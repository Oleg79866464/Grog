import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import PagesModal from './components/PagesModal';

// Pages
import HomePage from './pages/HomePage';
import CategoryMarketing from './pages/CategoryMarketing';
import CategorySMM from './pages/CategorySMM';
import CategoryTextgen from './pages/CategoryTextgen';
import CategorySEO from './pages/CategorySEO';
import CategoryContent from './pages/CategoryContent';
import CategoryImagegen from './pages/CategoryImagegen';
import CategoryVideo from './pages/CategoryVideo';
import CategoryBusiness from './pages/CategoryBusiness';
import ToolDetailPage from './pages/ToolDetailPage';
import RedirectPage from './pages/RedirectPage';
import AdminAnalytics from './pages/AdminAnalytics';
import AdminTemplates from './pages/AdminTemplates';
import BuyerReport from './pages/BuyerReport';
import ContactPage from './pages/ContactPage';
import PromptsMarketplace from './pages/PromptsMarketplace';
import PromptProduct from './pages/PromptProduct';
import SponsorsPage from './pages/SponsorsPage';
import RevenueWidgetPage from './pages/RevenueWidgetPage';
import SEOContentSection from './pages/SEOContentSection';

interface Tool {
  id: string;
  name: string;
  description: string;
  category: string;
  price: string;
  rating: number;
  users: string;
  badge?: string;
  premium?: boolean;
}

interface PromptItem {
  id: number;
  title: string;
  cat: string;
  price: string;
  desc: string;
  badge?: string;
}

type Page = 
  | 'home' | 'categories' | 'prompts' | 'admin' | 'contact' | 'redirect'
  | 'marketing' | 'smm' | 'textgen' | 'seo' | 'content' | 'imagegen' | 'video' | 'business'
  | 'tool' | 'analytics' | 'template-admin' | 'buyer-report' 
  | 'prompt-product' | 'sponsors' | 'revenue-widget' | 'seo-content';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [showPagesModal, setShowPagesModal] = useState(false);
  const [selectedTool, setSelectedTool] = useState<Tool | null>(null);
  const [selectedPrompt, setSelectedPrompt] = useState<PromptItem | null>(null);

  const navigate = (page: string) => {
    const validPages: Page[] = [
      'home', 'categories', 'prompts', 'admin', 'contact', 'redirect',
      'marketing', 'smm', 'textgen', 'seo', 'content', 'imagegen', 'video', 'business',
      'tool', 'analytics', 'template-admin', 'buyer-report',
      'prompt-product', 'sponsors', 'revenue-widget', 'seo-content'
    ];
    const target = page as Page;
    
    if (validPages.includes(target)) {
      setCurrentPage(target);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      setCurrentPage('home');
    }
  };

  const openTool = (tool: Tool) => {
    setSelectedTool(tool);
    setCurrentPage('tool');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openPrompt = (prompt: PromptItem) => {
    setSelectedPrompt(prompt);
    setCurrentPage('prompt-product');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const goToRedirect = () => {
    setCurrentPage('redirect');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openPagesModal = () => setShowPagesModal(true);

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={navigate} onOpenTool={openTool} />;
      
      case 'marketing':
        return <CategoryMarketing onNavigate={navigate} onOpenTool={openTool} />;
      case 'smm':
        return <CategorySMM onOpenTool={openTool} />;
      case 'textgen':
        return <CategoryTextgen onOpenTool={openTool} />;
      case 'seo':
        return <CategorySEO onOpenTool={openTool} />;
      case 'content':
        return <CategoryContent onOpenTool={openTool} />;
      case 'imagegen':
        return <CategoryImagegen onOpenTool={openTool} />;
      case 'video':
        return <CategoryVideo onOpenTool={openTool} />;
      case 'business':
        return <CategoryBusiness onOpenTool={openTool} />;

      case 'tool':
        return <ToolDetailPage tool={selectedTool} onNavigate={navigate} onGoToRedirect={goToRedirect} />;
      
      case 'redirect':
        return <RedirectPage onNavigate={navigate} />;

      case 'analytics':
        return <AdminAnalytics />;
      case 'template-admin':
        return <AdminTemplates />;
      case 'buyer-report':
        return <BuyerReport />;

      case 'contact':
        return <ContactPage />;

      case 'prompts':
        return <PromptsMarketplace onOpenPrompt={openPrompt} />;
      case 'prompt-product':
        return <PromptProduct prompt={selectedPrompt} onNavigate={navigate} onBuy={goToRedirect} />;

      case 'sponsors':
        return <SponsorsPage />;
      case 'revenue-widget':
        return <RevenueWidgetPage />;
      case 'seo-content':
        return <SEOContentSection onNavigate={navigate} />;

      case 'categories':
      case 'admin':
      default:
        return <HomePage onNavigate={navigate} onOpenTool={openTool} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0b0f] text-white overflow-x-hidden">
      <Navbar 
        currentPage={currentPage} 
        onNavigate={navigate} 
        onOpenPagesModal={openPagesModal} 
      />

      <main>
        {renderPage()}
      </main>

      <Footer onNavigate={navigate} />

      <PagesModal 
        isOpen={showPagesModal} 
        onClose={() => setShowPagesModal(false)} 
        onNavigate={navigate} 
      />

      {/* Floating quick access for premium feel */}
      <button 
        onClick={() => setShowPagesModal(true)} 
        className="fixed bottom-8 right-8 z-50 hidden xl:block px-5 py-2.5 rounded-2xl glass text-xs tracking-[1px] border border-white/20 hover:border-white/40"
      >
        ВСЕ 20 СТРАНИЦ
      </button>
    </div>
  );
};

export default App;
