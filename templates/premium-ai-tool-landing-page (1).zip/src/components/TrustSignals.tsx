import React from 'react';
import { Shield, Award, Users, TrendingUp } from 'lucide-react';

const TrustSignals: React.FC = () => (
  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
    {[
      { icon: Shield, label: 'Проверено', value: '100%' },
      { icon: Award, label: 'Рейтинг', value: '4.92' },
      { icon: Users, label: 'Пользователей', value: '142.8K' },
      { icon: TrendingUp, label: 'Рост', value: '+67%' },
    ].map((t, i) => (
      <div key={i} className="glass rounded-2xl p-5 flex gap-4 items-center border border-white/10">
        <div className="w-11 h-11 rounded-xl bg-white/5 flex items-center justify-center"><t.icon className="w-5 h-5 text-indigo-400" /></div>
        <div>
          <div className="text-xl font-semibold tracking-tight">{t.value}</div>
          <div className="text-xs text-white/50">{t.label}</div>
        </div>
      </div>
    ))}
  </div>
);

export default TrustSignals;
