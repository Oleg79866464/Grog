import React from 'react';

interface PagesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (page: string) => void;
}

const PagesModal: React.FC<PagesModalProps> = ({ isOpen, onClose, onNavigate }) => {
  if (!isOpen) return null;

  const pages = [
    { id: 'home', label: '01. Главная страница', desc: 'Полная домашняя страница каталога' },
    { id: 'marketing', label: '02. Нейросети для маркетинга', desc: 'Целевая страница категории' },
    { id: 'smm', label: '03. ИИ для SMM', desc: 'Лендинг для SMM-специалистов' },
    { id: 'textgen', label: '04. Генератор текста', desc: 'Категория генераторов текста' },
    { id: 'seo', label: '05. ИИ для SEO', desc: 'Категория инструментов SEO' },
    { id: 'content', label: '06. ИИ для контента', desc: 'Категория создания контента' },
    { id: 'imagegen', label: '07. Генератор изображений', desc: 'Категория AI-генерации картинок' },
    { id: 'video', label: '08. AI для видео', desc: 'Категория видео генерации' },
    { id: 'business', label: '09. AI для бизнеса', desc: 'Корпоративные инструменты' },
    { id: 'tool', label: '10. Страница инструмента', desc: 'Детальная карточка инструмента' },
    { id: 'redirect', label: '11. Redirect /go', desc: 'Экран редиректа и трекинга' },
    { id: 'analytics', label: '12. Админ: Аналитика', desc: 'Dashboard аналитики доходов' },
    { id: 'template-admin', label: '13. Админ: Шаблоны', desc: 'Управление шаблонами страниц' },
    { id: 'buyer-report', label: '14. Buyer report panel', desc: 'Отчёт для инвесторов' },
    { id: 'contact', label: '15. Контакты и портфолио', desc: 'Страница основателя' },
    { id: 'prompts', label: '16. Marketplace Prompts', desc: 'Маркетплейс промптов' },
    { id: 'prompt-product', label: '17. Prompt product card', desc: 'Полная карточка промпта' },
    { id: 'sponsors', label: '18. Спонсоры и реклама', desc: 'Страница для партнёров' },
    { id: 'revenue-widget', label: '19. Виджет доходов', desc: 'Премиум виджет аналитики' },
    { id: 'seo-content', label: '20. Раздел SEO-контента', desc: 'Коммерческий SEO-блок' },
  ];

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/90 p-6" onClick={onClose}>
      <div className="glass-strong rounded-3xl w-full max-w-3xl max-h-[86vh] overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="px-8 pt-8 pb-5 border-b border-white/10 flex items-center justify-between">
          <div>
            <div className="font-semibold tracking-tight text-2xl">Все страницы демо</div>
            <div className="text-sm text-white/50">20 премиум макетов в одном приложении</div>
          </div>
          <button onClick={onClose} className="text-white/50 hover:text-white">Закрыть</button>
        </div>

        <div className="p-8 overflow-auto max-h-[65vh] grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
          {pages.map((p, idx) => (
            <button
              key={idx}
              onClick={() => { onNavigate(p.id); onClose(); }}
              className="glass rounded-2xl p-5 text-left hover:border-white/20 border border-white/10 transition-all group"
            >
              <div className="font-semibold tracking-tight group-hover:text-indigo-400 transition-colors mb-1">{p.label}</div>
              <div className="text-white/50 text-[13px]">{p.desc}</div>
            </button>
          ))}
        </div>

        <div className="px-8 py-6 border-t border-white/10 bg-black/30 text-xs text-white/40 flex items-center justify-between">
          <div>Премиум B2B SaaS • Полностраничные макеты • Реалистичный UI</div>
          <div className="text-indigo-400">Кликните чтобы открыть</div>
        </div>
      </div>
    </div>
  );
};

export default PagesModal;
