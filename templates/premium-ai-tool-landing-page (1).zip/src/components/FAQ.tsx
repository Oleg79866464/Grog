import React, { useState } from 'react';

interface FAQItem {
  q: string;
  a: string;
}

interface FAQProps {
  items: FAQItem[];
}

const FAQ: React.FC<FAQProps> = ({ items }) => {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <div className="space-y-3">
      {items.map((item, idx) => (
        <div key={idx} className="faq-item glass rounded-2xl overflow-hidden border border-white/10">
          <button
            onClick={() => setOpen(open === idx ? null : idx)}
            className="w-full px-7 py-5 text-left flex items-center justify-between font-medium"
          >
            <span>{item.q}</span>
            <span className={`text-xl transition ${open === idx ? 'rotate-45' : ''}`}>+</span>
          </button>
          {open === idx && (
            <div className="px-7 pb-6 text-sm text-white/70 leading-relaxed">{item.a}</div>
          )}
        </div>
      ))}
    </div>
  );
};

export default FAQ;
