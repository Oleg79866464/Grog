import React from 'react';

interface FooterProps {
  onNavigate: (page: string) => void;
}

const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="border-t border-white/10 bg-[#08090c] pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-8">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-y-12">
          <div>
            <div className="flex items-center gap-2 mb-5">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center">
                <span className="text-white text-sm font-semibold">A</span>
              </div>
              <span className="font-semibold tracking-tight">AETHER</span>
            </div>
            <p className="text-xs text-white/50 leading-relaxed pr-4">
              Премиальный каталог российских ИИ-инструментов.<br />С 2023 года помогаем бизнесу внедрять ИИ.
            </p>
          </div>

          <div>
            <div className="text-xs font-semibold tracking-widest text-white/60 mb-4">КАТЕГОРИИ</div>
            <div className="space-y-2.5 text-sm text-white/70">
              {[
                { label: 'Нейросети для маркетинга', page: 'marketing' },
                { label: 'ИИ для SMM', page: 'smm' },
                { label: 'Генератор текста', page: 'textgen' },
                { label: 'ИИ для SEO', page: 'seo' },
              ].map((l, i) => (
                <button key={i} onClick={() => onNavigate(l.page)} className="block hover:text-white transition-colors">{l.label}</button>
              ))}
            </div>
          </div>

          <div>
            <div className="text-xs font-semibold tracking-widest text-white/60 mb-4">ПРОДУКТЫ</div>
            <div className="space-y-2.5 text-sm text-white/70">
              {[
                { label: 'Маркетплейс Prompts', page: 'prompts' },
                { label: 'Генератор изображений', page: 'imagegen' },
                { label: 'AI для видео', page: 'video' },
                { label: 'AI для бизнеса', page: 'business' },
              ].map((l, i) => (
                <button key={i} onClick={() => onNavigate(l.page)} className="block hover:text-white transition-colors">{l.label}</button>
              ))}
            </div>
          </div>

          <div>
            <div className="text-xs font-semibold tracking-widest text-white/60 mb-4">РЕСУРСЫ</div>
            <div className="space-y-2.5 text-sm text-white/70">
              <button onClick={() => onNavigate('seo-content')} className="block hover:text-white transition-colors">SEO-контент</button>
              <button onClick={() => onNavigate('sponsors')} className="block hover:text-white transition-colors">Партнёрам</button>
              <button onClick={() => onNavigate('contact')} className="block hover:text-white transition-colors">Контакты</button>
              <button onClick={() => onNavigate('buyer-report')} className="block hover:text-white transition-colors">Отчёт для инвесторов</button>
            </div>
          </div>

          <div>
            <div className="text-xs font-semibold tracking-widest text-white/60 mb-4">КОМПАНИЯ</div>
            <div className="space-y-2.5 text-sm text-white/70">
              <button onClick={() => onNavigate('contact')} className="block hover:text-white transition-colors">О нас и портфолио</button>
              <button onClick={() => onNavigate('analytics')} className="block hover:text-white transition-colors">Аналитика для партнёров</button>
              <button onClick={() => onNavigate('template-admin')} className="block hover:text-white transition-colors">Управление шаблонами</button>
            </div>
            <div className="mt-8 text-[11px] text-white/40">© 2023–2026 AETHER. Все права защищены.</div>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-white/10 text-[11px] flex flex-col md:flex-row justify-between gap-y-2 text-white/40">
          <div>Москва • Санкт-Петербург • Калининград • Политика конфиденциальности • Условия</div>
          <div>Рейтинг доверия: 98.4 • 142 800+ активных пользователей</div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
