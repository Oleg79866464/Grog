import React from 'react';

interface ComparisonRow {
  feature: string;
  a: string;
  b: string;
  c: string;
}

interface ComparisonTableProps {
  title: string;
  tools: string[];
  rows: ComparisonRow[];
}

const ComparisonTable: React.FC<ComparisonTableProps> = ({ title, tools, rows }) => {
  return (
    <div className="glass rounded-3xl p-8">
      <div className="font-semibold text-xl tracking-[-0.01em] mb-8">{title}</div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-white/10 text-left">
              <th className="pb-4 font-medium text-white/50 w-48">Параметр</th>
              {tools.map((t, i) => (
                <th key={i} className="pb-4 font-medium pl-4">{t}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, idx) => (
              <tr key={idx} className="border-b border-white/5 last:border-none">
                <td className="py-4 pr-4 text-white/70">{row.feature}</td>
                <td className="py-4 pl-4 text-white/90">{row.a}</td>
                <td className="py-4 pl-4 text-white/90">{row.b}</td>
                <td className="py-4 pl-4 text-white/90">{row.c}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ComparisonTable;
