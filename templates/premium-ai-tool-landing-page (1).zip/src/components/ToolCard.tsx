import React from 'react';
import { Star, ArrowRight } from 'lucide-react';

interface ToolCardProps {
  name: string;
  description: string;
  category: string;
  price: string;
  rating: number;
  users: string;
  onClick: () => void;
  badge?: string;
  premium?: boolean;
}

const ToolCard: React.FC<ToolCardProps> = ({ name, description, category, price, rating, users, onClick, badge, premium }) => {
  return (
    <div 
      onClick={onClick}
      className="tool-card glass rounded-3xl p-7 flex flex-col cursor-pointer border border-white/10 hover:border-white/20 group"
    >
      <div className="flex justify-between items-start mb-5">
        <div>
          <div className="font-semibold text-[17px] tracking-[-0.01em] mb-1 group-hover:text-white transition-colors">{name}</div>
          <div className="text-xs px-3 py-px rounded-full inline-block bg-white/5 text-white/60 border border-white/10">{category}</div>
        </div>
        {badge && (
          <div className={`text-[10px] tracking-widest px-3 py-1 rounded-full font-medium ${premium ? 'bg-violet-500/20 text-violet-300' : 'bg-emerald-500/15 text-emerald-400'}`}>
            {badge}
          </div>
        )}
      </div>

      <p className="text-sm text-white/70 leading-relaxed flex-1 mb-6 line-clamp-3">{description}</p>

      <div className="flex items-center justify-between pt-5 border-t border-white/10 mt-auto">
        <div className="flex items-center gap-2.5">
          <div className="flex text-amber-400">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} className={`w-3.5 h-3.5 ${i < Math.floor(rating) ? 'fill-current' : ''}`} />
            ))}
          </div>
          <span className="text-xs text-white/50">{rating} • {users}</span>
        </div>
        <div className="flex items-center gap-1.5 text-xs font-medium">
          <span className="text-white/70">{price}</span>
          <ArrowRight className="w-3.5 h-3.5 text-white/40 group-hover:text-white transition-colors" />
        </div>
      </div>
    </div>
  );
};

export default ToolCard;
