import React from 'react';
import { Menu, X, ChevronDown } from 'lucide-react';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onOpenPagesModal: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentPage, onNavigate, onOpenPagesModal }) => {
  const [mobileOpen, setMobileOpen] = React.useState(false);

  const navItems = [
    { label: 'Главная', id: 'home' },
    { label: 'Категории', id: 'categories' },
    { label: 'Prompts', id: 'prompts' },
    { label: 'Админ', id: 'admin' },
    { label: 'Контакты', id: 'contact' },
  ];

  const handleNav = (id: string) => {
    if (id === 'categories') {
      onOpenPagesModal();
    } else {
      onNavigate(id);
    }
    setMobileOpen(false);
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-strong border-b border-white/10">
      <div className="max-w-7xl mx-auto px-8 flex items-center justify-between h-20">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate('home')}>
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center">
            <span className="font-semibold text-white text-xl tracking-tighter">A</span>
          </div>
          <div>
            <div className="font-semibold text-xl tracking-[-0.02em]">AETHER</div>
            <div className="text-[10px] text-white/40 -mt-1">КАТАЛОГ ИИ</div>
          </div>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-9 text-sm">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => handleNav(item.id)}
              className={`nav-link text-sm font-medium transition-colors ${currentPage === item.id ? 'text-white' : 'text-white/70 hover:text-white'}`}
            >
              {item.label}
            </button>
          ))}
          <button
            onClick={onOpenPagesModal}
            className="flex items-center gap-2 px-5 py-2 rounded-full text-sm font-medium glass border border-white/10 hover:border-white/20"
          >
            Все страницы <ChevronDown className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="hidden md:flex items-center gap-3">
          <button 
            onClick={() => onNavigate('admin')}
            className="px-4 py-2 text-sm font-medium text-white/80 hover:text-white transition-colors"
          >
            Войти в админ
          </button>
          <button 
            onClick={() => onNavigate('redirect')}
            className="btn-primary px-6 py-2.5 rounded-full text-sm font-semibold text-white shadow-lg"
          >
            Начать бесплатно
          </button>
        </div>

        {/* Mobile */}
        <button 
          onClick={() => setMobileOpen(!mobileOpen)} 
          className="md:hidden p-2 text-white/80"
        >
          {mobileOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="md:hidden border-t border-white/10 bg-[#0a0b0f] px-6 py-6 space-y-4 text-sm">
          {navItems.map(item => (
            <button key={item.id} onClick={() => handleNav(item.id)} className="block w-full text-left py-2 text-white/90">
              {item.label}
            </button>
          ))}
          <button onClick={() => { onOpenPagesModal(); setMobileOpen(false); }} className="block w-full text-left py-2 text-white/90">
            Все страницы демо
          </button>
          <div className="pt-4 flex flex-col gap-3">
            <button onClick={() => { onNavigate('admin'); setMobileOpen(false); }} className="w-full py-3 rounded-full glass text-sm">Войти в админ</button>
            <button onClick={() => { onNavigate('redirect'); setMobileOpen(false); }} className="w-full py-3 rounded-full btn-primary text-sm font-medium">Начать бесплатно</button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
