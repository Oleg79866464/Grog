import React, { useState, useEffect } from 'react';
import { ArrowRight } from 'lucide-react';

interface Props { onNavigate: (p: string) => void; }

const RedirectPage: React.FC<Props> = ({ onNavigate }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress(p => {
        if (p >= 100) {
          clearInterval(timer);
          return 100;
        }
        return p + 14;
      });
    }, 240);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen pt-20 bg-[#0a0b0f] flex items-center justify-center px-6">
      <div className="max-w-md w-full text-center">
        <div className="glass-strong rounded-3xl px-12 py-14 border border-white/10">
          <div className="mx-auto w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center mb-8">
            <ArrowRight className="text-white w-8 h-8" />
          </div>
          
          <div className="font-semibold text-3xl tracking-tight mb-2">Переходим на сайт</div>
          <div className="text-lg text-white/70 mb-9">NeuroCopy • Партнёрский редирект</div>

          <div className="h-1.5 bg-white/10 rounded-full overflow-hidden mb-2">
            <div className="h-1.5 bg-gradient-to-r from-indigo-500 to-violet-500 transition-all" style={{ width: `${progress}%` }} />
          </div>
          <div className="text-xs text-white/50 mb-8 tracking-widest">ПЕРЕНАПРАВЛЕНИЕ • {progress}%</div>

          <div className="text-sm text-white/60 mb-8 leading-relaxed">
            Вы будете перенаправлены на официальный сайт инструмента. Мы получаем небольшое вознаграждение от партнёров — это позволяет нам поддерживать каталог бесплатно.
          </div>

          <div className="flex gap-3">
            <button onClick={() => onNavigate('home')} className="flex-1 py-3 rounded-full glass text-sm">Отменить</button>
            <button onClick={() => window.open('https://example.com/neurocopy', '_blank')} className="flex-1 py-3 rounded-full btn-primary text-sm font-medium">Продолжить переход</button>
          </div>
        </div>

        <div className="mt-6 text-xs text-white/40">Защищено • SSL • Прозрачный трекинг</div>
      </div>
    </div>
  );
};
export default RedirectPage;