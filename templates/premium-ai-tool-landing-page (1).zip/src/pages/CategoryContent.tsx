import React from 'react';
import ToolCard from '../components/ToolCard';
import FAQ from '../components/FAQ';

interface Props { onOpenTool: (t: any) => void; }

const CategoryContent: React.FC<Props> = ({ onOpenTool }) => {
  const tools = [
    { id: 'cnt1', name: 'ContentForge', description: 'Полный цикл создания контента: от идеи до готовой статьи или поста. 15 форматов.', category: 'Контент', price: 'от 2 400 ₽', rating: 4.7, users: '29k' },
    { id: 'cnt2', name: 'Longform AI', description: 'Генерация длинных экспертных материалов, исследований и гайдов.', category: 'Статьи', price: 'от 3 200 ₽', rating: 4.8, users: '7k', badge: 'Эксперт' },
    { id: 'cnt3', name: 'BrandVoice', description: 'Сохранение стиля бренда и генерация контента в едином тоне.', category: 'Брендинг', price: 'от 1 950 ₽', rating: 4.6, users: '15k' },
  ];

  return (
    <div className="min-h-screen pt-20 bg-[#0a0b0f]">
      <div className="max-w-7xl mx-auto px-8 pt-14 pb-20">
        <div className="max-w-3xl">
          <div className="uppercase tracking-widest text-xs text-white/50 mb-3">КАТЕГОРИЯ</div>
          <h1 className="section-title mb-4">ИИ для контента</h1>
          <p className="text-lg text-white/70">Создавайте качественный контент в 6 раз быстрее. От постов до глубоких экспертных статей. Полная поддержка бренд-voice и SEO-оптимизации.</p>
        </div>

        <div className="mt-12">
          <div className="font-semibold text-xl tracking-tight mb-7">Рекомендуемые инструменты</div>
          <div className="grid md:grid-cols-3 gap-6">
            {tools.map((t, i) => <ToolCard key={i} {...t} onClick={() => onOpenTool(t)} />)}
          </div>
        </div>

        <div className="mt-16 grid md:grid-cols-5 gap-4">
          {["Идея → Структура → Текст → SEO → Публикация"].map((step, i) => (
            <div key={i} className="glass rounded-2xl px-6 py-6 text-sm">{step}</div>
          ))}
        </div>

        <div className="mt-16 max-w-3xl">
          <div className="font-semibold tracking-tight mb-5 text-xl">Коммерческий контент</div>
          <div className="text-sm text-white/75 leading-relaxed">
            Компании, которые используют ИИ для производства контента, сокращают расходы на копирайтинг на 65% и выпускают на 4.8 раза больше материалов. Наши инструменты позволяют сохранять уникальный голос бренда и полностью контролировать качество.
          </div>
        </div>

        <div className="mt-16">
          <div className="font-semibold text-xl mb-6">Часто задаваемые вопросы</div>
          <FAQ items={[
            { q: 'Как обеспечить уникальность?', a: 'Каждый инструмент имеет встроенные проверки и режимы креатива. Средняя уникальность — 97%.' },
            { q: 'Можно ли подключить свою базу знаний?', a: 'Да, большинство инструментов поддерживают загрузку документов и корпоративных баз.' },
          ]} />
        </div>
      </div>
    </div>
  );
};

export default CategoryContent;
