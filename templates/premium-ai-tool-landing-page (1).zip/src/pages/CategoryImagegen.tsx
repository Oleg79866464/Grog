import React from 'react';
import ToolCard from '../components/ToolCard';
import FAQ from '../components/FAQ';

interface Props { onOpenTool: (t: any) => void; }

const CategoryImagegen: React.FC<Props> = ({ onOpenTool }) => {
  const tools = [
    { id: 'img1', name: 'Visor AI', description: 'Генерация фотореалистичных и стилизованных изображений. 12 стилей и высокое качество.', category: 'Изображения', price: 'от 1 450 ₽', rating: 4.8, users: '31k', badge: 'Топ' },
    { id: 'img2', name: 'RuImage Pro', description: 'Специализированный генератор для российского рынка: баннеры, соцсети, иллюстрации.', category: 'Дизайн', price: 'от 990 ₽', rating: 4.7, users: '24k' },
    { id: 'img3', name: 'ConceptFlow', description: 'Генерация концепт-арта и визуалов для рекламы и продуктов.', category: 'Коммерция', price: 'от 2 100 ₽', rating: 4.9, users: '7.8k' },
  ];

  return (
    <div className="min-h-screen pt-20 bg-[#0a0b0f]">
      <div className="max-w-7xl mx-auto px-8 pt-14 pb-20">
        <div className="max-w-3xl">
          <div className="uppercase text-xs tracking-[3px] text-white/50">КАТЕГОРИЯ</div>
          <h1 className="section-title mt-2 mb-4">Генератор изображений</h1>
          <p className="text-lg text-white/70">Премиальные нейросети для генерации визуалов. Создавайте баннеры, иллюстрации и рекламные изображения за секунды. Полная совместимость с российскими платформами.</p>
        </div>

        <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-5">
          {["Рекламные баннеры", "Фотореалистичные изображения", "Концепты и иллюстрации", "Изображения для соцсетей", "3D и продукт-визуалы", "Упаковка и дизайн"].map((l, i) => (
            <div key={i} className="glass rounded-2xl p-6 text-sm border border-white/10">{l}</div>
          ))}
        </div>

        <div className="mt-16">
          <div className="text-2xl font-semibold tracking-tight mb-8">Лучшие инструменты</div>
          <div className="grid md:grid-cols-3 gap-6">
            {tools.map((t, i) => <ToolCard key={i} {...t} onClick={() => onOpenTool(t)} />)}
          </div>
        </div>

        <div className="mt-16">
          <div className="font-semibold text-xl mb-6">Часто задаваемые вопросы</div>
          <FAQ items={[
            { q: 'Какое качество генерации?', a: 'Разрешение до 4K. Качество выше, чем у большинства зарубежных аналогов.' },
            { q: 'Можно ли использовать в коммерции?', a: 'Да. Все инструменты предоставляют коммерческую лицензию.' },
          ]} />
        </div>
      </div>
    </div>
  );
};
export default CategoryImagegen;