import React from 'react';
import ToolCard from '../components/ToolCard';
import ComparisonTable from '../components/ComparisonTable';
import FAQ from '../components/FAQ';

interface Props {
  onNavigate: (p: string) => void;
  onOpenTool: (t: any) => void;
}

const CategoryMarketing: React.FC<Props> = ({ onNavigate, onOpenTool }) => {
  const tools = [
    { id: 'nc', name: 'NeuroCopy', description: 'Генерация продающих текстов и email-рассылок под российский рынок. 30+ шаблонов.', category: 'Текст', price: 'от 2 900 ₽', rating: 4.9, users: '34k', badge: 'Топ' },
    { id: 'mkt', name: 'MarketAI', description: 'Полный цикл маркетинговой стратегии и генерации контента под разные каналы.', category: 'Стратегия', price: 'от 4 900 ₽', rating: 4.8, users: '12k' },
    { id: 'copy', name: 'CopyForge', description: 'Рекламные тексты для VK Ads, Яндекс.Директ и Telegram. Высокая конверсия.', category: 'Реклама', price: 'от 1 790 ₽', rating: 4.7, users: '27k', badge: 'Популярно' },
  ];

  const useCases = [
    "Генерация продающих описаний товаров для маркетплейсов",
    "Создание email-воронок и рассылок с высокой открываемостью",
    "Разработка рекламных текстов для VK, MyTarget и Яндекс",
    "Автоматическая генерация сценариев для вебинаров и презентаций"
  ];

  const faqs = [
    { q: 'Подходит ли для небольших магазинов?', a: 'Да, есть тарифы с 500 генерациями в месяц. Инструмент быстро окупается при правильном использовании.' },
    { q: 'Есть ли интеграция с CRM?', a: 'Полная интеграция с AmoCRM, Bitrix24, 1C и RetailCRM.' },
    { q: 'Какой процент конверсии?', a: 'Средний рост конверсии по отзывам клиентов — 29–47% при замене ручных текстов.' },
  ];

  return (
    <div className="min-h-screen pt-20 bg-[#0a0b0f]">
      <div className="max-w-7xl mx-auto px-8 pt-14 pb-20">
        <div className="max-w-3xl">
          <div className="uppercase text-xs tracking-[3px] text-indigo-400 mb-3">КАТЕГОРИЯ</div>
          <h1 className="section-title mb-4">Нейросети для маркетинга</h1>
          <p className="text-xl text-white/70">Инструменты, которые увеличивают продажи и снижают стоимость привлечения клиента. Адаптированы под российский рынок и 152-ФЗ.</p>
        </div>

        <div className="mt-9 flex flex-wrap gap-3">
          <button onClick={() => onNavigate('home')} className="text-xs px-4 py-2 rounded-full glass">← На главную</button>
          <button onClick={() => onNavigate('seo')} className="text-xs px-4 py-2 rounded-full glass">Смотреть ИИ для SEO</button>
        </div>

        {/* Use cases */}
        <div className="mt-16 glass rounded-3xl p-9">
          <div className="font-semibold mb-6">Сценарии использования</div>
          <div className="grid md:grid-cols-2 gap-x-12 gap-y-4 text-sm text-white/75">
            {useCases.map((u, i) => <div key={i} className="flex gap-3">• {u}</div>)}
          </div>
        </div>

        {/* Tools */}
        <div className="mt-16">
          <div className="flex items-center justify-between mb-6">
            <div className="font-semibold tracking-tight text-2xl">Рекомендуемые инструменты</div>
            <div className="text-sm text-white/50">48 инструментов в категории</div>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {tools.map((t, idx) => <ToolCard key={idx} {...t} onClick={() => onOpenTool(t)} />)}
          </div>
        </div>

        {/* Comparison */}
        <div className="mt-16">
          <ComparisonTable 
            title="Сравнение топ-3 решений" 
            tools={["NeuroCopy", "MarketAI", "CopyForge"]} 
            rows={[
              { feature: "Генерация рекламы", a: "Отлично", b: "Хорошо", c: "Отлично" },
              { feature: "Email-маркетинг", a: "Отлично", b: "Хорошо", c: "Средне" },
              { feature: "Интеграции", a: "Amo, Bitrix, 1C", b: "Zapier + 12", c: "VK + Direct" },
              { feature: "Цена от", a: "2 900 ₽", b: "4 900 ₽", c: "1 790 ₽" },
            ]} 
          />
        </div>

        {/* SEO commercial text */}
        <div className="mt-16 glass-strong p-9 rounded-3xl text-[15px] text-white/75 leading-relaxed border border-white/10">
          <h3 className="font-semibold text-white mb-4 text-lg tracking-tight">Как маркетинговые нейросети увеличивают ROI</h3>
          <p>По данным исследования AETHER 2025 года, компании, использующие ИИ-инструменты для генерации маркетингового контента, получают в среднем на 31% больше лидов при сокращении затрат на копирайтинг на 62%. Особенно эффективны решения с поддержкой русского языка и интеграцией с Яндекс.Директ и VK Ads.</p>
          <p className="mt-4">Выбирайте инструменты с доказанными кейсами и возможностью дообучения под ваш бренд.</p>
        </div>

        <div className="mt-16">
          <div className="font-semibold text-2xl tracking-tight mb-6">Часто задаваемые вопросы</div>
          <FAQ items={faqs} />
        </div>
      </div>
    </div>
  );
};

export default CategoryMarketing;
