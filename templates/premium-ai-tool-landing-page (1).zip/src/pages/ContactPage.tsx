import React from 'react';

const ContactPage: React.FC = () => (
  <div className="min-h-screen pt-20 bg-[#0a0b0f]">
    <div className="max-w-4xl mx-auto px-8 pt-14 pb-20">
      <div className="grid md:grid-cols-5 gap-x-14">
        <div className="md:col-span-2">
          <div className="w-28 h-28 rounded-3xl bg-gradient-to-br from-zinc-700 to-black mb-8" />
          <div className="font-semibold text-[28px] tracking-[-0.02em]">Алексей Ветров</div>
          <div className="text-white/50">Основатель AETHER • 2015–2026</div>

          <div className="mt-9 text-sm space-y-1 text-white/70">
            <div>Москва, Россия</div>
            <div>hello@aether.ai</div>
            <div>tg: @aetherfounder</div>
          </div>
          <div className="mt-7 flex gap-3">
            <a className="glass px-5 py-2 rounded-full text-sm border border-white/10">LinkedIn</a>
            <a className="glass px-5 py-2 rounded-full text-sm border border-white/10">Telegram</a>
          </div>
        </div>

        <div className="md:col-span-3 mt-12 md:mt-0">
          <div className="text-xl font-semibold tracking-tight mb-4">Обо мне</div>
          <div className="text-white/70 leading-relaxed text-[15px]">11 лет в digital-маркетинге. Основатель двух успешных SaaS-продуктов (один успешно продан). С 2023 года строю AETHER — самый надёжный и премиальный каталог ИИ-инструментов для российского бизнеса.</div>

          <div className="mt-9">
            <div className="uppercase text-xs tracking-widest text-white/50 mb-4">Портфолио и кейсы</div>
            <div className="space-y-4 text-sm">
              <div className="glass p-5 rounded-2xl border border-white/10">LeadFlow — продажа за 7.4 млн ₽ (2022)</div>
              <div className="glass p-5 rounded-2xl border border-white/10">ContentForge — 41k пользователей, серия A</div>
              <div className="glass p-5 rounded-2xl border border-white/10">AETHER — текущий проект</div>
            </div>
          </div>

          <button className="mt-8 btn-primary px-9 py-3.5 rounded-2xl text-sm font-medium">Написать напрямую</button>
        </div>
      </div>
    </div>
  </div>
);
export default ContactPage;