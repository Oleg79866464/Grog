import React from 'react';
import ToolCard from '../components/ToolCard';
import TrustSignals from '../components/TrustSignals';
import FAQ from '../components/FAQ';

interface Props { onOpenTool: (t: any) => void; }

const CategoryBusiness: React.FC<Props> = ({ onOpenTool }) => {
  const tools = [
    { id: 'biz1', name: 'EnterpriseAI Suite', description: 'Полная автоматизация бизнес-процессов: аналитика, отчёты, поддержка клиентов.', category: 'Enterprise', price: 'от 29 000 ₽', rating: 4.9, users: '1.4k', badge: 'Enterprise' },
    { id: 'biz2', name: 'BizBrain', description: 'Интеллектуальный помощник для руководителей. Анализ рынка и принятие решений.', category: 'Аналитика', price: 'от 8 900 ₽', rating: 4.7, users: '3.9k' },
    { id: 'biz3', name: 'AutoOps AI', description: 'Автоматизация операционных задач и внутренних процессов.', category: 'Операции', price: 'от 6 200 ₽', rating: 4.6, users: '2.8k' },
  ];

  return (
    <div className="min-h-screen pt-20 bg-[#0a0b0f]">
      <div className="max-w-7xl mx-auto px-8 pt-14 pb-20">
        <div className="max-w-4xl">
          <div className="uppercase tracking-[2px] text-xs text-white/50">КАТЕГОРИЯ</div>
          <h1 className="section-title mb-4">AI для бизнеса</h1>
          <p className="text-lg text-white/70">Корпоративные решения для автоматизации и аналитики. Увеличьте эффективность бизнеса в 3–5 раз при помощи проверенных ИИ-инструментов.</p>
        </div>

        <div className="mt-8"><TrustSignals /></div>

        <div className="mt-16">
          <div className="text-2xl font-semibold tracking-tight mb-8">Корпоративные инструменты</div>
          <div className="grid md:grid-cols-3 gap-6">
            {tools.map((t, i) => <ToolCard key={i} {...t} onClick={() => onOpenTool(t)} />)}
          </div>
        </div>

        <div className="mt-16 glass rounded-3xl px-9 py-10">
          <div className="text-xl font-semibold mb-4">Процесс внедрения в крупный бизнес</div>
          <div className="grid md:grid-cols-4 gap-4 text-sm text-white/70">
            <div>Аудит и выбор инструмента</div><div>Интеграция с внутренними системами</div><div>Обучение сотрудников</div><div>Мониторинг ROI и масштабирование</div>
          </div>
        </div>

        <div className="mt-16">
          <div className="font-semibold tracking-tight text-xl mb-5">Часто задаваемые вопросы</div>
          <FAQ items={[
            { q: 'Подходит ли для среднего бизнеса?', a: 'Да. Есть решения для компаний от 15 сотрудников.' },
            { q: 'Есть ли внедрение под ключ?', a: 'Да. Мы предлагаем услуги по интеграции и обучению.' },
          ]} />
        </div>
      </div>
    </div>
  );
};
export default CategoryBusiness;