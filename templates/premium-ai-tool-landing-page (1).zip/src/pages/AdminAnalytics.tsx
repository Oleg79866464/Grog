import React from 'react';
import { Download } from 'lucide-react';

const AdminAnalytics: React.FC = () => {
  const kpis = [
    { label: "Всего кликов", value: "187,420", change: "+21%" },
    { label: "Оценочная выручка", value: "₽4.82M", change: "+38%" },
    { label: "Revenue per click", value: "₽25.7", change: "+12%" },
    { label: "Конверсия", value: "3.9%", change: "-0.4%" },
  ];

  const topTools = [
    { name: "NeuroCopy", clicks: "38,420", rev: "1.12M", cr: "4.8%" },
    { name: "SMMForge AI", clicks: "27,180", rev: "689K", cr: "3.9%" },
    { name: "Texta Pro", clicks: "31,940", rev: "794K", cr: "3.2%" },
    { name: "Visor AI", clicks: "21,390", rev: "521K", cr: "4.1%" },
  ];

  return (
    <div className="min-h-screen pt-20 bg-[#0a0b0f] px-8 pb-20">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-end mb-9 pt-8">
          <div>
            <div className="text-xs tracking-[3px] text-white/50">АДМИН-ПАНЕЛЬ</div>
            <div className="text-4xl font-semibold tracking-[-0.03em] mt-1">Аналитика</div>
          </div>
          <button className="flex items-center gap-2 px-6 py-2.5 rounded-2xl glass text-sm border border-white/10">
            <Download className="w-4 h-4" /> Экспорт отчёта
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-9">
          {kpis.map((k, i) => (
            <div key={i} className="stat-card glass rounded-3xl px-6 py-6 border border-white/10">
              <div className="text-xs uppercase tracking-widest text-white/50">{k.label}</div>
              <div className="text-3xl font-semibold mt-2 tabular-nums">{k.value}</div>
              <div className="text-xs text-emerald-400 mt-1">{k.change}</div>
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-5 gap-5">
          {/* Charts */}
          <div className="md:col-span-3 glass rounded-3xl p-8">
            <div className="flex justify-between items-center mb-8">
              <div className="font-semibold">Динамика кликов и выручки (90 дней)</div>
              <div className="text-xs text-white/40">Янв — Мар 2026</div>
            </div>
            <div className="h-64 flex items-end gap-2">
              {[42, 58, 51, 71, 64, 79, 84, 68, 91, 77, 95, 88].map((h, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-1">
                  <div className="chart-bar w-full bg-gradient-to-t from-indigo-500/70 to-violet-500 rounded-t" style={{ height: `${h}%` }} />
                  <div className="text-[9px] text-white/40 mt-1">{i + 1}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="md:col-span-2 glass rounded-3xl p-8 flex flex-col">
            <div className="font-semibold mb-6">Распределение по странам</div>
            <div className="space-y-4 text-sm flex-1">
              {[{ c: "Россия", p: 71 }, { c: "Казахстан", p: 11 }, { c: "Беларусь", p: 8 }, { c: "Другие", p: 10 }].map((r, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-24 text-white/70">{r.c}</div>
                  <div className="flex-1 h-2 bg-white/10 rounded"><div className="h-2 rounded bg-indigo-400" style={{ width: r.p + '%' }} /></div>
                  <div className="w-8 text-right text-xs text-white/60">{r.p}%</div>
                </div>
              ))}
            </div>
            <div className="text-xs text-white/50 pt-6 border-t border-white/10">Устройства: Десктоп 61% • Мобильные 39%</div>
          </div>
        </div>

        <div className="mt-6">
          <div className="glass rounded-3xl p-8">
            <div className="font-semibold mb-6">Топ инструменты по доходности</div>
            <table className="w-full text-sm">
              <thead><tr className="text-white/50 text-left border-b border-white/10"><th className="pb-3">Инструмент</th><th className="pb-3">Клики</th><th className="pb-3">Выручка</th><th className="pb-3">CR</th></tr></thead>
              <tbody>
                {topTools.map((t, idx) => (
                  <tr key={idx} className="border-b border-white/5 last:border-0"><td className="py-4">{t.name}</td><td>{t.clicks}</td><td className="text-emerald-400">{t.rev}</td><td>{t.cr}</td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
export default AdminAnalytics;