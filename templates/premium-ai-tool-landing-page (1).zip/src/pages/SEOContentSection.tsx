import React from 'react';

interface Props { onNavigate: (p: string) => void; }

const SEOContentSection: React.FC<Props> = ({ onNavigate }) => (
  <div className="min-h-screen pt-20 bg-[#0a0b0f]">
    <div className="max-w-4xl mx-auto px-8 pt-16 pb-20">
      <div className="text-xs tracking-[2px] text-indigo-400">КОММЕРЧЕСКИЙ КОНТЕНТ</div>
      <h1 className="section-title mt-3 mb-8">Как выбрать ИИ-инструмент для вашего бизнеса в 2026 году</h1>

      <div className="prose prose-invert text-[15px] text-white/75 max-w-none leading-relaxed space-y-6">
        <p>Российский рынок нейросетей и ИИ-сервисов переживает беспрецедентный рост. По данным исследования AETHER, за последний год количество компаний, внедривших ИИ в маркетинг и производство контента, выросло на 167%.</p>
        
        <p>Главное преимущество каталога AETHER — строгая фильтрация. Мы проверяем не только качество генерации и удобство интерфейса, но и реальную отдачу для бизнеса, соблюдение 152-ФЗ и интеграции с российскими сервисами (Яндекс, VK, AmoCRM, 1C).</p>
        
        <h3 className="font-semibold text-white mt-8">Что важно при выборе инструмента</h3>
        <ul className="list-disc pl-5 space-y-1">
          <li>Качество русского языка и понимание локальных особенностей</li>
          <li>Наличие интеграций с привычными CRM и рекламными системами</li>
          <li>Прозрачные условия лицензии и коммерческого использования</li>
          <li>Поддержка и регулярные обновления</li>
        </ul>
      </div>

      <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-4">
        {["Маркетинг", "SMM", "SEO", "Текст", "Изображения", "Видео"].map((c, i) => (
          <button key={i} onClick={() => onNavigate(c.toLowerCase().replace(' ', ''))} className="glass px-6 py-5 rounded-2xl text-sm text-left border border-white/10 hover:border-white/30">Смотреть категорию: {c} →</button>
        ))}
      </div>
    </div>
  </div>
);
export default SEOContentSection;