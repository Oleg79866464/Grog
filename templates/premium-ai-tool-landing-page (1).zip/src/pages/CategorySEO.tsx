import React from 'react';
import ToolCard from '../components/ToolCard';
import ComparisonTable from '../components/ComparisonTable';
import FAQ from '../components/FAQ';
import TrustSignals from '../components/TrustSignals';

interface Props { onOpenTool: (t: any) => void; }

const CategorySEO: React.FC<Props> = ({ onOpenTool }) => {
  const tools = [
    { id: 'seo1', name: 'SEOlytics AI', description: 'Полноценный SEO-анализ, кластеризация запросов, генерация ТЗ для копирайтеров.', category: 'SEO', price: 'от 3 900 ₽', rating: 4.9, users: '8.2k', badge: 'Премиум' },
    { id: 'seo2', name: 'RankAI', description: 'Автоматическая генерация SEO-оптимизированных текстов и метатегов.', category: 'Контент', price: 'от 1 800 ₽', rating: 4.6, users: '17k' },
    { id: 'seo3', name: 'YandexSEO AI', description: 'Анализ позиций и рекомендаций специально под алгоритмы Яндекса.', category: 'Анализ', price: 'от 2 990 ₽', rating: 4.8, users: '6.9k' },
  ];

  return (
    <div className="min-h-screen pt-20 bg-[#0a0b0f]">
      <div className="max-w-7xl mx-auto px-8 pt-14 pb-20">
        <div className="max-w-3xl">
          <div className="uppercase tracking-[2.5px] text-xs text-sky-400">КАТЕГОРИЯ • SEO</div>
          <h1 className="section-title mt-2 mb-4">ИИ для SEO</h1>
          <p className="text-lg text-white/70">Современные инструменты для быстрого роста органического трафика в России. Кластеризация, генерация ТЗ, анализ конкурентов и оптимизация контента под Яндекс и Google.</p>
        </div>

        <div className="mt-8"><TrustSignals /></div>

        <div className="mt-14">
          <div className="text-xl font-semibold tracking-tight mb-6">Лучшие инструменты категории</div>
          <div className="grid md:grid-cols-3 gap-6">
            {tools.map((t, i) => <ToolCard key={i} {...t} onClick={() => onOpenTool(t)} />)}
          </div>
        </div>

        <div className="mt-16">
          <ComparisonTable title="Сравнение ИИ для SEO" tools={["SEOlytics AI", "RankAI", "YandexSEO AI"]} rows={[
            { feature: "Кластеризация запросов", a: "Отлично", b: "Хорошо", c: "Отлично" },
            { feature: "Оптимизация под Яндекс", a: "Да", b: "Базовая", c: "Отлично" },
            { feature: "Генерация ТЗ", a: "Подробное", b: "Да", c: "Да" },
            { feature: "Цена от", a: "3 900 ₽", b: "1 800 ₽", c: "2 990 ₽" },
          ]} />
        </div>

        <div className="mt-16 glass p-8 rounded-3xl">
          <div className="font-semibold mb-4">Процесс работы с ИИ в SEO</div>
          <ol className="text-sm space-y-2.5 text-white/75 list-decimal pl-5">
            <li>Сбор семантики и кластеризация с помощью ИИ</li>
            <li>Генерация технического задания на контент</li>
            <li>Создание и оптимизация текстов</li>
            <li>Анализ конкурентов и рекомендаций</li>
            <li>Мониторинг позиций и корректировка</li>
          </ol>
        </div>

        <div className="mt-14">
          <div className="font-semibold text-xl mb-6">Часто задаваемые вопросы</div>
          <FAQ items={[
            { q: 'Насколько эффективны ИИ-тексты для SEO?', a: 'При правильной доработке и оптимизации дают рост позиций на 30–70% быстрее.' },
            { q: 'Поддержка Яндекс и Google?', a: 'Да, все инструменты учитывают особенности обоих поисковиков.' },
          ]} />
        </div>
      </div>
    </div>
  );
};

export default CategorySEO;
