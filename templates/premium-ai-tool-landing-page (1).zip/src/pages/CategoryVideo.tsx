import React from 'react';
import ToolCard from '../components/ToolCard';
import ComparisonTable from '../components/ComparisonTable';
import FAQ from '../components/FAQ';

interface Props { onOpenTool: (t: any) => void; }

const CategoryVideo: React.FC<Props> = ({ onOpenTool }) => {
  const tools = [
    { id: 'vid1', name: 'Vivid AI', description: 'Генерация видео из текста и изображений. Полная поддержка русского языка.', category: 'Видео', price: 'от 4 200 ₽', rating: 4.8, users: '6.1k', badge: 'Премиум' },
    { id: 'vid2', name: 'ClipForge', description: 'Автоматический монтаж, субтитры и анимация для коротких видео.', category: 'Монтаж', price: 'от 1 990 ₽', rating: 4.6, users: '14k' },
    { id: 'vid3', name: 'MotionAI', description: 'Генерация анимированных видео для рекламы и соцсетей.', category: 'Реклама', price: 'от 3 100 ₽', rating: 4.7, users: '4.8k' },
  ];

  return (
    <div className="min-h-screen pt-20 bg-[#0a0b0f]">
      <div className="max-w-7xl mx-auto px-8 pt-14 pb-20">
        <div className="max-w-3xl">
          <div className="uppercase text-xs tracking-[2px] text-rose-400 mb-2">КАТЕГОРИЯ</div>
          <h1 className="section-title mb-4">AI для видео</h1>
          <p className="text-lg text-white/70">Современные инструменты для генерации и обработки видео. От коротких роликов до полноценных рекламных видео и обучающего контента.</p>
        </div>

        <div className="mt-14">
          <div className="text-xl font-semibold tracking-tight mb-7">Инструменты генерации видео</div>
          <div className="grid md:grid-cols-3 gap-6">
            {tools.map((t, i) => <ToolCard key={i} {...t} onClick={() => onOpenTool(t)} />)}
          </div>
        </div>

        <div className="mt-16">
          <ComparisonTable title="Сравнение AI-видео платформ" tools={["Vivid AI", "ClipForge", "MotionAI"]} rows={[
            { feature: "Генерация из текста", a: "Да", b: "—", c: "Да" },
            { feature: "Автомонтаж", a: "Полный", b: "Отлично", c: "Базовый" },
            { feature: "Субтитры", a: "Да + перевод", b: "Да", c: "Да" },
            { feature: "Цена от", a: "4 200 ₽", b: "1 990 ₽", c: "3 100 ₽" },
          ]} />
        </div>

        <div className="mt-14">
          <div className="font-semibold text-xl mb-6">Часто задаваемые вопросы</div>
          <FAQ items={[{ q: 'Какое максимальное разрешение?', a: 'До 4K. Доступны все популярные форматы.' }, { q: 'Поддержка русского голоса?', a: 'Да, 11 голосов с натуральным произношением.' }]} />
        </div>
      </div>
    </div>
  );
};
export default CategoryVideo;