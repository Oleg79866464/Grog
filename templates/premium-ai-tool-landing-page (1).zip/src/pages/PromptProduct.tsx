import React from 'react';

interface Props { prompt: any; onNavigate: (p: string) => void; onBuy: () => void; }

const PromptProduct: React.FC<Props> = ({ prompt, onNavigate, onBuy }) => {
  const p = prompt || { title: "Продающий email для SaaS", cat: "Маркетинг", price: "290 ₽", desc: "Готовый промпт для генерации высококонверсионных писем." };

  return (
    <div className="min-h-screen pt-20 bg-[#0a0b0f]">
      <div className="max-w-4xl mx-auto px-8 py-14">
        <button onClick={() => onNavigate('prompts')} className="text-xs tracking-widest mb-9 text-white/50">← НАЗАД В МАРКЕТПЛЕЙС</button>

        <div className="glass-strong rounded-3xl px-9 py-11 border border-white/10">
          <div className="uppercase tracking-[2px] text-xs text-indigo-400 mb-2">{p.cat}</div>
          <div className="text-4xl tracking-[-0.03em] font-semibold mb-2">{p.title}</div>
          <div className="text-3xl font-semibold text-emerald-400 mb-8">{p.price}</div>

          <div className="text-lg text-white/75 leading-relaxed mb-8 max-w-2xl">{p.desc} Полностью адаптирован под российский рынок. Используйте в ChatGPT, Claude, GigaChat, YandexGPT.</div>

          <div className="grid grid-cols-2 gap-3 mb-10">
            {["Высокая конверсия", "Проверен 11k+ раз", "Готов к использованию", "Обновляется бесплатно"].map((b, i) => <div key={i} className="glass px-5 py-3.5 rounded-2xl text-sm border border-white/10">{b}</div>)}
          </div>

          <button onClick={onBuy} className="btn-primary w-full py-4 rounded-2xl font-semibold text-lg">Купить и скачать промпт</button>
          <div className="text-center text-xs mt-3 text-white/50">Мгновенная доставка • Безопасная оплата</div>
        </div>

        <div className="mt-10 text-sm text-white/60">После покупки промпт станет доступен в вашем аккаунте навсегда. Можно использовать в любых нейросетях.</div>
      </div>
    </div>
  );
};
export default PromptProduct;