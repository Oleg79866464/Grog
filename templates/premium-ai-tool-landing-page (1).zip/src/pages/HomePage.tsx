import React from 'react';
import ToolCard from '../components/ToolCard';
import TrustSignals from '../components/TrustSignals';
import FAQ from '../components/FAQ';

interface HomePageProps {
  onNavigate: (page: string) => void;
  onOpenTool: (tool: any) => void;
}

const HomePage: React.FC<HomePageProps> = ({ onNavigate, onOpenTool }) => {
  const featuredTools = [
    { id: 'neuro', name: 'NeuroCopy', description: 'Генерация продающих текстов, email-кампаний и рекламы для российского рынка с учетом локальных особенностей.', category: 'Маркетинг', price: 'от 2 900 ₽', rating: 4.9, users: '34k', badge: 'Лидер', premium: true },
    { id: 'smm', name: 'SMMForge AI', description: 'Автоматическая генерация постов, сторис и комментариев под любой бренд и аудиторию. 7 языков.', category: 'SMM', price: 'от 1 990 ₽', rating: 4.8, users: '21k', badge: 'Популярно' },
    { id: 'text', name: 'Texta Pro', description: 'Мощный генератор текстов с поддержкой 40+ стилей, SEO-оптимизации и рерайта. Интеграция с Яндексом.', category: 'Текст', price: 'Бесплатно+', rating: 4.7, users: '58k' },
  ];

  const categories = [
    { id: 'marketing', title: 'Нейросети для маркетинга', count: 48, desc: 'Контент, реклама, email, копирайтинг' },
    { id: 'smm', title: 'ИИ для SMM', count: 32, desc: 'Посты, сторис, комментарии, аналитика' },
    { id: 'textgen', title: 'Генераторы текста', count: 61, desc: 'Статьи, описания, письма, скрипты' },
    { id: 'seo', title: 'ИИ для SEO', count: 29, desc: 'Оптимизация, кластеризация, анализ' },
    { id: 'imagegen', title: 'Генераторы изображений', count: 24, desc: 'Иллюстрации, баннеры, дизайн' },
    { id: 'video', title: 'AI для видео', count: 19, desc: 'Монтаж, генерация, субтитры' },
  ];

  const faqItems = [
    { q: 'Как выбрать подходящий инструмент?', a: 'Каждый инструмент имеет подробную страницу, сравнение и реальные кейсы. Используйте фильтры и сравнительные таблицы.' },
    { q: 'Есть ли бесплатные версии?', a: 'Большинство инструментов предлагают бесплатный доступ с ограничениями. Платные тарифы начинаются от 990 ₽/мес.' },
    { q: 'Поддержка русского языка?', a: 'Все инструменты в каталоге имеют качественную поддержку русского языка и учитывают особенности рынка РФ.' },
    { q: 'Можно ли интегрировать с существующими сервисами?', a: 'Да. 87% инструментов поддерживают API, Zapier, Make и интеграцию с российскими CRM и CMS.' },
  ];

  return (
    <div className="min-h-screen pt-20 bg-[#0a0b0f]">
      {/* Hero */}
      <section className="max-w-5xl mx-auto px-8 pt-20 pb-20 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full glass text-xs tracking-[2px] mb-6 border border-white/10">ПРЕМИУМ КАТАЛОГ • С 2023 ГОДА</div>
        <h1 className="section-title text-balance max-w-4xl mx-auto mb-6">Каталог российских<br />нейросетей и ИИ-инструментов</h1>
        <p className="max-w-xl mx-auto text-lg text-white/70 mb-10">Проверенные решения для маркетинга, SMM, SEO, контента и бизнеса. 200+ инструментов. 142 800+ пользователей. Только проверенные решения с реальным ROI.</p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
          <button onClick={() => onNavigate('prompts')} className="btn-primary px-9 py-4 rounded-2xl font-semibold text-white text-[15px] flex-1 sm:flex-none">Смотреть промпты и кейсы</button>
          <button onClick={() => onNavigate('categories')} className="btn-secondary px-9 py-4 rounded-2xl font-semibold text-[15px]">Смотреть все категории</button>
        </div>

        <div className="flex justify-center gap-8 text-sm text-white/60">
          <div>Яндекс • VK • Т-Банк • Сбер • Ozon</div>
        </div>
        <div className="mt-10"><TrustSignals /></div>
      </section>

      {/* Featured Tools */}
      <section className="max-w-7xl mx-auto px-8 pb-16">
        <div className="flex items-end justify-between mb-8">
          <div>
            <div className="uppercase text-xs tracking-[2px] text-white/50 mb-1">ИЗБРАННОЕ</div>
            <div className="text-3xl font-semibold tracking-tighter">Популярные инструменты</div>
          </div>
          <button onClick={() => onNavigate('categories')} className="text-sm flex items-center gap-2 text-indigo-400 hover:text-indigo-300">Все инструменты <span>→</span></button>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {featuredTools.map((tool, i) => (
            <ToolCard key={i} {...tool} onClick={() => onOpenTool(tool)} />
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-8 py-16 border-t border-white/10">
        <div className="mb-9">
          <div className="text-xs tracking-[2px] text-white/50">ОБЗОР</div>
          <div className="section-title mt-2">Категории инструментов</div>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          {categories.map((cat, idx) => (
            <div key={idx} onClick={() => onNavigate(cat.id)} className="glass rounded-3xl p-8 cursor-pointer group border border-white/10 hover:border-white/25">
              <div className="flex justify-between items-start">
                <div>
                  <div className="font-semibold text-xl mb-1 tracking-[-0.01em] group-hover:text-indigo-400 transition-colors">{cat.title}</div>
                  <div className="text-sm text-white/60">{cat.desc}</div>
                </div>
                <div className="font-mono text-xs px-4 py-1 rounded bg-white/5 text-white/60 self-start">{cat.count}</div>
              </div>
              <div className="mt-8 text-xs uppercase tracking-[2px] text-white/50">Смотреть категорию →</div>
            </div>
          ))}
        </div>
      </section>

      {/* Commercial SEO content block */}
      <section className="max-w-5xl mx-auto px-8 py-16">
        <div className="glass rounded-3xl px-10 py-12 border border-white/10">
          <div className="uppercase tracking-[1.5px] text-xs text-indigo-400 mb-3">КОММЕРЧЕСКИЙ ОБЗОР</div>
          <h2 className="text-3xl tracking-[-0.025em] font-semibold mb-6">Почему российские компании выбирают AETHER</h2>
          <div className="prose prose-invert max-w-none text-white/75 text-[15px] leading-relaxed">
            <p>Рынок ИИ-инструментов в России за последние 3 года вырос в 9 раз. Наша команда провела аудит 400+ сервисов и отобрала только те решения, которые дают измеримый результат: рост конверсии на 22–51%, снижение затрат на контент на 67% и увеличение органического трафика в 3–4 раза.</p>
            <p className="mt-4">Все инструменты из каталога адаптированы под особенности российского рынка: Yandex, VK, Telegram, 1C, AmoCRM, Tilda. Мы проверяем качество генерации русского текста, работу с локальными SEO-факторами и соответствие 152-ФЗ.</p>
          </div>
          <button onClick={() => onNavigate('seo-content')} className="mt-8 text-sm font-medium text-white underline underline-offset-4">Читать полный коммерческий обзор →</button>
        </div>
      </section>

      {/* Benefits */}
      <section className="max-w-7xl mx-auto px-8 py-16 border-t border-white/10">
        <div className="text-center mb-12">
          <div className="text-xs tracking-widest text-white/50 mb-2">ПРЕИМУЩЕСТВА</div>
          <div className="section-title">Почему AETHER — выбор профессионалов</div>
        </div>
        <div className="grid md:grid-cols-4 gap-5">
          {[
            ["Проверенные решения", "Каждый инструмент прошёл ручной аудит качества и эффективности."],
            ["Прозрачные цены", "Актуальные тарифы и сравнение стоимости по всем планам."],
            ["Поддержка РФ", "Инструменты с фокусом на российский рынок и законодательство."],
            ["ROI-аналитика", "Встроенные расчёты и отчёты по эффективности использования."],
          ].map((b, i) => (
            <div key={i} className="glass rounded-3xl px-7 py-8 border border-white/10">
              <div className="font-semibold mb-3 text-lg tracking-tight">{b[0]}</div>
              <div className="text-sm text-white/70">{b[1]}</div>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="max-w-4xl mx-auto px-8 py-16">
        <div className="text-center mb-10">
          <div className="text-xs tracking-[2px] text-white/50 mb-2">ЧАСТО ЗАДАВАЕМЫЕ ВОПРОСЫ</div>
          <div className="section-title">Вопросы и ответы</div>
        </div>
        <FAQ items={faqItems} />
      </section>

      {/* Founder / Portfolio */}
      <section className="max-w-5xl mx-auto px-8 py-16 border-t border-white/10">
        <div className="glass rounded-3xl p-10 md:p-14 grid md:grid-cols-5 gap-x-10 gap-y-8 items-center">
          <div className="md:col-span-2">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-zinc-700 to-zinc-900 mb-7" />
            <div className="font-semibold text-2xl tracking-tight">Алексей Ветров</div>
            <div className="text-sm text-white/50 mt-1">Основатель • 11 лет в digital</div>
            <div className="mt-6 text-sm text-white/70">Бывший директор по продукту в крупном маркетинговом холдинге. Запустил 3 успешных ИИ-продукта для российского рынка.</div>
            <button onClick={() => onNavigate('contact')} className="mt-6 text-sm font-medium underline">Полное портфолио и контакты →</button>
          </div>
          <div className="md:col-span-3 text-sm text-white/70 space-y-4">
            <p>Проект AETHER создан как ответ на растущую потребность в качественном и проверенном каталоге ИИ-инструментов. Мы фокусируемся исключительно на продуктах с доказанной эффективностью, реальными отзывами и прозрачной ценовой политикой.</p>
            <p>Наша миссия — помогать бизнесу и специалистам внедрять искусственный интеллект максимально быстро и с максимальной отдачей.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
