import React, { useState } from 'react';

interface Props { onOpenPrompt: (p: any) => void; }

const PromptsMarketplace: React.FC<Props> = ({ onOpenPrompt }) => {
  const [activeCat, setActiveCat] = useState('all');

  const prompts = [
    { id: 1, title: "Продающий email для SaaS", cat: "Маркетинг", price: "290 ₽", desc: "Генерирует мощные продающие письма с высоким open rate.", badge: "Bestseller" },
    { id: 2, title: "VK посты для брендов", cat: "SMM", price: "190 ₽", desc: "30 шаблонов постов под любой бренд в соцсетях.", badge: "" },
    { id: 3, title: "SEO-статья 3000+ слов", cat: "SEO", price: "340 ₽", desc: "Полноценная экспертная статья с кластеризацией.", badge: "Топ" },
    { id: 4, title: "Рекламный текст для Директ", cat: "Реклама", price: "150 ₽", desc: "Креативы и заголовки под Яндекс.Директ.", badge: "" },
  ];

  const cats = ["all", "Маркетинг", "SMM", "SEO", "Реклама"];

  return (
    <div className="min-h-screen pt-20 bg-[#0a0b0f]">
      <div className="max-w-7xl mx-auto px-8 pt-12 pb-20">
        <div className="max-w-3xl">
          <div className="uppercase tracking-widest text-xs text-white/50">МАРКЕТПЛЕЙС</div>
          <h1 className="section-title mt-2 mb-4">Premium AI Prompts</h1>
          <p className="text-lg text-white/70">Готовые промпты для российских ИИ-инструментов. Мгновенная загрузка. Проверенная конверсия.</p>
        </div>

        <div className="flex gap-2 mt-9 mb-8 flex-wrap">
          {cats.map(c => (
            <button key={c} onClick={() => setActiveCat(c)} className={`px-5 py-1.5 rounded-full text-sm ${activeCat === c ? 'btn-primary text-white' : 'glass border border-white/10'}`}>{c === 'all' ? 'Все' : c}</button>
          ))}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
          {prompts.filter(p => activeCat === 'all' || p.cat === activeCat).map(p => (
            <div key={p.id} onClick={() => onOpenPrompt(p)} className="glass rounded-3xl p-7 cursor-pointer border border-white/10 hover:border-white/25">
              <div className="flex justify-between items-start mb-6">
                <div className="font-semibold tracking-tight text-lg leading-tight pr-3">{p.title}</div>
                {p.badge && <div className="text-[10px] px-2.5 py-px rounded-full bg-violet-500/20 text-violet-300">{p.badge}</div>}
              </div>
              <p className="text-sm text-white/70 line-clamp-3 mb-9">{p.desc}</p>
              <div className="flex justify-between items-center text-sm">
                <div><span className="text-white/50">от </span><span className="font-medium text-lg tabular-nums">{p.price}</span></div>
                <div className="text-xs text-indigo-400 font-medium">КУПИТЬ →</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
export default PromptsMarketplace;