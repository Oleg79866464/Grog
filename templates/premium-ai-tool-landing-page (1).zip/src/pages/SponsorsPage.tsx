import React from 'react';

const SponsorsPage: React.FC = () => (
  <div className="min-h-screen pt-20 bg-[#0a0b0f]">
    <div className="max-w-7xl mx-auto px-8 pt-14 pb-20">
      <div className="max-w-3xl mb-14">
        <div className="uppercase tracking-widest text-xs text-white/50">ПАРТНЁРСТВО</div>
        <h1 className="section-title mt-2 mb-4">Спонсоры и реклама</h1>
        <p className="text-xl text-white/70">Премиальные рекламные возможности для ИИ-компаний и технологических брендов на российском рынке.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="glass rounded-3xl p-9 border border-white/10">
          <div className="font-semibold text-xl mb-6">Места для спонсоров</div>
          <div className="space-y-5 text-sm">
            {["Hero-баннер (верх главной)", "Карточка в избранном", "Блок в SEO-контенте", "Партнёрская колонка в email"].map((s, i) => (
              <div key={i} className="flex justify-between items-center border-b border-white/10 pb-4 last:border-none last:pb-0"><span>{s}</span><span className="text-emerald-400">Доступно</span></div>
            ))}
          </div>
        </div>
        <div className="glass rounded-3xl p-9">
          <div className="font-semibold mb-5">Медиа-кит</div>
          <div className="text-sm text-white/75 leading-relaxed">Средний CTR — 4.8%. 142k+ пользователей. 71% аудитории из РФ. Медианная стоимость лида 189 ₽. Полный медиа-кит доступен по запросу.</div>
          <button className="mt-7 btn-secondary px-8 py-3 text-sm rounded-full">Запросить медиа-кит</button>
        </div>
      </div>

      <div className="mt-12">
        <div className="uppercase tracking-[2px] text-xs text-white/50 mb-4">НАШИ ПАРТНЁРЫ</div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {["Яндекс", "VK", "Сбер", "Т-Банк", "Ozon", "1C", "AmoCRM", "Tilda"].map((p, i) => (
            <div key={i} className="glass rounded-2xl px-8 py-8 text-center text-sm border border-white/10 font-medium">{p}</div>
          ))}
        </div>
      </div>
    </div>
  </div>
);
export default SponsorsPage;