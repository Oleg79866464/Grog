import React from 'react';

const RevenueWidgetPage: React.FC = () => (
  <div className="min-h-screen pt-20 bg-[#0a0b0f] px-6 flex items-center justify-center">
    <div className="w-full max-w-lg">
      <div className="text-center mb-6 text-xs tracking-[3px] text-white/50">ПРЕМИУМ АНАЛИТИКА</div>
      
      <div className="glass-strong rounded-3xl p-9 border border-white/10">
        <div className="flex items-center justify-between mb-9">
          <div>
            <div className="text-sm text-white/50">Оценочная прибыль (30 дней)</div>
            <div className="text-5xl font-semibold tracking-tighter mt-1 tabular-nums">₽184 920</div>
          </div>
          <div className="text-right text-xs">
            <div className="text-emerald-400">+34%</div>
            <div className="text-white/50">к прошлому месяцу</div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-9">
          <div className="border border-white/10 rounded-2xl px-5 py-4">
            <div className="text-xs text-white/50">Клики</div>
            <div className="text-2xl font-semibold mt-1">7 140</div>
          </div>
          <div className="border border-white/10 rounded-2xl px-5 py-4">
            <div className="text-xs text-white/50">Конверсия</div>
            <div className="text-2xl font-semibold mt-1">3.8%</div>
          </div>
          <div className="border border-white/10 rounded-2xl px-5 py-4">
            <div className="text-xs text-white/50">RPC</div>
            <div className="text-2xl font-semibold mt-1">₽25.9</div>
          </div>
        </div>

        <div>
          <div className="flex justify-between text-xs mb-2 text-white/60"><div>Партнёрская программа</div><div>68%</div></div>
          <div className="h-2 bg-white/10 rounded mb-8"><div className="h-2 bg-gradient-to-r from-violet-500 to-indigo-400 rounded" style={{width: '68%'}} /></div>
        </div>

        <div className="text-xs text-white/50">Прогноз на следующий месяц: <span className="text-emerald-400 font-medium">₽219 000 — ₽248 000</span></div>
      </div>
    </div>
  </div>
);
export default RevenueWidgetPage;