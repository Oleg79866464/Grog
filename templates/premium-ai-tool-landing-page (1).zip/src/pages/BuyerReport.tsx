import React from 'react';

const BuyerReport: React.FC = () => (
  <div className="min-h-screen pt-20 bg-[#0a0b0f] px-8 pb-20">
    <div className="max-w-5xl mx-auto">
      <div className="pt-10">
        <div className="inline-block px-4 py-1 text-xs tracking-[2px] rounded-full glass border border-white/10 mb-4">CONFIDENTIAL • ACQUISITION</div>
        <h1 className="text-5xl font-semibold tracking-tighter">AETHER Acquisition Report</h1>
        <div className="text-white/70 mt-1">Q1 2026 • Confidential Buyer Package</div>
      </div>

      <div className="mt-14 grid md:grid-cols-4 gap-4">
        {[
          { label: "Traffic Value", val: "₽18.4M" },
          { label: "Monetization Potential", val: "₽6.1M/yr" },
          { label: "SEO Asset Value", val: "₽9.2M" },
          { label: "Est. 3yr Growth", val: "+312%" },
        ].map((m, i) => (
          <div key={i} className="glass rounded-3xl p-7 border border-white/10">
            <div className="text-sm text-white/50">{m.label}</div>
            <div className="mt-2 text-4xl font-semibold tracking-tight">{m.val}</div>
          </div>
        ))}
      </div>

      <div className="mt-10 glass rounded-3xl p-9 border border-white/10">
        <div className="font-semibold mb-5">Executive Summary</div>
        <p className="text-[15px] leading-relaxed text-white/75">AETHER — ведущий премиальный каталог российских ИИ-инструментов. 200+ инструментов, 142k+ активных пользователей, сильная органическая видимость в Яндексе. Высокий retention и конверсия в платные подписки. Идеальный актив для стратегического инвестора или крупного игрока рынка digital-маркетинга.</p>
      </div>

      <div className="mt-8 grid md:grid-cols-2 gap-5">
        <div className="glass rounded-3xl p-8 border border-white/10">
          <div className="uppercase tracking-widest text-xs mb-4 text-white/50">Business Highlights</div>
          <ul className="space-y-3 text-sm text-white/80">
            <li>• 68% YoY revenue growth</li>
            <li>• 29% average affiliate commission</li>
            <li>• 100% organic traffic</li>
            <li>• 41% repeat visitors</li>
            <li>• 9.3% email conversion</li>
          </ul>
        </div>
        <div className="glass rounded-3xl p-8 border border-white/10">
          <div className="font-semibold mb-4">Growth Trajectory</div>
          <div className="h-36 flex items-end gap-1.5 pt-4">
            {[35, 48, 61, 55, 77, 82, 91, 100, 87, 98, 110, 124].map((v, i) => (
              <div key={i} className="flex-1 bg-gradient-to-t from-violet-500/80 to-indigo-400 rounded" style={{ height: v * 0.85 + '%' }} />
            ))}
          </div>
        </div>
      </div>
    </div>
  </div>
);
export default BuyerReport;