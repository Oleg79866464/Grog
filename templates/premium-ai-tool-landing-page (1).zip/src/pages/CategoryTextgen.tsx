import React from 'react';
import ToolCard from '../components/ToolCard';
import ComparisonTable from '../components/ComparisonTable';
import FAQ from '../components/FAQ';

interface Props { onOpenTool: (t: any) => void; }

const CategoryTextgen: React.FC<Props> = ({ onOpenTool }) => {
  const tools = [
    { id: 'txt1', name: 'Texta Pro', description: 'Мощный генератор текстов с поддержкой 40+ стилей и SEO-оптимизацией. Лучший русский язык.', category: 'Текст', price: 'Бесплатно+', rating: 4.7, users: '58k', badge: 'Топ' },
    { id: 'txt2', name: 'RussText AI', description: 'Специализированный генератор для сложных длинных текстов, рерайт и адаптация под бренд.', category: 'Рерайт', price: 'от 2 100 ₽', rating: 4.8, users: '14k' },
    { id: 'txt3', name: 'Scriptly', description: 'Генератор продающих скриптов, коммерческих предложений и презентаций.', category: 'Бизнес', price: 'от 1 650 ₽', rating: 4.5, users: '11k' },
  ];

  return (
    <div className="min-h-screen pt-20 bg-[#0a0b0f]">
      <div className="max-w-7xl mx-auto px-8 pt-14 pb-20">
        <div className="max-w-4xl">
          <div className="uppercase tracking-[3px] text-xs text-white/50 mb-3">КАТЕГОРИЯ</div>
          <h1 className="section-title mb-4">Генератор текста</h1>
          <p className="text-lg text-white/70">Профессиональные нейросети для генерации текстов любой сложности. От коротких описаний товаров до полноценных статей и коммерческих предложений. Качество выше, чем у большинства зарубежных аналогов.</p>
        </div>

        <div className="mt-12">
          <div className="font-semibold text-xl mb-6">Популярные инструменты</div>
          <div className="grid md:grid-cols-3 gap-6">
            {tools.map((t, i) => <ToolCard key={i} {...t} onClick={() => onOpenTool(t)} />)}
          </div>
        </div>

        <div className="mt-16">
          <div className="font-semibold text-2xl tracking-tighter mb-7">Сравнение генераторов текста</div>
          <ComparisonTable title="Сравнение" tools={["Texta Pro", "RussText AI", "Scriptly"]} rows={[
            { feature: "Качество русского языка", a: "Отлично", b: "Отлично", c: "Хорошо" },
            { feature: "SEO-оптимизация", a: "Да + анализ", b: "Да", c: "Базовая" },
            { feature: "Максимальная длина", a: "25 000 зн.", b: "40 000 зн.", c: "12 000 зн." },
            { feature: "Цена", a: "Бесплатно+", b: "2 100 ₽", c: "1 650 ₽" },
          ]} />
        </div>

        <div className="mt-16 glass p-9 rounded-3xl">
          <h3 className="font-semibold mb-4">Примеры использования</h3>
          <ul className="grid md:grid-cols-2 gap-x-12 gap-y-2 text-sm text-white/75 list-none">
            <li>Статьи для блогов и СМИ</li>
            <li>Товарные описания для Wildberries и Ozon</li>
            <li>Коммерческие предложения</li>
            <li>Сценарии видео и подкастов</li>
            <li>Пресс-релизы и официальные тексты</li>
            <li>Тексты для лендингов и email</li>
          </ul>
        </div>

        <div className="mt-16">
          <div className="font-semibold text-xl mb-6">Часто задаваемые вопросы</div>
          <FAQ items={[
            { q: 'Можно ли обучить модель под стиль бренда?', a: 'Да. Большинство инструментов поддерживают загрузку примеров и дообучение.' },
            { q: 'Есть ли плагиат?', a: 'Генерация уникальна. Проверяем через сервисы. Средний уровень уникальности — 96%.' },
          ]} />
        </div>
      </div>
    </div>
  );
};

export default CategoryTextgen;
