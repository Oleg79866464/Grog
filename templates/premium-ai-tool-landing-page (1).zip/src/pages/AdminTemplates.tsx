import React, { useState } from 'react';

const AdminTemplates: React.FC = () => {
  const [activeId, setActiveId] = useState(1);

  const templates = [
    { id: 1, name: "Главная страница", type: "Landing", version: "v2.4", status: "Активен", updated: "2 дня назад" },
    { id: 2, name: "Категория: Маркетинг", type: "Category", version: "v1.9", status: "Активен", updated: "1 нед. назад" },
    { id: 3, name: "Страница инструмента", type: "Tool", version: "v3.1", status: "Черновик", updated: "5 дней назад" },
    { id: 4, name: "Страница Prompts", type: "Marketplace", version: "v1.2", status: "Активен", updated: "3 нед. назад" },
  ];

  return (
    <div className="min-h-screen pt-20 bg-[#0a0b0f] px-8 pb-20">
      <div className="max-w-6xl mx-auto">
        <div className="pt-8 pb-9">
          <div className="text-xs tracking-[3px] text-white/50">АДМИН • ШАБЛОНЫ</div>
          <div className="text-4xl font-semibold tracking-tighter mt-1">Управление шаблонами</div>
        </div>

        <div className="grid md:grid-cols-2 gap-5">
          {templates.map(t => (
            <div key={t.id} className={`glass rounded-3xl p-7 border ${activeId === t.id ? 'border-indigo-400' : 'border-white/10'}`}>
              <div className="flex justify-between">
                <div>
                  <div className="font-semibold text-xl tracking-tight">{t.name}</div>
                  <div className="text-xs text-white/50 mt-1">{t.type} • {t.version}</div>
                </div>
                <div className={`text-xs px-3 py-1 rounded-full self-start ${t.status === 'Активен' ? 'bg-emerald-500/15 text-emerald-400' : 'bg-white/10 text-white/70'}`}>{t.status}</div>
              </div>
              <div className="mt-9 text-xs text-white/50">Обновлено: {t.updated}</div>

              <div className="mt-6 flex gap-3">
                <button onClick={() => setActiveId(t.id)} className={`flex-1 py-2.5 rounded-xl text-sm ${activeId === t.id ? 'btn-primary' : 'glass border border-white/10'}`}>{activeId === t.id ? 'Текущий активный' : 'Сделать активным'}</button>
                <button className="px-5 py-2.5 rounded-xl glass text-sm border border-white/10">Предпросмотр</button>
              </div>
            </div>
          ))}
        </div>

        <div className="text-xs text-white/40 mt-8">Все изменения автоматически публикуются в продакшн. История версий сохранена.</div>
      </div>
    </div>
  );
};
export default AdminTemplates;