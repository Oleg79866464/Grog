import React from 'react';
import FAQ from '../components/FAQ';

interface Props { tool: any; onNavigate: (p: string) => void; onGoToRedirect: () => void; }

const ToolDetailPage: React.FC<Props> = ({ tool, onNavigate, onGoToRedirect }) => {
  const defaultTool = { name: 'NeuroCopy', description: 'Профессиональный генератор текстов и маркетингового контента.', category: 'Маркетинг', price: 'от 2 900 ₽', rating: 4.9, users: '34k' };
  const t = tool || defaultTool;

  return (
    <div className="min-h-screen pt-20 bg-[#0a0b0f]">
      <div className="max-w-5xl mx-auto px-8 pt-12 pb-20">
        <button onClick={() => onNavigate('home')} className="text-xs tracking-widest text-white/50 mb-6">← ВЕРНУТЬСЯ В КАТАЛОГ</button>

        <div className="flex flex-col lg:flex-row gap-10">
          {/* Main info */}
          <div className="flex-1">
            <div className="inline px-4 py-1 text-xs rounded-full glass mb-4 border border-white/10">{t.category}</div>
            <h1 className="text-5xl font-semibold tracking-tighter mb-4">{t.name}</h1>
            <p className="text-xl text-white/70 mb-7 max-w-2xl">{t.description}</p>

            <div className="flex items-center gap-4 mb-9">
              <div className="text-4xl font-semibold tabular-nums">{t.price}</div>
              <div className="px-4 py-1 text-xs rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">ПОПУЛЯРНЫЙ ВЫБОР</div>
            </div>

            <div className="flex gap-3">
              <button onClick={onGoToRedirect} className="btn-primary px-10 py-4 rounded-2xl font-semibold">Перейти на сайт инструмента</button>
              <button onClick={() => onNavigate('prompts')} className="btn-secondary px-8 py-4 rounded-2xl font-medium">Смотреть готовые промпты</button>
            </div>

            <div className="mt-10 text-sm flex items-center gap-6 text-white/50">
              <div>Рейтинг: <span className="text-white">{t.rating}</span></div>
              <div>Пользователей: <span className="text-white">{t.users}</span></div>
              <div>Обновлено: январь 2026</div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:w-80">
            <div className="glass rounded-3xl p-7 border border-white/10">
              <div className="uppercase text-xs tracking-widest text-white/50 mb-5">Информация</div>
              <div className="space-y-4 text-sm">
                <div className="flex justify-between"><span className="text-white/60">Категория</span><span>{t.category}</span></div>
                <div className="flex justify-between"><span className="text-white/60">Цена</span><span>{t.price}</span></div>
                <div className="flex justify-between"><span className="text-white/60">Платформа</span><span>Web / API</span></div>
                <div className="flex justify-between"><span className="text-white/60">Интеграции</span><span>12+</span></div>
                <div className="flex justify-between"><span className="text-white/60">Язык</span><span>Русский + EN</span></div>
              </div>
            </div>

            <div className="glass rounded-3xl mt-5 p-7 text-sm border border-white/10">
              <div className="font-medium mb-4">Ключевые преимущества</div>
              <ul className="space-y-2 text-white/70">
                <li>• Высококачественный русский язык</li>
                <li>• Более 40 готовых шаблонов</li>
                <li>• Интеграция с CRM и рекламы</li>
                <li>• API и Zapier</li>
                <li>• Поддержка 152-ФЗ</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Use cases */}
        <div className="mt-16">
          <div className="text-xl font-semibold tracking-tight mb-6">Сценарии применения</div>
          <div className="grid md:grid-cols-3 gap-4">
            {["Email-кампании", "Рекламные тексты", "Контент для соцсетей", "Продающие описания", "Скрипты и презентации", "SEO-статьи"].map((u, i) => (
              <div key={i} className="glass rounded-2xl px-7 py-6 text-sm border border-white/10">{u}</div>
            ))}
          </div>
        </div>

        {/* Affiliate redirect CTA */}
        <div className="mt-16 glass-strong rounded-3xl p-9 flex flex-col md:flex-row gap-8 items-center justify-between border border-white/10">
          <div>
            <div className="font-semibold text-2xl tracking-tight">Готовы начать работу?</div>
            <div className="text-white/70 mt-1">Перейдите на сайт инструмента с помощью нашего партнёрского редиректа. Мы отслеживаем качество и предоставляем поддержку.</div>
          </div>
          <button onClick={onGoToRedirect} className="btn-primary px-10 py-3.5 rounded-2xl font-semibold whitespace-nowrap">Перейти на сайт →</button>
        </div>

        <div className="mt-16 max-w-3xl">
          <div className="font-semibold text-2xl tracking-tighter mb-6">Отзывы и кейсы</div>
          <div className="text-sm text-white/70 space-y-7">
            <div>“NeuroCopy увеличил конверсию нашего email-канала на 48% за 2 месяца. Очень качественный русский текст.” — <span className="text-white/90">Мария К., Head of Marketing, RetailTech</span></div>
            <div>“Простой интерфейс и отличная интеграция с AmoCRM. Рекомендую.” — <span className="text-white/90">Андрей Л., CEO, FinLead</span></div>
          </div>
        </div>

        <div className="mt-16">
          <div className="font-semibold tracking-tight text-xl mb-6">Часто задаваемые вопросы</div>
          <FAQ items={[
            { q: 'Есть ли бесплатный период?', a: 'Да, 14 дней полного доступа ко всем функциям.' },
            { q: 'Можно ли отменить подписку?', a: 'Да, в любой момент. Сохранение данных до 90 дней.' },
          ]} />
        </div>
      </div>
    </div>
  );
};
export default ToolDetailPage;