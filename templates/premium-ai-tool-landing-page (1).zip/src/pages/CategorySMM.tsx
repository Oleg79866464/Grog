import React from 'react';
import ToolCard from '../components/ToolCard';
import ComparisonTable from '../components/ComparisonTable';
import FAQ from '../components/FAQ';

interface Props { onOpenTool: (t: any) => void; }

const CategorySMM: React.FC<Props> = ({ onOpenTool }) => {
  const tools = [
    { id: 'smm1', name: 'SMMForge AI', description: 'Генерация контента для всех соцсетей. Автоматические ответы и анализ конкурентов.', category: 'SMM', price: 'от 1 990 ₽', rating: 4.8, users: '21k', badge: 'Популярно' },
    { id: 'smm2', name: 'PostMaster AI', description: 'Планирование и генерация постов для Instagram, VK и Telegram. Авто-публикации.', category: 'Контент', price: 'от 1 490 ₽', rating: 4.6, users: '18k' },
    { id: 'smm3', name: 'ViralPulse', description: 'Анализ вирусности контента и генерация трендовых идей для SMM.', category: 'Аналитика', price: 'от 2 400 ₽', rating: 4.9, users: '9k', badge: 'Новый' },
  ];

  const examples = ["Создание 30 постов в месяц для 5 аккаунтов", "Генерация комментариев и ответов на отзывы", "Анализ вовлеченности и предложений по контенту", "Автоматическая адаптация под каждый соц. канал"];

  return (
    <div className="min-h-screen pt-20 bg-[#0a0b0f]">
      <div className="max-w-7xl mx-auto px-8 pt-14 pb-20">
        <div className="max-w-3xl">
          <div className="text-xs tracking-[3px] text-violet-400 mb-2">КАТЕГОРИЯ</div>
          <h1 className="section-title mb-4">ИИ для SMM</h1>
          <p className="text-xl text-white/70">Инструменты для автоматизации SMM: генерация постов, сторис, комментариев и аналитика эффективности. Экономия до 30 часов в неделю.</p>
        </div>

        <div className="mt-12 grid md:grid-cols-2 gap-5">
          {examples.map((ex, i) => (
            <div key={i} className="glass rounded-2xl px-7 py-6 text-sm border border-white/10">{ex}</div>
          ))}
        </div>

        <div className="mt-16">
          <div className="font-semibold text-2xl tracking-tight mb-8">Инструменты для SMM-специалистов</div>
          <div className="grid md:grid-cols-3 gap-6">
            {tools.map((t, i) => <ToolCard key={i} {...t} onClick={() => onOpenTool(t)} />)}
          </div>
        </div>

        <div className="mt-16">
          <ComparisonTable 
            title="Сравнение решений для SMM" 
            tools={["SMMForge AI", "PostMaster AI", "ViralPulse"]} 
            rows={[
              { feature: "Генерация постов", a: "✓ 50+/день", b: "✓ 35+/день", c: "✓ Идеи + текст" },
              { feature: "Аналитика", a: "Полная", b: "Базовая", c: "Глубокая" },
              { feature: "Автопубликации", a: "Да", b: "Да", c: "— (экспорт)" },
              { feature: "Цена", a: "1 990 ₽", b: "1 490 ₽", c: "2 400 ₽" },
            ]} 
          />
        </div>

        <div className="mt-16 max-w-4xl">
          <div className="font-semibold tracking-tight text-xl mb-6">Часто задаваемые вопросы</div>
          <FAQ items={[
            { q: 'Можно ли подключить несколько аккаунтов?', a: 'Да, до 25 аккаунтов в одном проекте. Поддерживаются Instagram, VK, Telegram и Threads.' },
            { q: 'Есть ли защита от банов?', a: 'Система имитирует поведение человека. Более 94% аккаунтов работают стабильно более 6 месяцев.' },
          ]} />
        </div>
      </div>
    </div>
  );
};

export default CategorySMM;
