export type Tool = {
  id: string;
  name: string;
  tagline: string;
  description: string;
  category: string;
  tags: string[];
  pricing: string;
  rating: number;
  users: string;
  logo?: string;
  logoColor?: string;
  features?: string[];
  url?: string;
};

export const tools: Tool[] = [
  {
    id: "yandexgpt",
    name: "YandexGPT",
    tagline: "Корпоративная нейросеть от Яндекса",
    description: "Семейство больших языковых моделей с глубокой интеграцией в экосистему Яндекса, API для бизнеса и приватным развёртыванием.",
    category: "Генератор текста",
    tags: ["LLM", "API", "On-prem", "Русский язык"],
    pricing: "Бесплатно / от 480 ₽",
    rating: 4.8,
    users: "1.2M+",
    logoColor: "from-red-500 to-yellow-400",
    features: ["Русский язык", "API", "Интеграции", "Приватность"],
    url: "yandexgpt",
  },
  {
    id: "giga-chat",
    name: "GigaChat",
    tagline: "Мультимодальная нейросеть от Сбера",
    description: "Универсальный ИИ-ассистент для бизнеса и разработки с поддержкой документов, изображений и голоса.",
    category: "Генератор текста",
    tags: ["LLM", "Мультимодальная", "B2B"],
    pricing: "от 1 990 ₽",
    rating: 4.7,
    users: "850K+",
    logoColor: "from-emerald-400 to-teal-500",
    features: ["Мультимодальность", "B2B", "SberID"],
    url: "giga-chat",
  },
  {
    id: "kandinsky",
    name: "Kandinsky",
    tagline: "Генератор изображений от Сбера",
    description: "Генеративная модель текст-в-изображение с поддержкой русского языка, кисти и контура.",
    category: "Генератор изображений",
    tags: ["Изображения", "Русский", "API"],
    pricing: "от 6 ₽/изобр.",
    rating: 4.6,
    users: "600K+",
    logoColor: "from-amber-400 to-pink-500",
    features: ["Фотореализм", "Русский", "API"],
    url: "kandinsky",
  },
  {
    id: "sber-sound",
    name: "Sber Sound",
    tagline: "Генерация музыки и голоса",
    description: "Синтез речи, клонирование голоса и создание музыкальных треков по текстовому описанию.",
    category: "AI для видео",
    tags: ["TTS", "Голос", "Музыка"],
    pricing: "от 90 ₽",
    rating: 4.4,
    users: "120K+",
    logoColor: "from-orange-400 to-rose-500",
    features: ["TTS", "Клонирование", "API"],
    url: "sber-sound",
  },
  {
    id: "shedevrum",
    name: "Шедеврум",
    tagline: "Генерация изображений от Яндекса",
    description: "Народный генератор картинок: быстро, бесплатно, с русскими промптами и стилями.",
    category: "Генератор изображений",
    tags: ["Изображения", "Бесплатно"],
    pricing: "Бесплатно",
    rating: 4.5,
    users: "2.4M+",
    logoColor: "from-yellow-400 to-orange-500",
    features: ["Бесплатно", "Русский", "Простой UX"],
    url: "shedevrum",
  },
  {
    id: "neuro-coder",
    name: "NeuroCoder",
    tagline: "ИИ-программист для команд",
    description: "Пишет, рефакторит и тестирует код в вашем репозитории, понимает контекст проекта.",
    category: "ИИ для бизнеса",
    tags: ["Code", "IDE", "Автотесты"],
    pricing: "от 4 900 ₽",
    rating: 4.7,
    users: "75K+",
    logoColor: "from-indigo-400 to-violet-500",
    features: ["Git", "IDE-плагины", "On-prem"],
    url: "neuro-coder",
  },
  {
    id: "contentmind",
    name: "ContentMind",
    tagline: "Контент-маркетинг на автомате",
    description: "Планирует редакционный календарь, пишет SEO-статьи и адаптирует под любые каналы.",
    category: "ИИ для контента",
    tags: ["SEO", "Статьи", "Календарь"],
    pricing: "от 3 900 ₽",
    rating: 4.6,
    users: "180K+",
    logoColor: "from-cyan-400 to-blue-500",
    features: ["SEO", "Планировщик", "Мультиканальность"],
    url: "contentmind",
  },
  {
    id: "seo-pilot",
    name: "SEOPilot",
    tagline: "Автоматическое продвижение",
    description: "Аудит сайта, кластеризация запросов, генерация метатегов и внутренняя перелинковка.",
    category: "ИИ для SEO",
    tags: ["SEO", "Аудит", "Яндекс"],
    pricing: "от 5 900 ₽",
    rating: 4.8,
    users: "240K+",
    logoColor: "from-fuchsia-400 to-purple-500",
    features: ["Аудит", "Кластеры", "Яндекс.Вебмастер"],
    url: "seo-pilot",
  },
  {
    id: "smm-oracle",
    name: "SMM Oracle",
    tagline: "ИИ-стратегия для соцсетей",
    description: "Генерирует контент-план, креативы и рекламные кампании под VK, Telegram и Дзен.",
    category: "ИИ для SMM",
    tags: ["SMM", "VK", "Telegram"],
    pricing: "от 2 900 ₽",
    rating: 4.5,
    users: "110K+",
    logoColor: "from-pink-400 to-rose-500",
    features: ["VK", "Telegram", "Таргет"],
    url: "smm-oracle",
  },
  {
    id: "marketmind",
    name: "MarketMind",
    tagline: "Прогнозирование спроса и аналитика",  
    description: "ML-модели для прогноза продаж, сегментации аудитории и динамического ценообразования.",
    category: "Нейросети для маркетинга",
    tags: ["ML", "Прогнозы", "Ценообразование"],
    pricing: "По запросу",
    rating: 4.7,
    users: "320+",
    logoColor: "from-emerald-400 to-cyan-500",
    features: ["ML", "B2B", "Enterprise"],
    url: "marketmind",
  },
  {
    id: "videoforge",
    name: "VideoForge",
    tagline: "Видео по текстовому сценарию",
    description: "Собирает видеоролики из генеративных клипов, озвучки и субтитров за несколько минут.",
    category: "AI для видео",
    tags: ["Видео", "T2V", "Субтитры"],
    pricing: "от 1 500 ₽",
    rating: 4.5,
    users: "60K+",
    logoColor: "from-red-500 to-orange-500",
    features: ["T2V", "Автосубтитры", "Озвучка"],
    url: "videoforge",
  },
  {
    id: "bizsight",
    name: "BizSight",
    tagline: "Аналитическая платформа для бизнеса",
    description: "BI-дашборды нового поколения: ИИ интерпретирует данные и подсказывает гипотезы.",
    category: "ИИ для бизнеса",
    tags: ["BI", "Dashboards", "SQL"],
    pricing: "от 9 900 ₽",
    rating: 4.6,
    users: "1.4K+",
    logoColor: "from-blue-400 to-indigo-500",
    features: ["BI", "Dashboards", "SQL-помощник"],
    url: "bizsight",
  },
];

export const featuredTools = tools.slice(0, 6);

export const categories = [
  { id: "marketing", name: "Нейросети для маркетинга", count: 38, icon: "M" },
  { id: "smm", name: "ИИ для SMM", count: 27, icon: "S" },
  { id: "text", name: "Генераторы текста", count: 54, icon: "T" },
  { id: "seo", name: "ИИ для SEO", count: 19, icon: "S" },
  { id: "content", name: "ИИ для контента", count: 41, icon: "C" },
  { id: "image", name: "Генераторы изображений", count: 33, icon: "I" },
  { id: "video", name: "ИИ для видео", count: 22, icon: "V" },
  { id: "business", name: "ИИ для бизнеса", count: 47, icon: "B" },
];

export const prompts = [
  { id: "seo-pack", title: "SEO-промпты для генерации кластеров", category: "SEO", price: 1490, description: "Пакет из 80 промптов для кластеризации запросов и написания метатегов." },
  { id: "smo-pack", title: "Пакет промптов для SMM-аккаунта", category: "SMM", price: 990, description: "Готовые скрипты для постов, сторис и реакций в Telegram и VK." },
  { id: "design-pack", title: "Промпты для Midjourney v7", category: "Image", price: 2490, description: "200 промптов для реалистичной фоторекламы и брендинга." },
  { id: "video-pack", title: "Видео-промпты для Runway", category: "Video", price: 1790, description: "120 сценарных промптов и лутков для короткого видео." },
  { id: "code-pack", title: "Промпты для Code Assistants", category: "Dev", price: 1990, description: "Системные промпты для рефакторинга, документирования и тестов." },
  { id: "sales-pack", title: "Промпты для cold-рассылок", category: "Sales", price: 1290, description: "60 промптов для персонализации коммерческих предложений." },
];

export function findTool(id: string) {
  return tools.find((t) => t.id === id);
}
