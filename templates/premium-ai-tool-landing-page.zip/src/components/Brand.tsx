import { Link } from "react-router-dom";

export function Logo({ size = "md" }: { size?: "sm" | "md" | "lg" }) {
  const sizes = {
    sm: "h-7 w-7",
    md: "h-8 w-8",
    lg: "h-10 w-10",
  };
  return (
    <Link to="/" className="group inline-flex items-center gap-2.5">
      <div className={`${sizes[size]} relative rounded-xl bg-gradient-to-br from-violet-500 via-indigo-500 to-cyan-400 p-[1px] glow-violet`}>
        <div className="flex h-full w-full items-center justify-center rounded-[10px] bg-[#0a0c12]">
          <svg viewBox="0 0 24 24" className="h-1/2 w-1/2 text-violet-400" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 2L2 7l10 5 10-5-10-5z" />
            <path d="M2 17l10 5 10-5" />
            <path d="M2 12l10 5 10-5" />
          </svg>
        </div>
      </div>
      <div className="flex flex-col leading-none">
        <span className="text-[15px] font-semibold tracking-tight text-white">AINexus</span>
        <span className="text-[10px] font-medium uppercase tracking-[0.2em] text-white/40">AI Directory</span>
      </div>
    </Link>
  );
}
