import { Link } from "react-router-dom";
import { ArrowUpRight, Check, Star, Sparkles, Shield, Zap, TrendingUp } from "lucide-react";
import type { Tool } from "../data/tools";
import { cn } from "../utils/cn";

export function ToolIcon({ tool }: { tool: Tool }) {
  return (
    <div className={cn("relative shrink-0 rounded-xl bg-gradient-to-br p-[1.5px]", tool.logoColor || "from-violet-500 to-blue-500")}>
      <div className={cn("flex h-full w-full items-center justify-center rounded-[10px] bg-[#0a0c12]")}>
        <span className="font-semibold tracking-tight text-white/90">
          {tool.name.slice(0, 2).toUpperCase()}
        </span>
      </div>
    </div>
  );
}

export function ToolCard({ tool, variant = "default" }: { tool: Tool; variant?: "default" | "compact" }) {
  const compact = variant === "compact";
  return (
    <Link
      to={`/tool/${tool.id}`}
      className="glass-card glass-card-hover group relative flex flex-col gap-4 p-5"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <ToolIcon tool={tool} />
          <div>
            <h3 className="text-[15px] font-semibold tracking-tight text-white">{tool.name}</h3>
            <p className="text-[12px] text-white/50">{tool.tagline}</p>
          </div>
        </div>
        <ArrowUpRight className="h-4 w-4 shrink-0 text-white/30 transition-all group-hover:text-white/80 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
      </div>
      {!compact && (
        <p className="text-[13px] leading-relaxed text-white/60 line-clamp-2">{tool.description}</p>
      )}
      <div className="mt-auto flex items-center justify-between gap-2 pt-1">
        <div className="flex items-center gap-2 text-[11px] text-white/55">
          <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
          <span className="font-medium text-white/80">{tool.rating}</span>
          <span>·</span>
          <span className="hidden sm:inline">{tool.users} пользователей</span>
        </div>
        <span className="badge text-[10px]">{tool.pricing}</span>
      </div>
      {!compact && (
        <div className="flex flex-wrap gap-1.5">
          {tool.tags.map((t) => (
            <span key={t} className="badge text-[10px]">{t}</span>
          ))}
        </div>
      )}
    </Link>
  );
}

export function TrustBar() {
  const logos = ["Яндекс", "Сбер", "VK", "Альфа-Банк", "Тинькофф", "МТС", "Магнит", "Ozon"];
  return (
    <div className="flex flex-wrap items-center justify-between gap-x-12 gap-y-6 opacity-60">
      {logos.map((l) => (
        <div key={l} className="text-[13px] font-semibold tracking-tight text-white/40">{l}</div>
      ))}
    </div>
  );
}

export function FAQBlock({ items }: { items: { q: string; a: string }[] }) {
  return (
    <div className="glass-card divide-y divide-white/[0.05] overflow-hidden">
      {items.map((it, i) => (
        <details key={i} className="group">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-4 px-6 py-5 text-[14px] font-medium text-white transition-colors hover:bg-white/[0.02]">
            {it.q}
            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-white/10 text-white/60 transition-transform group-open:rotate-45">
              <span className="text-base leading-none">+</span>
            </div>
          </summary>
          <div className="px-6 pb-5 pr-14 text-[13px] leading-relaxed text-white/55">{it.a}</div>
        </details>
      ))}
    </div>
  );
}

export function FeatureRow({
  icon: Icon,
  title,
  description,
}: {
  icon: typeof Sparkles;
  title: string;
  description: string;
}) {
  return (
    <div className="flex gap-4">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/[0.03] text-violet-300">
        <Icon className="h-4 w-4" />
      </div>
      <div>
        <h4 className="text-[14px] font-semibold tracking-tight text-white">{title}</h4>
        <p className="mt-1 text-[13px] leading-relaxed text-white/55">{description}</p>
      </div>
    </div>
  );
}

export function ComparisonTable({ rows }: { rows: { feature: string; a: string; b: string }[] }) {
  return (
    <div className="glass-card overflow-hidden">
      <div className="grid grid-cols-[1fr_1fr_1fr] border-b border-white/[0.06] bg-white/[0.02] px-6 py-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-white/60">
        <div>Характеристика</div>
        <div>Лидер категории</div>
        <div className="text-white/40">Альтернатива</div>
      </div>
      {rows.map((r, i) => (
        <div
          key={i}
          className="grid grid-cols-[1fr_1fr_1fr] border-b border-white/[0.04] px-6 py-4 text-[13px] last:border-b-0 hover:bg-white/[0.02]"
        >
          <div className="text-white/80">{r.feature}</div>
          <div className="flex items-center gap-2 text-white/85">
            <Check className="h-3.5 w-3.5 text-emerald-400" /> {r.a}
          </div>
          <div className="flex items-center gap-2 text-white/45">{r.b}</div>
        </div>
      ))}
    </div>
  );
}

export function PageHero({
  eyebrow,
  title,
  description,
  primaryCta,
  secondaryCta,
  children,
}: {
  eyebrow?: string;
  title: React.ReactNode;
  description: React.ReactNode;
  primaryCta?: { label: string; href: string };
  secondaryCta?: { label: string; href: string };
  children?: React.ReactNode;
}) {
  return (
    <section className="relative overflow-hidden border-b border-white/[0.04]">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-0 h-[420px] w-[820px] -translate-x-1/2 rounded-full bg-violet-600/15 blur-[120px]" />
        <div className="absolute left-1/2 top-1/3 h-[260px] w-[360px] -translate-x-1/3 rounded-full bg-blue-500/10 blur-[90px]" />
      </div>
      <div className="mx-auto max-w-5xl px-6 pt-20 pb-16 text-center">
        {eyebrow && <div className="section-eyebrow">{eyebrow}</div>}
        <h1 className="mt-4 text-balance text-4xl font-semibold leading-[1.05] tracking-tight text-gradient sm:text-5xl md:text-6xl">
          {title}
        </h1>
        <p className="mx-auto mt-5 max-w-2xl text-pretty text-[15px] leading-relaxed text-white/55 sm:text-[16px]">
          {description}
        </p>
        {(primaryCta || secondaryCta) && (
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            {primaryCta && (
              <Link to={primaryCta.href} className="btn-primary">
                {primaryCta.label}
                <ArrowUpRight className="h-3.5 w-3.5" />
              </Link>
            )}
            {secondaryCta && (
              <Link to={secondaryCta.href} className="btn-secondary">
                {secondaryCta.label}
              </Link>
            )}
          </div>
        )}
        {children}
      </div>
    </section>
  );
}

export function TrustBadges() {
  return (
    <div className="grid grid-cols-3 gap-px overflow-hidden rounded-2xl border border-white/[0.05] bg-white/[0.02] sm:grid-cols-6">
      {[
        { icon: Shield, label: "GDPR", sub: "Соответствие" },
        { icon: Zap, label: "SLA 99.9%", sub: "Доступность" },
        { icon: TrendingUp, label: "+38%", sub: "Конверсия" },
        { icon: Sparkles, label: "152", sub: "Инструментов" },
        { icon: Star, label: "4.7", sub: "Рейтинг" },
        { icon: Check, label: "1.2M+", sub: "Пользователей" },
      ].map((b) => (
        <div key={b.label} className="flex flex-col items-center gap-1.5 bg-[#06070b] px-4 py-5">
          <b.icon className="h-4 w-4 text-violet-300" />
          <div className="text-[13px] font-semibold text-white">{b.label}</div>
          <div className="text-[10px] uppercase tracking-[0.18em] text-white/35">{b.sub}</div>
        </div>
      ))}
    </div>
  );
}
