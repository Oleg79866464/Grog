import { Link, NavLink, useLocation } from "react-router-dom";
import { Logo } from "./Brand";
import { Search, ArrowUpRight, Menu, X, ChevronDown } from "lucide-react";
import { useState } from "react";
import { cn } from "../utils/cn";

const navItems = [
  { label: "Каталог", href: "/", type: "route" as const, dropdown: [
    { label: "Нейросети для маркетинга", href: "/category/marketing" },
    { label: "ИИ для SMM", href: "/category/smm" },
    { label: "Генераторы текста", href: "/category/text" },
    { label: "ИИ для SEO", href: "/category/seo" },
    { label: "ИИ для контента", href: "/category/content" },
    { label: "Генераторы изображений", href: "/category/image" },
    { label: "ИИ для видео", href: "/category/video" },
    { label: "ИИ для бизнеса", href: "/category/business" },
  ]},
  { label: "Промпты", href: "/prompts", type: "route" as const },
  { label: "Аналитика", href: "/admin/analytics", type: "route" as const },
  { label: "Для партнёров", href: "/sponsors", type: "route" as const },
];

export function Header() {
  const [open, setOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const location = useLocation();

  return (
    <header className="sticky top-0 z-50 border-b border-white/[0.05] bg-[#06070b]/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        <div className="flex items-center gap-10">
          <Logo />
          <nav className="hidden items-center gap-1 lg:flex">
            {navItems.map((item) => (
              <div
                key={item.label}
                className="relative"
                onMouseEnter={() => item.dropdown && setOpenDropdown(item.label)}
                onMouseLeave={() => setOpenDropdown(null)}
              >
                <NavLink
                  to={item.href}
                  className={({ isActive }) =>
                    cn(
                      "relative inline-flex items-center gap-1 rounded-lg px-3 py-2 text-[13px] font-medium transition-colors",
                      isActive || location.pathname.startsWith(item.href + "/")
                        ? "text-white"
                        : "text-white/60 hover:text-white"
                    )
                  }
                >
                  {item.label}
                  {item.dropdown && <ChevronDown className="h-3.5 w-3.5 opacity-60" />}
                </NavLink>
                {item.dropdown && openDropdown === item.label && (
                  <div className="absolute left-0 top-full pt-2">
                    <div className="glass-card min-w-[260px] p-2">
                      {item.dropdown.map((sub) => (
                        <Link
                          key={sub.label}
                          to={sub.href}
                          className="block rounded-lg px-3 py-2 text-[13px] text-white/70 transition-colors hover:bg-white/5 hover:text-white"
                        >
                          {sub.label}
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </nav>
        </div>

        <div className="hidden items-center gap-2 md:flex">
          <button className="inline-flex h-9 items-center gap-2 rounded-lg border border-white/10 bg-white/[0.03] px-3 text-[12px] text-white/50 transition-colors hover:border-white/20 hover:bg-white/[0.06]">
            <Search className="h-3.5 w-3.5" />
            Поиск инструментов
            <span className="ml-8 rounded bg-white/10 px-1.5 py-0.5 text-[10px] tracking-wider text-white/60">⌘K</span>
          </button>
          <Link to="/contact" className="btn-secondary text-[12px]">
            Связаться
            <ArrowUpRight className="h-3.5 w-3.5" />
          </Link>
          <Link to="/admin/analytics" className="btn-primary text-[12px]">
            Личный кабинет
          </Link>
        </div>

        <button onClick={() => setOpen(!open)} className="rounded-lg border border-white/10 p-2 lg:hidden">
          {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
        </button>
      </div>
    </header>
  );
}
