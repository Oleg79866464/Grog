import { Link } from "react-router-dom";
import { Mail } from "lucide-react";
import { Logo } from "./Brand";

const cols: { title: string; links: { label: string; href: string }[] }[] = [
  {
    title: "Каталог",
    links: [
      { label: "Маркетинг", href: "/category/marketing" },
      { label: "SMM", href: "/category/smm" },
      { label: "SEO", href: "/category/seo" },
      { label: "Контент", href: "/category/content" },
      { label: "Видео", href: "/category/video" },
      { label: "Бизнес", href: "/category/business" },
    ],
  },
  {
    title: "Продукты",
    links: [
      { label: "Все инструменты", href: "/" },
      { label: "Промпты", href: "/prompts" },
      { label: "Промпт-карточка", href: "/prompts/card" },
      { label: "Страница инструмента", href: "/tool/chatgpt-ru" },
      { label: "Редирект", href: "/go/chatgpt-ru" },
    ],
  },
  {
    title: "Компания",
    links: [
      { label: "О проекте", href: "/contact" },
      { label: "Для партнёров", href: "/sponsors" },
      { label: "Отчёт покупателя", href: "/buyer-report" },
      { label: "Аналитика", href: "/admin/analytics" },
      { label: "Шаблоны", href: "/admin/templates" },
    ],
  },
  {
    title: "Ресурсы",
    links: [
      { label: "SEO-контент", href: "/seo-content" },
      { label: "Виджет дохода", href: "/revenue-widget" },
      { label: "Частые вопросы", href: "/category/seo" },
      { label: "Поддержка", href: "/contact" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="relative mt-32 border-t border-white/[0.06] bg-[#06070b]">
      <div className="pointer-events-none absolute inset-x-0 -top-px mx-auto h-px max-w-3xl bg-gradient-to-r from-transparent via-violet-500/30 to-transparent" />
      <div className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid grid-cols-2 gap-10 md:grid-cols-6">
          <div className="col-span-2 space-y-6">
            <Logo />
            <p className="max-w-xs text-[13px] leading-relaxed text-white/50">
              Крупнейший каталог российских AI-инструментов. Ежедневно обновляемая база, честные обзоры и партнёрские программы.
            </p>
            <div className="flex items-center gap-2">
              {[
                { label: "X", icon: "X" },
                { label: "GH", icon: "GH" },
                { label: "in", icon: "in" },
                { label: "YT", icon: "YT" },
                { label: "@", icon: "@" },
              ].map((it, i) => (
                <button
                  key={i}
                  aria-label={it.label}
                  className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/[0.02] text-[11px] font-semibold tracking-tight text-white/60 transition-colors hover:border-white/20 hover:text-white"
                >
                  {it.icon}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2 rounded-xl border border-white/[0.06] bg-white/[0.02] p-1 pl-3 max-w-xs">
              <Mail className="h-4 w-4 text-white/40" />
              <input
                placeholder="newsletter@ainexus.ru"
                className="flex-1 bg-transparent py-2 text-[13px] text-white placeholder-white/40 outline-none"
              />
              <button className="btn-primary text-[12px]">Подписаться</button>
            </div>
          </div>
          {cols.map((col) => (
            <div key={col.title} className="space-y-4">
              <h4 className="text-[12px] font-semibold uppercase tracking-[0.18em] text-white/80">{col.title}</h4>
              <ul className="space-y-2.5">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <Link to={link.href} className="text-[13px] text-white/55 transition-colors hover:text-white">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-14 flex flex-col items-start justify-between gap-4 border-t border-white/[0.05] pt-8 md:flex-row md:items-center">
          <p className="text-[12px] text-white/40">© 2026 AINexus. Все права защищены. Информация носит справочный характер.</p>
          <div className="flex items-center gap-5 text-[12px] text-white/40">
            <Link to="/" className="hover:text-white">Политика конфиденциальности</Link>
            <Link to="/" className="hover:text-white">Условия использования</Link>
            <Link to="/" className="hover:text-white">Дисклеймер</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
