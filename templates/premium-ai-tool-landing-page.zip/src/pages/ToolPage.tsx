import { Link, useParams } from "react-router-dom";
import { ArrowUpRight, Star, Check, Shield, Zap, Users, Sparkles, Tag, Crown } from "lucide-react";
import { findTool, tools } from "../data/tools";
import { ToolIcon, PageHero, TrustBadges } from "../components/PageSections";
import { cn } from "../utils/cn";

export function ToolPage() {
  const { id } = useParams();
  const tool = findTool(id || "");
  const related = tools.filter((t) => t.id !== id).slice(0, 3);

  if (!tool) {
    return (
      <div className="mx-auto max-w-3xl px-6 py-24 text-center">
        <h1 className="text-3xl font-semibold tracking-tight text-gradient">Инструмент не найден</h1>
        <p className="mt-3 text-white/55">Возможно, он был перемещён или удалён.</p>
        <Link to="/" className="mt-6 inline-block btn-primary">На главную</Link>
      </div>
    );
  }

  const useCases = [
    "Автоматизация повседневных бизнес-задач",
    "Генерация контента для маркетинга и SMM",
    "Аналитика данных и построение отчётов",
    "Поддержка клиентов и FAQ-боты",
  ];

  const benefits = [
    { icon: Zap, title: "Быстрый старт", desc: "Готовые шаблоны и интеграции" },
    { icon: Shield, title: "Приватность", desc: "Хранение данных в РФ" },
    { icon: Users, title: "Поддержка 24/7", desc: "Персональный менеджер" },
    { icon: Sparkles, title: "Русский язык", desc: "Отличное качество на кириллице" },
  ];

  return (
    <>
      <PageHero
        eyebrow={`${tool.category} · ${tool.pricing}`}
        title={tool.name}
        description={tool.tagline}
        primaryCta={{ label: "Перейти на сайт", href: `/go/${tool.id}` }}
        secondaryCta={{ label: "Сравнить с аналогами", href: "#compare" }}
      >
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          <div className="glass-card p-5">
            <div className="text-[10px] uppercase tracking-[0.18em] text-white/40">Рейтинг</div>
            <div className="mt-2 flex items-baseline gap-2">
              <div className="text-3xl font-semibold tracking-tight text-gradient">{tool.rating}</div>
              <div className="flex">
                {[1,2,3,4,5].map((i) => (
                  <Star key={i} className={cn("h-3.5 w-3.5", i <= Math.round(tool.rating) ? "fill-amber-400 text-amber-400" : "text-white/20")} />
                ))}
              </div>
            </div>
            <div className="mt-1 text-[11px] text-white/45">{tool.users} активных пользователей</div>
          </div>
          <div className="glass-card p-5">
            <div className="text-[10px] uppercase tracking-[0.18em] text-white/40">Тарифы</div>
            <div className="mt-2 text-2xl font-semibold tracking-tight text-white">{tool.pricing}</div>
            <div className="mt-1 text-[11px] text-white/45">Бесплатный пробный период 14 дней</div>
          </div>
          <div className="glass-card p-5">
            <div className="text-[10px] uppercase tracking-[0.18em] text-white/40">Обновлено</div>
            <div className="mt-2 text-2xl font-semibold tracking-tight text-white">сегодня</div>
            <div className="mt-1 text-[11px] text-white/45">Версия API 6.4</div>
          </div>
        </div>
      </PageHero>

      <section className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr]">
          <div className="space-y-8">
            <div className="glass-card p-7">
              <div className="flex items-start gap-4">
                <ToolIcon tool={tool} />
                <div>
                  <h2 className="text-2xl font-semibold tracking-tight text-white">{tool.name}</h2>
                  <p className="mt-1 text-[13px] text-white/55">{tool.tagline}</p>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {tool.tags.map((t) => (
                      <span key={t} className="badge"><Tag className="h-3 w-3" />{t}</span>
                    ))}
                  </div>
                </div>
              </div>
              <p className="mt-6 text-[14px] leading-relaxed text-white/70">{tool.description}</p>
              <p className="mt-4 text-[14px] leading-relaxed text-white/55">
                Сервис разработан для российского бизнеса и учитывает специфику работы с отечественными данными.
                Доступны расширенные права пользователей, аудит действий и интеграция с корпоративными SSO-провайдерами.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold tracking-tight text-white">Сценарии использования</h3>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                {useCases.map((u) => (
                  <div key={u} className="glass-card flex items-center gap-3 p-4">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-emerald-400/10 text-emerald-300">
                      <Check className="h-4 w-4" />
                    </div>
                    <span className="text-[13px] text-white/80">{u}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold tracking-tight text-white">Преимущества</h3>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                {benefits.map((b) => (
                  <div key={b.title} className="glass-card flex gap-3 p-5">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-gradient-to-br from-violet-500/15 to-blue-500/5 text-violet-200">
                      <b.icon className="h-4 w-4" />
                    </div>
                    <div>
                      <h4 className="text-[14px] font-semibold text-white">{b.title}</h4>
                      <p className="mt-1 text-[12px] text-white/55">{b.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div id="compare">
              <h3 className="text-xl font-semibold tracking-tight text-white">Сравнение с аналогами</h3>
              <div className="mt-4 overflow-hidden rounded-2xl border border-white/[0.05]">
                <table className="w-full text-left text-[13px]">
                  <thead className="border-b border-white/[0.05] bg-white/[0.02]">
                    <tr className="text-[10px] uppercase tracking-[0.18em] text-white/45">
                      <th className="px-5 py-3 font-semibold">Характеристика</th>
                      <th className="px-5 py-3 font-semibold">{tool.name}</th>
                      <th className="px-5 py-3 font-semibold text-white/30">Аналог</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/[0.04]">
                    {[
                      ["Качество на русском", "★★★★★", "★★★☆☆"],
                      ["Стоимость токена", "от 6 ₽", "от 22 ₽"],
                      ["API и SDK", "Полный набор", "Только REST"],
                      ["SLA", "99.9%", "99.5%"],
                      ["Приватное развёртывание", "Да", "Нет"],
                    ].map(([f, a, b]) => (
                      <tr key={f} className="hover:bg-white/[0.02]">
                        <td className="px-5 py-3 text-white/75">{f}</td>
                        <td className="px-5 py-3 text-white/90">{a}</td>
                        <td className="px-5 py-3 text-white/40">{b}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <aside className="space-y-5 lg:sticky lg:top-24 lg:self-start">
            <div className="glass-card overflow-hidden p-6">
              <div className="text-[11px] uppercase tracking-[0.18em] text-violet-300">Аффилиатная ссылка</div>
              <h3 className="mt-2 text-[18px] font-semibold tracking-tight text-white">Перейти на официальный сайт</h3>
              <p className="mt-2 text-[12px] leading-relaxed text-white/55">
                По переходу вы получите бонусные токены и расширенный пробный период.
              </p>
              <Link to={`/go/${tool.id}`} className="mt-5 flex w-full items-center justify-center gap-2 btn-primary">
                Перейти к инструменту
                <ArrowUpRight className="h-3.5 w-3.5" />
              </Link>
              <div className="mt-4 grid grid-cols-2 gap-3 text-[11px]">
                <div className="rounded-lg border border-white/[0.05] bg-white/[0.02] p-3">
                  <div className="text-white/40">Комиссия</div>
                  <div className="mt-0.5 font-medium text-emerald-300">+25% revshare</div>
                </div>
                <div className="rounded-lg border border-white/[0.05] bg-white/[0.02] p-3">
                  <div className="text-white/40">Cookie window</div>
                  <div className="mt-0.5 font-medium text-white/85">90 дней</div>
                </div>
              </div>
            </div>

            <div className="glass-card p-6">
              <h4 className="text-[14px] font-semibold text-white">Детали продукта</h4>
              <ul className="mt-4 space-y-3 text-[13px]">
                <li className="flex items-center justify-between">
                  <span className="text-white/50">Категория</span>
                  <Link to="/category/text" className="text-white/85">{tool.category}</Link>
                </li>
                <li className="flex items-center justify-between">
                  <span className="text-white/50">Цена</span>
                  <span className="text-white/85">{tool.pricing}</span>
                </li>
                <li className="flex items-center justify-between">
                  <span className="text-white/50">Обновлено</span>
                  <span className="text-white/85">12.01.2026</span>
                </li>
                <li className="flex items-center justify-between">
                  <span className="text-white/50">Рейтинг</span>
                  <span className="flex items-center gap-1 text-white/85">
                    <Crown className="h-3 w-3 text-amber-300" />
                    {tool.rating}
                  </span>
                </li>
              </ul>
            </div>

            <div className="glass-card p-6">
              <h4 className="text-[14px] font-semibold text-white">Отзыв редакции</h4>
              <div className="mt-3 flex gap-0.5">
                {[1,2,3,4,5].map((i) => (
                  <Star key={i} className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <p className="mt-3 text-[13px] leading-relaxed text-white/60">
                «Стабильный, быстрый, с отличной поддержкой русского языка. Отличный выбор для команд,
                которые ценят качество и предсказуемость.»
              </p>
              <div className="mt-4 flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-gradient-to-br from-violet-500 to-blue-500" />
                <div>
                  <div className="text-[12px] font-medium text-white">Анна Соколова</div>
                  <div className="text-[11px] text-white/45">Главный редактор AINexus</div>
                </div>
              </div>
            </div>
          </aside>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 pb-16">
        <div className="section-eyebrow">Похожие инструменты</div>
        <h2 className="mt-2 text-2xl font-semibold tracking-tight text-gradient sm:text-3xl">
          Из той же категории
        </h2>
        <div className="mt-8 grid gap-5 md:grid-cols-3">
          {related.map((r) => (
            <Link key={r.id} to={`/tool/${r.id}`} className="glass-card glass-card-hover p-5">
              <div className="flex items-center gap-3">
                <ToolIcon tool={r} />
                <div>
                  <div className="text-[14px] font-semibold text-white">{r.name}</div>
                  <div className="text-[12px] text-white/55">{r.tagline}</div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <TrustBadges />
    </>
  );
}
