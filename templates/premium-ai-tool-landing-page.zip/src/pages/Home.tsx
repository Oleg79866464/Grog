import { Link } from "react-router-dom";
import { ArrowUpRight, Sparkles, Shield, BarChart3, Globe, Zap, Layers, Users } from "lucide-react";
import { featuredTools, categories, tools } from "../data/tools";
import { ToolCard, TrustBar, PageHero, TrustBadges } from "../components/PageSections";

export function Home() {
  return (
    <>
      <PageHero
        eyebrow="Каталог AI-инструментов · Версия 6.4"
        title={
          <>
            Российские нейросети <br />
            <span className="accent-gradient">в одном каталоге</span>
          </>
        }
        description="Больше 150 проверенных AI-сервисов: от генерации текста и изображений до автоматизации маркетинга, SEO и аналитики. Честные обзоры, партнёрские программы и бонусы для подписчиков."
        primaryCta={{ label: "Открыть каталог", href: "#catalog" }}
        secondaryCta={{ label: "Как это работает", href: "#how" }}
      >
        <div className="mt-12 grid gap-6">
          <div className="mx-auto inline-flex max-w-fit items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-4 py-1.5 text-[12px] text-white/55">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
            Обновлено 12 января 2026 · добавлено 14 новых инструментов
          </div>
          <div className="mx-auto max-w-3xl">
            <TrustBar />
          </div>
        </div>
      </PageHero>

      <section id="catalog" className="mx-auto max-w-7xl px-6 py-20">
        <div className="flex items-end justify-between gap-6">
          <div>
            <div className="section-eyebrow">Избранное</div>
            <h2 className="mt-2 text-3xl font-semibold tracking-tight text-gradient sm:text-4xl">
              Рекомендуемые инструменты
            </h2>
            <p className="mt-2 max-w-xl text-[14px] text-white/55">
              Топ-6 сервисов, которые еженедельно проверяются нашей редакцией и получают самые высокие оценки пользователей.
            </p>
          </div>
          <Link to="/category/text" className="hidden btn-secondary text-[12px] md:inline-flex">
            Все инструменты
            <ArrowUpRight className="h-3.5 w-3.5" />
          </Link>
        </div>

        <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {featuredTools.map((t) => (
            <ToolCard key={t.id} tool={t} />
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 pb-20">
        <div className="flex items-end justify-between gap-6">
          <div>
            <div className="section-eyebrow">Категории</div>
            <h2 className="mt-2 text-3xl font-semibold tracking-tight text-gradient sm:text-4xl">
              Найдите ИИ под свою задачу
            </h2>
          </div>
        </div>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {categories.map((c) => (
            <Link
              to={`/category/${c.id}`}
              key={c.id}
              className="glass-card glass-card-hover group flex flex-col gap-4 p-5"
            >
              <div className="flex items-center justify-between">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-gradient-to-br from-violet-500/20 to-blue-500/10 text-[14px] font-semibold text-violet-200">
                  {c.icon}
                </div>
                <span className="badge text-[10px]">{c.count} {c.count > 4 ? "сервисов" : "сервиса"}</span>
              </div>
              <div>
                <h3 className="text-[15px] font-semibold tracking-tight text-white">{c.name}</h3>
                <p className="mt-1 text-[12px] leading-relaxed text-white/50">
                  Специализированные инструменты именно для вашего направления.
                </p>
              </div>
              <div className="mt-1 inline-flex items-center gap-1 text-[12px] text-white/55 transition-colors group-hover:text-white">
                Перейти в категорию
                <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 pb-24">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.4fr] lg:items-center">
          <div className="space-y-8">
            <div>
              <div className="section-eyebrow">Преимущества</div>
              <h2 className="mt-2 text-3xl font-semibold tracking-tight text-gradient sm:text-4xl">
                Зачем использовать AINexus
              </h2>
              <p className="mt-3 text-[14px] leading-relaxed text-white/55">
                Мы agregируем лучшие российские AI-сервисы, чтобы вы не тратили время на поиск альтернатив зарубежным решениям.
              </p>
            </div>
            <div className="grid gap-5">
              {[
                { icon: Shield, title: "Проверенные поставщики", desc: "В каталог попадают только сервисы с прозрачной политикой и SLA." },
                { icon: BarChart3, title: "Сравнение по метрикам", desc: "Цена, скорость, точность, интеграции — всё в одной таблице." },
                { icon: Globe, title: "Русский язык в приоритете", desc: "Отдельная оценка для работы с кириллицей и локальным контекстом." },
                { icon: Layers, title: "Готовые стеки", desc: "Подборки инструментов для маркетинга, продукта и поддержки." },
              ].map((f, i) => (
                <div key={i} className="flex gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-gradient-to-br from-violet-500/15 to-blue-500/5 text-violet-200">
                    <f.icon className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="text-[14px] font-semibold text-white">{f.title}</h4>
                    <p className="mt-1 text-[13px] leading-relaxed text-white/55">{f.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="glass-card overflow-hidden p-6">
              <div className="flex items-center gap-3 border-b border-white/[0.06] pb-4">
                <div className="flex gap-1.5">
                  <div className="h-2.5 w-2.5 rounded-full bg-rose-400/80" />
                  <div className="h-2.5 w-2.5 rounded-full bg-amber-400/80" />
                  <div className="h-2.5 w-2.5 rounded-full bg-emerald-400/80" />
                </div>
                <div className="text-[11px] uppercase tracking-[0.18em] text-white/40">AINexus · Product UI</div>
              </div>
              <div className="grid grid-cols-3 gap-3 py-4">
                {[
                  { label: "Инструментов", value: "152", trend: "+14" },
                  { label: "Категорий", value: "8", trend: "—" },
                  { label: "Пользователей", value: "1.2M", trend: "+8%" },
                ].map((s) => (
                  <div key={s.label} className="rounded-xl border border-white/[0.05] bg-white/[0.02] p-4">
                    <div className="text-[10px] uppercase tracking-[0.18em] text-white/40">{s.label}</div>
                    <div className="mt-2 flex items-baseline gap-2">
                      <div className="text-[22px] font-semibold tracking-tight text-white">{s.value}</div>
                      <div className="text-[11px] font-medium text-emerald-400">{s.trend}</div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="grid gap-2">
                {tools.slice(0, 4).map((t) => (
                  <div key={t.id} className="flex items-center justify-between rounded-xl border border-white/[0.04] bg-white/[0.01] p-3">
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-violet-500/30 to-blue-500/20" />
                      <div>
                        <div className="text-[13px] font-medium text-white">{t.name}</div>
                        <div className="text-[11px] text-white/45">{t.category}</div>
                      </div>
                    </div>
                    <div className="text-[11px] text-white/55">{t.pricing}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="pointer-events-none absolute -inset-6 -z-10 rounded-[36px] bg-gradient-to-br from-violet-600/10 via-blue-500/5 to-transparent blur-2xl" />
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 pb-24">
        <div className="grid gap-4 md:grid-cols-3">
          {[
            { icon: Users, stat: "12 400+", label: "Подписчиков в Телеграме" },
            { icon: Zap, stat: "38%", label: "Средний прирост конверсии" },
            { icon: Sparkles, stat: "152", label: "Актуальных инструментов" },
          ].map((s) => (
            <div key={s.label} className="glass-card p-6">
              <s.icon className="h-5 w-5 text-violet-300" />
              <div className="mt-6 text-[26px] font-semibold tracking-tight text-gradient">{s.stat}</div>
              <div className="mt-1 text-[12px] text-white/55">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 pb-24">
        <div className="section-eyebrow">SEO-обзор</div>
        <h2 className="mt-2 text-3xl font-semibold tracking-tight text-gradient sm:text-4xl">
          Почему российские AI-инструменты — это новая норма
        </h2>
        <div className="mt-8 grid gap-6 md:grid-cols-2">
          <div className="glass-card p-7">
            <h3 className="text-[15px] font-semibold tracking-tight text-white">Суверенный стек технологий</h3>
            <p className="mt-3 text-[13px] leading-relaxed text-white/55">
              Отечественные разработчики всё чаще используют собственные LLM и обучающие контуры, что позволяет сохранять данные внутри юрисдикции и соблюдать 152-ФЗ. Мы подробно описываем каждый такой кейс в каталоге.
            </p>
          </div>
          <div className="glass-card p-7">
            <h3 className="text-[15px] font-semibold tracking-tight text-white">Прозрачное сравнение</h3>
            <p className="mt-3 text-[13px] leading-relaxed text-white/55">
              Для каждой категории мы поддерживаем актуальные таблицы: что умеет бесплатный тариф, каковы ограничения API, насколько быстрый вывод токенов. Это помогает избежать переплаты за функции, которые никогда не будут использоваться.
            </p>
          </div>
        </div>
      </section>

      <TrustBadges />

      <section className="mx-auto max-w-7xl px-6 py-24">
        <div className="section-eyebrow">FAQ</div>
        <h2 className="mt-2 text-3xl font-semibold tracking-tight text-gradient sm:text-4xl">
          Часто задаваемые вопросы
        </h2>
        <div className="mt-8 grid gap-3">
          {[
            { q: "Это действительно бесплатный каталог?", a: "Да, базовый доступ и обзоры бесплатны. Премиум-функции (экспорт данных, API) открываются по подписке." },
            { q: "Как часто обновляются обзоры?", a: "Каждую неделю. Мы перепроверяем метрики, добавляем новые тарифы и удаляем устаревшие сервисы." },
            { q: "Есть ли партнёрская программа?", a: "Да. Авторы обзоров и крупные интеграторы получают revshare до 25% с каждого привлечённого платящего клиента." },
            { q: "Можно ли предложить свой инструмент?", a: "Конечно — форма добавления в каталог доступна в личном кабинете, а также через страницу «Для партнёров»." },
          ].map((it, i) => (
            <details key={i} className="glass-card group p-0 [&_summary]:px-6 [&_summary]:py-5">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-[14px] font-medium text-white">
                {it.q}
                <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-white/10 text-white/60 transition-transform group-open:rotate-45">+</div>
              </summary>
              <div className="px-6 pb-5 pr-14 text-[13px] leading-relaxed text-white/60">{it.a}</div>
            </details>
          ))}
        </div>
      </section>
    </>
  );
}
