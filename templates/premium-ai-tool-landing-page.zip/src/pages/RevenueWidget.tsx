import { ArrowUpRight, Crown, MousePointer, Percent, TrendingUp, Wallet } from "lucide-react";

const monthData = [
  { d: "1", v: 18 }, { d: "5", v: 22 }, { d: "10", v: 30 }, { d: "15", v: 26 },
  { d: "20", v: 42 }, { d: "25", v: 56 }, { d: "30", v: 48 },
];

export function RevenueWidget() {
  return (
    <div className="mx-auto max-w-2xl px-6 py-16">
      <div className="mb-6 text-center">
        <span className="section-eyebrow">Партнёрский виджет · AINexus</span>
        <h1 className="mt-2 text-2xl font-semibold tracking-tight text-gradient sm:text-3xl">
          Виджет аналитики доходов
        </h1>
      </div>

      <article className="glass-card overflow-hidden">
        <div className="flex items-center justify-between border-b border-white/[0.06] px-5 py-4">
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded-lg bg-gradient-to-br from-violet-500 to-blue-500" />
            <div>
              <div className="text-[13px] font-semibold text-white">AINexus Revenue</div>
              <div className="text-[10px] uppercase tracking-[0.18em] text-white/40">Affiliate · Live</div>
            </div>
          </div>
          <button className="badge">
            <Crown className="h-3 w-3 text-amber-300" />
            PRO
          </button>
        </div>

        <div className="grid grid-cols-2 gap-px bg-white/[0.04]">
          {[
            { icon: Wallet, label: "Прогноз дохода", value: "2 348 920 ₽", delta: "+18.2%" },
            { icon: MousePointer, label: "Клики", value: "128 472", delta: "+12.4%" },
            { icon: Percent, label: "Конверсия", value: "4.71%", delta: "+0.4 п.п." },
            { icon: TrendingUp, label: "Rev / Click", value: "18,28 ₽", delta: "+5.3%" },
          ].map((k) => (
            <div key={k.label} className="bg-[#0a0c12] p-4">
              <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.18em] text-white/40">
                <k.icon className="h-3 w-3" /> {k.label}
              </div>
              <div className="mt-2 text-[20px] font-semibold tracking-tight text-white">{k.value}</div>
              <div className="mt-1 flex items-center gap-1 text-[11px] text-emerald-300">
                <ArrowUpRight className="h-3 w-3" /> {k.delta}
              </div>
            </div>
          ))}
        </div>

        <div className="p-5">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-white/40">Динамика за месяц</span>
            <span className="text-emerald-300">+38% прогресс</span>
          </div>
          <div className="mt-3 grid grid-cols-7 items-end gap-1.5">
            {monthData.map((m, i) => (
              <div key={i} className="flex flex-col items-center gap-1">
                <div className="h-20 w-full rounded-md bg-white/[0.02] p-1">
                  <div
                    className="w-full rounded bg-gradient-to-t from-violet-500 to-cyan-400"
                    style={{ height: `${m.v}%` }}
                  />
                </div>
                <span className="text-[9px] text-white/40">{m.d}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2 border-t border-white/[0.05] pt-4 text-[11px]">
            <div>
              <span className="text-white/45">Партнёров</span>
              <div className="mt-0.5 font-medium text-white/90">38</div>
            </div>
            <div>
              <span className="text-white/45">Cookie</span>
              <div className="mt-0.5 font-medium text-white/90">90 дней</div>
            </div>
            <div>
              <span className="text-white/45">Revshare</span>
              <div className="mt-0.5 font-medium text-emerald-300">до 25%</div>
            </div>
          </div>
        </div>
      </article>

      <p className="mt-4 text-center text-[11px] text-white/40">
        Виджет можно встроить на любой сайт через iframe или script-тег.
      </p>
    </div>
  );
}
