import { Link } from "react-router-dom";
import { ArrowDownRight, ArrowUpRight, BarChart3, Calendar, Download, Filter, Globe, Laptop, MousePointer, Smartphone, TrendingUp, Wallet } from "lucide-react";
import { BarChart, Bar, LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid, Cell, PieChart, Pie } from "recharts";

const kpis = [
  { label: "Всего кликов", value: "128 472", delta: "+12.4%", up: true, icon: MousePointer },
  { label: "Доход (оценка)", value: "2 348 920 ₽", delta: "+18.2%", up: true, icon: Wallet },
  { label: "Доход на клик", value: "18,28 ₽", delta: "+5.3%", up: true, icon: TrendingUp },
  { label: "Конверсия", value: "4.71%", delta: "-0.8%", up: false, icon: BarChart3 },
];

const clicksByDay = [
  { d: "Пн", v: 12400 }, { d: "Вт", v: 14800 }, { d: "Ср", v: 13200 },
  { d: "Чт", v: 16800 }, { d: "Пт", v: 19500 }, { d: "Сб", v: 14300 }, { d: "Вс", v: 11800 },
];

const revenueByMonth = [
  { d: "Июль", v: 162000 }, { d: "Авг", v: 184000 }, { d: "Сен", v: 219000 },
  { d: "Окт", v: 254000 }, { d: "Ноя", v: 312000 }, { d: "Дек", v: 401000 },
  { d: "Янв", v: 348000 },
];

const countries = [
  { name: "Россия", value: 62, color: "#8b5cf6" },
  { name: "Беларусь", value: 11, color: "#5b8def" },
  { name: "Казахстан", value: 9, color: "#22d3ee" },
  { name: "Другие", value: 18, color: "#475569" },
];

const devices = [
  { name: "Desktop", value: 54, color: "#8b5cf6" },
  { name: "Mobile", value: 38, color: "#5b8def" },
  { name: "Tablet", value: 8, color: "#22d3ee" },
];

const topTools = [
  { name: "YandexGPT", clicks: 18420, conv: "5.8%", rev: "412 800 ₽", trend: "+8.4%" },
  { name: "GigaChat", clicks: 16240, conv: "5.1%", rev: "318 400 ₽", trend: "+12.1%" },
  { name: "Kandinsky", clicks: 13980, conv: "4.6%", rev: "286 000 ₽", trend: "+6.2%" },
  { name: "ContentMind", clicks: 10840, conv: "6.2%", rev: "254 200 ₽", trend: "+14.5%" },
  { name: "SEOPilot", clicks: 9480, conv: "5.4%", rev: "201 600 ₽", trend: "+7.8%" },
  { name: "SMM Oracle", clicks: 7820, conv: "4.1%", rev: "112 800 ₽", trend: "+3.4%" },
];

export function Analytics() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-12">
      <div className="flex items-end justify-between gap-6">
        <div>
          <span className="section-eyebrow">Аналитика · Администратор</span>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-gradient sm:text-4xl">
            Аффилиатная аналитика
          </h1>
          <p className="mt-2 text-[14px] text-white/55">
            Дашборд по кликам, доходу и поведению пользователей в партнёрской программе.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="hidden items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2 sm:flex">
            <Calendar className="h-3.5 w-3.5 text-white/45" />
            <span className="text-[12px] text-white/70">Январь 2026</span>
          </div>
          <button className="btn-secondary text-[12px]">
            <Download className="h-3.5 w-3.5" /> Экспорт
          </button>
        </div>
      </div>

      <div className="mt-10 grid gap-4 lg:grid-cols-4">
        {kpis.map((k) => (
          <div key={k.label} className="glass-card p-5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase tracking-[0.18em] text-white/40">{k.label}</span>
              <k.icon className="h-4 w-4 text-white/35" />
            </div>
            <div className="mt-3 text-2xl font-semibold tracking-tight text-white">{k.value}</div>
            <div className={`mt-1 inline-flex items-center gap-1 text-[11px] ${k.up ? "text-emerald-300" : "text-rose-300"}`}>
              {k.up ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
              {k.delta} <span className="text-white/35">vs прошлый период</span>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <div className="glass-card p-5 lg:col-span-2">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-[14px] font-semibold text-white">Клики по дням</h3>
              <p className="mt-0.5 text-[11px] text-white/45">Сумма за последние 7 дней</p>
            </div>
            <div className="flex gap-1">
              {["7Д", "30Д", "90Д", "Всё"].map((x, i) => (
                <button key={x} className={`rounded-md px-2 py-1 text-[11px] ${i === 0 ? "bg-violet-500/20 text-violet-200" : "text-white/45 hover:text-white/80"}`}>
                  {x}
                </button>
              ))}
            </div>
          </div>
          <div className="mt-4 h-56">
            <ResponsiveContainer>
              <BarChart data={clicksByDay}>
                <defs>
                  <linearGradient id="barGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.9} />
                    <stop offset="100%" stopColor="#5b8def" stopOpacity={0.2} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="#ffffff10" vertical={false} />
                <XAxis dataKey="d" tick={{ fill: "#8b93a7", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "#8b93a7", fontSize: 11 }} axisLine={false} tickLine={false} width={40} />
                <Tooltip
                  contentStyle={{ background: "#0a0c12", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, fontSize: 12 }}
                  cursor={{ fill: "rgba(255,255,255,0.03)" }}
                />
                <Bar dataKey="v" radius={[6, 6, 0, 0]} fill="url(#barGrad)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-card p-5">
          <h3 className="text-[14px] font-semibold text-white">География</h3>
          <p className="mt-0.5 text-[11px] text-white/45">Клики по странам</p>
          <div className="mt-3 h-44">
            <ResponsiveContainer>
              <PieChart>
                <Pie data={countries} dataKey="value" innerRadius={42} outerRadius={68} paddingAngle={2}>
                  {countries.map((c, i) => (
                    <Cell key={i} fill={c.color} stroke="none" />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ background: "#0a0c12", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, fontSize: 12 }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-2 space-y-1.5 text-[12px]">
            {countries.map((c) => (
              <div key={c.name} className="flex items-center justify-between text-white/65">
                <span className="flex items-center gap-2"><span className="h-2 w-2 rounded-full" style={{ background: c.color }} />{c.name}</span>
                <span>{c.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <div className="glass-card p-5 lg:col-span-2">
          <h3 className="text-[14px] font-semibold text-white">Доход по месяцам</h3>
          <p className="mt-0.5 text-[11px] text-white/45">Кумулятивный показатель в рублях</p>
          <div className="mt-4 h-56">
            <ResponsiveContainer>
              <LineChart data={revenueByMonth}>
                <defs>
                  <linearGradient id="lineGrad" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#22d3ee" />
                    <stop offset="100%" stopColor="#8b5cf6" />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="#ffffff10" vertical={false} />
                <XAxis dataKey="d" tick={{ fill: "#8b93a7", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "#8b93a7", fontSize: 11 }} axisLine={false} tickLine={false} width={50} />
                <Tooltip
                  contentStyle={{ background: "#0a0c12", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, fontSize: 12 }}
                  formatter={(v) => `${Number(v).toLocaleString()} ₽`}
                />
                <Line type="monotone" dataKey="v" stroke="url(#lineGrad)" strokeWidth={2.5} dot={false} activeDot={{ r: 5, fill: "#8b5cf6" }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-card p-5">
          <h3 className="text-[14px] font-semibold text-white">Устройства</h3>
          <p className="mt-0.5 text-[11px] text-white/45">Распределение сессий</p>
          <div className="mt-3 h-44">
            <ResponsiveContainer>
              <PieChart>
                <Pie data={devices} dataKey="value" innerRadius={42} outerRadius={68} paddingAngle={2}>
                  {devices.map((d, i) => (
                    <Cell key={i} fill={d.color} stroke="none" />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ background: "#0a0c12", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-2 space-y-1.5 text-[12px]">
            {devices.map((d) => (
              <div key={d.name} className="flex items-center justify-between text-white/65">
                <span className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full" style={{ background: d.color }} />
                  {d.name === "Desktop" ? <span className="flex items-center gap-1.5"><Laptop className="h-3 w-3" />Desktop</span> :
                    d.name === "Mobile" ? <span className="flex items-center gap-1.5"><Smartphone className="h-3 w-3" />Mobile</span> :
                    <span className="flex items-center gap-1.5"><Globe className="h-3 w-3" />Tablet</span>}
                </span>
                <span>{d.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-6 glass-card overflow-hidden">
        <div className="flex items-center justify-between border-b border-white/[0.06] px-5 py-4">
          <h3 className="text-[14px] font-semibold text-white">Топ инструментов</h3>
          <button className="btn-secondary text-[11px]"><Filter className="h-3 w-3" /> Фильтр</button>
        </div>
        <table className="w-full text-left text-[13px]">
          <thead className="border-b border-white/[0.05] bg-white/[0.02]">
            <tr className="text-[10px] uppercase tracking-[0.18em] text-white/45">
              <th className="px-5 py-3 font-semibold">Инструмент</th>
              <th className="px-5 py-3 font-semibold">Клики</th>
              <th className="px-5 py-3 font-semibold">Конверсия</th>
              <th className="px-5 py-3 font-semibold">Доход</th>
              <th className="px-5 py-3 font-semibold">Тренд</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/[0.04]">
            {topTools.map((t) => (
              <tr key={t.name} className="transition-colors hover:bg-white/[0.02]">
                <td className="px-5 py-3.5">
                  <Link to="/" className="font-medium text-white/90 hover:text-white">{t.name}</Link>
                </td>
                <td className="px-5 py-3.5 text-white/75">{t.clicks.toLocaleString()}</td>
                <td className="px-5 py-3.5 text-white/75">{t.conv}</td>
                <td className="px-5 py-3.5 text-white/90">{t.rev}</td>
                <td className="px-5 py-3.5 text-emerald-300">{t.trend}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
