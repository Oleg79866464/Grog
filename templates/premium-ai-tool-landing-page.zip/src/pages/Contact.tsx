import { Link } from "react-router-dom";
import { ArrowUpRight, Mail, MapPin, Send, Shield, Sparkles, Star, Users } from "lucide-react";

const portfolio = [
  { name: "AINexus — каталог ИИ-инструментов", desc: "Сооснователь и руководитель продукта. Рост с 0 до 184K MAU за 18 месяцев.", tag: "Product", url: "/" },
  { name: "AIPrompts Shop", desc: "Маркетплейс промптов и шаблонов. Более 4 000 транзакций за первый год.", tag: "eCommerce", url: "/prompts" },
  { name: "NeuralInsights", desc: "Аналитический подкаст про AI-индустрию в России. 38 выпусков, 12K слушателей.", tag: "Media", url: "/" },
  { name: "Autotone AI Conference", desc: "Организатор ежегодной конференции для практиков ИИ в бизнесе.", tag: "Events", url: "/" },
];

const badges = [
  { icon: Star, label: "Топ-50", sub: "предпринимателей Рунета" },
  { icon: Shield, label: "Verified", sub: "проверенный продавец" },
  { icon: Users, label: "12K+", sub: "подписчиков в Телеграме" },
  { icon: Sparkles, label: "8 лет", sub: "в digital-продуктах" },
];

export function Contact() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-16">
      <div className="grid gap-12 lg:grid-cols-[1fr_1.2fr]">
        <aside className="space-y-6">
          <div className="glass-card flex flex-col items-center p-8 text-center">
            <div className="relative">
              <div className="h-28 w-28 overflow-hidden rounded-full bg-gradient-to-br from-violet-500 via-indigo-500 to-cyan-400 p-[2px]">
                <div className="flex h-full w-full items-center justify-center rounded-full bg-[#0a0c12] text-3xl font-semibold tracking-tight text-white">
                  АС
                </div>
              </div>
              <span className="absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full border-2 border-[#0a0c12] bg-emerald-400 text-[10px] font-semibold text-emerald-950">
                ✓
              </span>
            </div>
            <h1 className="mt-5 text-2xl font-semibold tracking-tight text-gradient">Анна Соколова</h1>
            <p className="mt-1 text-[13px] text-white/55">основатель AINexus · продуктовый стратег</p>
            <p className="mt-4 max-w-[26ch] text-[13px] leading-relaxed text-white/65">
              Помогаю бизнесу внедрять ИИ-инструменты и строить устойчивые продукты в русскоязычном сегменте.
            </p>
            <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
              {badges.map((b) => (
                <div key={b.label} className="flex items-center gap-2 rounded-full border border-white/[0.06] bg-white/[0.03] px-3 py-1.5 text-[11px] text-white/65">
                  <b.icon className="h-3 w-3 text-violet-300" /> {b.label}
                </div>
              ))}
            </div>
            <div className="mt-7 grid w-full grid-cols-2 gap-2 text-left">
              <div className="rounded-xl border border-white/[0.05] bg-white/[0.02] p-3">
                <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.18em] text-white/40">
                  <MapPin className="h-3 w-3" /> Город
                </div>
                <div className="mt-1 font-medium text-white/90">Москва</div>
              </div>
              <div className="rounded-xl border border-white/[0.05] bg-white/[0.02] p-3">
                <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.18em] text-white/40">
                  <Mail className="h-3 w-3" /> Email
                </div>
                <div className="mt-1 truncate font-medium text-white/90">anna@ainexus.ru</div>
              </div>
            </div>
            <Link to="mailto:anna@ainexus.ru" className="mt-6 flex w-full items-center justify-center gap-2 btn-primary">
              Связаться
              <Send className="h-3.5 w-3.5" />
            </Link>
          </div>

          <div className="glass-card p-6">
            <h3 className="text-[14px] font-semibold text-white">Социальные сети</h3>
            <ul className="mt-4 space-y-2 text-[13px]">
              {[
                ["Телеграм-канал", "t.me/ainexus"],
                ["Хабр", "habr.com/ru/users/asokolova"],
                ["GitHub", "github.com/asokolova"],
                ["LinkedIn", "linkedin.com/in/asokolova"],
              ].map(([label, url]) => (
                <li key={label} className="flex items-center justify-between rounded-lg border border-white/[0.04] px-3 py-2 text-white/65 hover:border-white/10 hover:text-white">
                  <span>{label}</span>
                  <span className="font-mono text-[11px] text-white/40">{url}</span>
                </li>
              ))}
            </ul>
          </div>
        </aside>

        <section className="space-y-10">
          <div>
            <span className="section-eyebrow">Обо мне</span>
            <h2 className="mt-2 text-3xl font-semibold tracking-tight text-gradient sm:text-4xl">
              Позиционирование
            </h2>
            <div className="mt-6 space-y-4 text-[14px] leading-relaxed text-white/65">
              <p>
                Более 8 лет занимаюсь digital-продуктами в России и СНГ. Специализируюсь на запуске
                нишевых каталогов, маркетплейсов и партнёрских сетей с упором на SEO и AI-автоматизацию.
              </p>
              <p>
                AINexus — мой флагманский проект, который демонстрирует, как можно быстро выстроить
                доверие аудитории и монетизировать знания об ИИ-рынке без агрессивного маркетинга.
              </p>
              <p>
                Открыта к стратегическому партнёрству, консультациям и M&A сделкам. Если у вас есть
                интересный продукт или вы хотите выйти на российский ИИ-рынок — буду рада пообщаться.
              </p>
            </div>
          </div>

          <div>
            <span className="section-eyebrow">Портфолио</span>
            <h2 className="mt-2 text-2xl font-semibold tracking-tight text-gradient sm:text-3xl">
              Ключевые проекты
            </h2>
            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              {portfolio.map((p) => (
                <Link key={p.name} to={p.url} className="glass-card glass-card-hover p-5">
                  <div className="flex items-center justify-between">
                    <span className="badge">{p.tag}</span>
                    <ArrowUpRight className="h-3.5 w-3.5 text-white/35" />
                  </div>
                  <h4 className="mt-3 text-[14px] font-semibold text-white">{p.name}</h4>
                  <p className="mt-1.5 text-[12px] leading-relaxed text-white/55">{p.desc}</p>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
