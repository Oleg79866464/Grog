import { Link } from "react-router-dom";
import { ArrowUpRight, Check, Download, Filter, Search, Shield, ShoppingCart, Sparkles, Star, Tag, Zap } from "lucide-react";
import { prompts } from "../data/tools";

const categories = ["Все", "SEO", "SMM", "Image", "Video", "Dev", "Sales"];

export function Prompts() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-12">
      <section className="relative overflow-hidden rounded-3xl border border-white/[0.05] bg-gradient-to-br from-[#0d0f17] via-[#0a0c12] to-[#0d0f17] p-10 md:p-14">
        <div className="pointer-events-none absolute -right-20 -top-20 h-[420px] w-[420px] rounded-full bg-violet-600/15 blur-[120px]" />
        <div className="relative grid gap-8 lg:grid-cols-[1.4fr_1fr] lg:items-center">
          <div>
            <div className="section-eyebrow">AINexus · Маркетплейс промптов</div>
            <h1 className="mt-3 text-4xl font-semibold tracking-tight text-gradient sm:text-5xl">
              Промпты, которые{" "}
              <span className="accent-gradient">экономят часы</span>
            </h1>
            <p className="mt-4 max-w-xl text-[15px] leading-relaxed text-white/55">
              Готовые, протестированные промпты для ChatGPT, Midjourney, Runway и других нейросетей.
              Покупайте отдельные пакеты или подписку на весь каталог.
            </p>
            <div className="mt-7 flex flex-wrap items-center gap-3">
              <button className="btn-primary">
                <ShoppingCart className="h-3.5 w-3.5" /> Открыть каталог промптов
              </button>
              <button className="btn-secondary">
                <Sparkles className="h-3.5 w-3.5" /> Посмотреть пример
              </button>
            </div>
            <div className="mt-8 grid grid-cols-3 gap-px overflow-hidden rounded-2xl border border-white/[0.05] bg-white/[0.02] sm:max-w-md">
              {[
                { value: "4 200+", label: "Промптов в базе" },
                { value: "98%", label: "Положительных отзывов" },
                { value: "30 дней", label: "Гарантия возврата" },
              ].map((s) => (
                <div key={s.label} className="bg-[#06070b] px-4 py-4">
                  <div className="text-base font-semibold tracking-tight text-white">{s.value}</div>
                  <div className="mt-1 text-[10px] uppercase tracking-[0.18em] text-white/40">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="glass-card mx-auto w-full max-w-sm p-6">
            <div className="flex items-center justify-between">
              <span className="badge">ХИТ ПРОДАЖ</span>
              <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
            </div>
            <h3 className="mt-4 text-[15px] font-semibold tracking-tight text-white">Пакет SEO-промптов</h3>
            <p className="mt-1 text-[12px] text-white/55">80 промптов для кластеризации и метатегов</p>
            <div className="mt-5 flex items-baseline gap-2">
              <span className="text-3xl font-semibold tracking-tight text-white">1 490 ₽</span>
              <span className="text-[12px] text-white/40 line-through">2 990 ₽</span>
            </div>
            <Link to="/prompts/card" className="mt-5 flex w-full items-center justify-center gap-2 btn-primary">
              Посмотреть карточку
              <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
            <ul className="mt-5 space-y-1.5 text-[12px] text-white/65">
              {["80 готовых промптов", "Для ChatGPT, Claude, GigaChat", "Обновления 6 месяцев", "Чек-лист по внедрению"].map((f) => (
                <li key={f} className="flex items-center gap-2">
                  <Check className="h-3 w-3 text-emerald-400" /> {f}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="mt-12 flex flex-wrap items-center gap-3">
        <div className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2">
          <Search className="h-3.5 w-3.5 text-white/40" />
          <input placeholder="Поиск промптов..." className="bg-transparent text-[12px] text-white placeholder-white/40 outline-none w-56" />
        </div>
        <div className="flex items-center gap-1 rounded-xl border border-white/10 bg-white/[0.03] p-1">
          {categories.map((c, i) => (
            <button key={c} className={`rounded-md px-3 py-1.5 text-[12px] ${i === 0 ? "bg-white/10 text-white" : "text-white/55 hover:text-white"}`}>
              {c}
            </button>
          ))}
        </div>
        <button className="btn-secondary text-[12px]"><Filter className="h-3.5 w-3.5" /> Ещё фильтры</button>
      </section>

      <section className="mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {prompts.map((p) => (
          <div key={p.id} className="glass-card glass-card-hover flex flex-col gap-4 p-6">
            <div className="flex items-start justify-between">
              <span className="badge">{p.category}</span>
              <Zap className="h-3.5 w-3.5 text-amber-300" />
            </div>
            <div>
              <h3 className="text-[15px] font-semibold tracking-tight text-white">{p.title}</h3>
              <p className="mt-1.5 text-[12px] leading-relaxed text-white/55">{p.description}</p>
            </div>
            <div className="mt-auto flex items-center justify-between border-t border-white/[0.05] pt-4">
              <span className="text-lg font-semibold tracking-tight text-white">{p.price.toLocaleString()} ₽</span>
              <button className="btn-secondary text-[11px]">
                <Download className="h-3 w-3" /> Купить
              </button>
            </div>
          </div>
        ))}
      </section>

      <section className="mt-14 grid gap-4 md:grid-cols-3">
        {[
          { icon: Sparkles, title: "Готовые решения", desc: "Каждый промпт протестирован на реальных задачах и дает стабильный результат." },
          { icon: Shield, title: "Безопасная оплата", desc: "Оплата через ЮKassa, возврат в течение 30 дней, если промпт не подошёл." },
          { icon: Tag, title: "Обновления", desc: "Подписка включает обновления всех пакетов на 6 месяцев." },
        ].map((s) => (
          <div key={s.title} className="glass-card p-6">
            <s.icon className="h-4 w-4 text-violet-300" />
            <h4 className="mt-4 text-[14px] font-semibold text-white">{s.title}</h4>
            <p className="mt-2 text-[13px] leading-relaxed text-white/55">{s.desc}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
