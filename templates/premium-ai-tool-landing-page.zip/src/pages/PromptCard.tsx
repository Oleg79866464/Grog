import { Link } from "react-router-dom";
import { Check, Download, Star, Shield, Sparkles, Zap, Clock, Tag, Users, ShoppingCart, Heart } from "lucide-react";

export function PromptCard() {
  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <div className="mb-6 flex items-center gap-2 text-[12px] text-white/45">
        <Link to="/prompts" className="hover:text-white">Маркетплейс</Link>
        <span>/</span>
        <span>Промпт</span>
      </div>

      <article className="glass-card overflow-hidden">
        <div className="relative h-40 w-full bg-gradient-to-br from-violet-600/30 via-indigo-500/20 to-cyan-500/20">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.2),transparent_60%)]" />
          <div className="absolute right-5 top-5 flex items-center gap-2">
            <span className="badge border-amber-400/30 bg-amber-400/10 text-amber-200">
              <Sparkles className="h-3 w-3" /> ХИТ
            </span>
            <span className="badge">SEO</span>
          </div>
          <div className="absolute left-5 top-5">
            <span className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-[#0a0c12] shadow-lg">
              <Tag className="h-5 w-5 text-violet-300" />
            </span>
          </div>
        </div>

        <div className="space-y-6 p-7">
          <div>
            <span className="section-eyebrow">Промпт-пакет</span>
            <h1 className="mt-2 text-3xl font-semibold tracking-tight text-gradient sm:text-4xl">
              SEO-промпты для кластеризации и метатегов
            </h1>
            <p className="mt-3 text-[14px] leading-relaxed text-white/60">
              Готовый набор из 80 промптов для SEO-специалистов и контент-маркетологов.
              Сокращает время на написание метатегов в 5 раз.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {[
              { icon: Star, label: "Рейтинг", value: "4.9 / 5", color: "amber" },
              { icon: Download, label: "Загрузок", value: "1 240", color: "violet" },
              { icon: Users, label: "Клиентов", value: "380+", color: "cyan" },
              { icon: Clock, label: "Обновление", value: "01.2026", color: "emerald" },
            ].map((m) => (
              <div key={m.label} className="rounded-xl border border-white/[0.05] bg-white/[0.02] p-4">
                <m.icon className="h-3.5 w-3.5 text-violet-300" />
                <div className="mt-2 text-[10px] uppercase tracking-[0.18em] text-white/40">{m.label}</div>
                <div className="mt-1 font-semibold text-white">{m.value}</div>
              </div>
            ))}
          </div>

          <p className="text-[14px] leading-relaxed text-white/65">
            Пакет подойдёт для команд, которые регулярно работают с семантическим ядром и SEO-текстами.
            Все промпты совместимы с ChatGPT, Claude, GigaChat и YandexGPT. Каждый шаблон снабжён
            примерами вводных данных и ожидаемого вывода.
          </p>

          <div className="rounded-2xl border border-white/[0.05] bg-gradient-to-br from-violet-500/5 to-blue-500/5 p-5">
            <div className="text-[10px] uppercase tracking-[0.18em] text-violet-300">Что внутри</div>
            <ul className="mt-3 grid gap-2 text-[13px] text-white/75">
              {[
                "24 промпта для кластеризации запросов",
                "18 шаблонов Title и Description",
                "12 промптов для расширения семантики",
                "10 шаблонов для FAQ и People Also Ask",
                "8 промптов для внутренней перелинковки",
                "8 промптов для генерации мета-тегов изображений",
              ].map((f, i) => (
                <li key={i} className="flex items-start gap-2">
                  <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-[14px] font-semibold text-white">Преимущества пакета</h3>
            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              {[
                { icon: Zap, title: "Экономия времени", desc: "В 5 раз быстрее ручной работы" },
                { icon: Shield, title: "Проверенные шаблоны", desc: "Каждый промпт протестирован на 50+ сайтах" },
                { icon: Heart, title: "Бесплатные обновления", desc: "6 месяцев новых шаблонов в подарок" },
              ].map((b) => (
                <div key={b.title} className="glass-card p-4">
                  <b.icon className="h-4 w-4 text-violet-300" />
                  <h4 className="mt-3 text-[13px] font-semibold text-white">{b.title}</h4>
                  <p className="mt-1 text-[12px] text-white/55">{b.desc}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-3 border-t border-white/[0.05] pt-6">
            <button className="btn-primary flex-1 justify-center">
              <ShoppingCart className="h-3.5 w-3.5" /> Купить за 1 490 ₽
            </button>
            <button className="btn-secondary">
              Добавить в корзину
            </button>
            <button className="btn-secondary px-3"><Heart className="h-3.5 w-3.5" /></button>
          </div>
        </div>
      </article>

      <div className="mt-8 text-center">
        <Link to="/prompts" className="inline-flex items-center gap-1 text-[12px] text-white/55 hover:text-white">
          ← Вернуться к маркетплейсу промптов
        </Link>
      </div>
    </div>
  );
}
