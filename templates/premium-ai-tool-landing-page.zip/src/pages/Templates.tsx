import { useState } from "react";
import { MoreHorizontal, Plus, Settings2, Sparkles } from "lucide-react";
import { cn } from "../utils/cn";

const templates = [
  { id: "tpl-home", name: "Главная страница каталога", pageType: "Главная", status: "active", version: "v6.4.1", updated: "12.01.2026", blocks: 12 },
  { id: "tpl-cat", name: "Раздел категории", pageType: "Категория", status: "active", version: "v3.1.0", updated: "10.01.2026", blocks: 9 },
  { id: "tpl-tool", name: "Карточка инструмента", pageType: "Инструмент", status: "active", version: "v2.8.4", updated: "08.01.2026", blocks: 14 },
  { id: "tpl-redirect", name: "Редирект /go", pageType: "Служебная", status: "active", version: "v1.4.0", updated: "05.01.2026", blocks: 5 },
  { id: "tpl-prompts", name: "Витрина промптов", pageType: "eCommerce", status: "draft", version: "v0.6.0", updated: "11.01.2026", blocks: 11 },
  { id: "tpl-buyer", name: "Отчёт покупателя", pageType: "M&A", status: "draft", version: "v0.2.1", updated: "03.01.2026", blocks: 8 },
  { id: "tpl-sponsors", name: "Медиакит", pageType: "Партнёрка", status: "active", version: "v1.0.0", updated: "01.01.2026", blocks: 7 },
  { id: "tpl-seo", name: "SEO-лендинг", pageType: "Landing", status: "active", version: "v4.2.1", updated: "07.01.2026", blocks: 10 },
];

export function Templates() {
  const [filter, setFilter] = useState<"all" | "active" | "draft">("all");
  const list = templates.filter((t) => filter === "all" ? true : t.status === filter);

  return (
    <div className="mx-auto max-w-7xl px-6 py-12">
      <div className="flex items-end justify-between gap-6">
        <div>
          <span className="section-eyebrow">Администратор · Управление шаблонами</span>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-gradient sm:text-4xl">
            Шаблоны страниц
          </h1>
          <p className="mt-2 text-[14px] text-white/55">
            Централизованное управление версиями и состоянием всех шаблонов проекта.
          </p>
        </div>
        <button className="btn-primary text-[12px]">
          <Plus className="h-3.5 w-3.5" /> Новый шаблон
        </button>
      </div>

      <div className="mt-8 flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] p-1 w-fit">
        {[
          { key: "all", label: "Все" },
          { key: "active", label: "Активные" },
          { key: "draft", label: "Черновики" },
        ].map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key as typeof filter)}
            className={cn(
              "rounded-lg px-3 py-1.5 text-[12px] font-medium transition-colors",
              filter === f.key ? "bg-white/10 text-white" : "text-white/55 hover:text-white"
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="mt-6 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        {list.map((tpl) => (
          <div key={tpl.id} className="glass-card glass-card-hover overflow-hidden">
            <div className="relative h-32 w-full overflow-hidden border-b border-white/[0.05] bg-gradient-to-br from-[#0d0f17] via-[#0a0c12] to-[#0d0f17]">
              <div className="absolute inset-0 grid grid-cols-6 grid-rows-3 gap-px p-3 opacity-60">
                {Array.from({ length: 18 }).map((_, i) => (
                  <div key={i} className="rounded bg-white/[0.04]" />
                ))}
              </div>
              <div className="absolute inset-0 flex items-end justify-between p-3">
                <span className="badge bg-[#0a0c12] text-[10px]">{tpl.pageType}</span>
                <span className={cn("badge text-[10px]", tpl.status === "active" ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-300" : "border-amber-400/30 bg-amber-400/10 text-amber-200")}>
                  {tpl.status === "active" ? "Активен" : "Черновик"}
                </span>
              </div>
            </div>
            <div className="space-y-4 p-5">
              <div>
                <h3 className="text-[15px] font-semibold tracking-tight text-white">{tpl.name}</h3>
                <p className="mt-1 text-[11px] text-white/45">{tpl.id} · {tpl.blocks} блоков</p>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-white/55">Версия</span>
                <span className="font-mono text-violet-300">{tpl.version}</span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-white/55">Обновлён</span>
                <span className="text-white/85">{tpl.updated}</span>
              </div>
              <div className="flex items-center gap-2 border-t border-white/[0.05] pt-4">
                {tpl.status === "active" ? (
                  <button className="btn-secondary flex-1 justify-center text-[11px]">
                    <Settings2 className="h-3 w-3" /> Настроить
                  </button>
                ) : (
                  <button className="btn-primary flex-1 justify-center text-[11px]">
                    <Sparkles className="h-3 w-3" /> Активировать
                  </button>
                )}
                <button className="btn-secondary px-2">
                  <MoreHorizontal className="h-3 w-3" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
