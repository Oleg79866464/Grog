import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowUpRight, Shield, CheckCircle2 } from "lucide-react";
import { findTool } from "../data/tools";

export function RedirectPage() {
  const { id } = useParams();
  const tool = findTool(id || "");
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const start = Date.now();
    const total = 2200;
    const interval = setInterval(() => {
      const elapsed = Date.now() - start;
      const pct = Math.min(100, Math.round((elapsed / total) * 100));
      setProgress(pct);
      if (pct >= 100) {
        clearInterval(interval);
        setDone(true);
      }
    }, 30);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative flex min-h-[80vh] items-center justify-center px-6 py-16">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-1/3 h-[420px] w-[640px] -translate-x-1/2 rounded-full bg-violet-600/15 blur-[120px]" />
      </div>
      <div className="glass-card w-full max-w-xl p-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-violet-300">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-violet-400" />
            AINexus · Secure redirect
          </div>
          <Shield className="h-4 w-4 text-emerald-400" />
        </div>

        <div className="mt-8 text-center">
          <div className="mx-auto inline-flex h-12 w-12 items-center justify-center rounded-full border border-white/10 bg-white/[0.03]">
            {done ? (
              <CheckCircle2 className="h-5 w-5 text-emerald-400" />
            ) : (
              <ArrowUpRight className="h-5 w-5 animate-pulse text-violet-300" />
            )}
          </div>
          <h1 className="mt-5 text-2xl font-semibold tracking-tight text-gradient sm:text-3xl">
            {done ? "Перенаправляем…" : "Проверяем партнёрскую ссылку"}
          </h1>
          <p className="mt-3 text-[14px] text-white/55">
            Мы готовим безопасный переход на сайт партнёра. Это займёт пару секунд.
          </p>
        </div>

        <div className="mt-8">
          <div className="flex items-center justify-between text-[11px] text-white/45">
            <span>Прогресс</span>
            <span>{progress}%</span>
          </div>
          <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-white/[0.05]">
            <div
              className="h-full rounded-full bg-gradient-to-r from-violet-500 via-indigo-500 to-cyan-400 transition-[width] duration-150 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <div className="mt-7 rounded-xl border border-white/[0.05] bg-white/[0.02] p-4">
          <div className="text-[10px] uppercase tracking-[0.18em] text-white/40">Назначение</div>
          <div className="mt-1 truncate text-[13px] font-medium text-white">
            {tool ? `https://${tool.id}.ru` : "https://partner.example.ru"}
          </div>
          <div className="mt-2 text-[11px] text-white/45">
            Партнёр AINexus получит вознаграждение, если вы совершите покупку. Это не влияет на вашу цену.
          </div>
        </div>

        <div className="mt-7 text-center text-[11px] text-white/40">
          Не хотите ждать?{" "}
          <Link to="/" className="text-white/70 underline-offset-2 hover:underline">
            Вернуться в каталог
          </Link>
        </div>
      </div>
    </div>
  );
}
