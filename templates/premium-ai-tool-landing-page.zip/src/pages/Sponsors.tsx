import { Link } from "react-router-dom";
import { ArrowUpRight, BadgeCheck, BarChart3, Building2, Crown, Download, Eye, Globe, Layers, Shield, Sparkles, TrendingUp } from "lucide-react";

const sponsors = [
  { name: "Яндекс", tier: "Platinum", since: "2024", status: "active", logo: "bg-gradient-to-br from-rose-500 to-yellow-400" },
  { name: "Сбер", tier: "Platinum", since: "2024", status: "active", logo: "bg-gradient-to-br from-emerald-400 to-teal-500" },
  { name: "VK", tier: "Gold", since: "2024", status: "active", logo: "bg-gradient-to-br from-sky-400 to-indigo-500" },
  { name: "Альфа-Банк", tier: "Gold", since: "2025", status: "active", logo: "bg-gradient-to-br from-rose-400 to-red-500" },
  { name: "Тинькофф", tier: "Silver", since: "2025", status: "active", logo: "bg-gradient-to-br from-amber-300 to-orange-500" },
  { name: "МТС", tier: "Silver", since: "2025", status: "active", logo: "bg-gradient-to-br from-red-500 to-rose-500" },
  { name: "Ozon", tier: "Gold", since: "2025", status: "active", logo: "bg-gradient-to-br from-violet-500 to-fuchsia-500" },
  { name: "Магнит", tier: "Bronze", since: "2025", status: "active", logo: "bg-gradient-to-br from-blue-400 to-blue-600" },
];

const adSlots = [
  { id: "SLOT-A1", name: "Хедлайнер главной", position: "Hero / Above the fold", price: "120 000 ₽", ctr: "3.8%", sold: true },
  { id: "SLOT-A2", name: "Каталог спонсор", position: "Категории / Top 3", price: "45 000 ₽", ctr: "1.6%", sold: false },
  { id: "SLOT-B1", name: "Промпт-витрина", position: "Маркетплейс / Featured", price: "30 000 ₽", ctr: "2.1%", sold: true },
  { id: "SLOT-B2", name: "Email digest", position: "Еженедельная рассылка", price: "18 000 ₽", ctr: "4.2%", sold: false },
  { id: "SLOT-C1", name: "FAQ баннер", position: "Все страницы категорий", price: "8 500 ₽", ctr: "0.9%", sold: false },
  { id: "SLOT-C2", name: "Sticky sidebar", position: "Инструменты / Fixed", price: "22 000 ₽", ctr: "1.4%", sold: true },
];

const audienceStats = [
  { label: "MAU", value: "184K", delta: "+12%" },
  { label: "Средний чек", value: "4 025 ₽", delta: "+8%" },
  { label: "Время на сайте", value: "4:18", delta: "+15%" },
  { label: "Подписчики в ТГ", value: "12.4K", delta: "+22%" },
];

const mediaKitSections = [
  { icon: Globe, title: "Аудитория", desc: "Демография и интересы нашей аудитории, данные опросов и сегментация." },
  { icon: BarChart3, title: "Аналитика", desc: "Детальная статистика по всем площадкам: сайт, рассылка, соцсети." },
  { icon: Layers, title: "Форматы", desc: "Разрешённые форматы интеграций: нативная, баннер, email, подкаст." },
  { icon: Shield, title: "Прозрачность", desc: "Все размещения фиксируются в открытом отчёте и публикуются после кампании." },
];

export function Sponsors() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-12">
      <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr] lg:items-center">
        <div>
          <span className="section-eyebrow">Для партнёров · Медиакит 2026</span>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-gradient sm:text-5xl">
            Разместитесь в крупнейшем каталоге AI-инструментов
          </h1>
          <p className="mt-4 max-w-xl text-[14px] leading-relaxed text-white/55">
            Наши читатели — это CTO, маркетологи, продакт-менеджеры и предприниматели, которые ежедневно
            выбирают между российскими и зарубежными нейросетями.
          </p>
          <div className="mt-7 flex flex-wrap items-center gap-3">
            <button className="btn-primary">
              <Crown className="h-3.5 w-3.5" /> Стать спонсором
            </button>
            <button className="btn-secondary">
              <Download className="h-3.5 w-3.5" /> Скачать медиакит PDF
            </button>
          </div>
        </div>
        <div className="glass-card p-6">
          <div className="text-[10px] uppercase tracking-[0.18em] text-white/40">Аудитория</div>
          <div className="mt-5 grid grid-cols-2 gap-3">
            {audienceStats.map((s) => (
              <div key={s.label} className="rounded-xl border border-white/[0.05] bg-white/[0.02] p-4">
                <div className="flex items-baseline justify-between">
                  <span className="text-[10px] uppercase tracking-[0.18em] text-white/40">{s.label}</span>
                </div>
                <div className="mt-2 text-xl font-semibold tracking-tight text-white">{s.value}</div>
                <div className="mt-1 text-[11px] text-emerald-300">{s.delta} vs прошлый месяц</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <section className="mt-14 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {mediaKitSections.map((m) => (
          <div key={m.title} className="glass-card p-5">
            <m.icon className="h-4 w-4 text-violet-300" />
            <h4 className="mt-4 text-[14px] font-semibold text-white">{m.title}</h4>
            <p className="mt-2 text-[12px] leading-relaxed text-white/55">{m.desc}</p>
          </div>
        ))}
      </section>

      <section className="mt-14">
        <div className="flex items-end justify-between gap-6">
          <div>
            <span className="section-eyebrow">Спонсоры проекта</span>
            <h2 className="mt-2 text-2xl font-semibold tracking-tight text-gradient sm:text-3xl">
              Наши партнёры
            </h2>
          </div>
          <Link to="/contact" className="btn-secondary text-[12px]">
            Стать партнёром
            <ArrowUpRight className="h-3.5 w-3.5" />
          </Link>
        </div>
        <div className="mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {sponsors.map((s) => (
            <div key={s.name} className="glass-card glass-card-hover flex items-center gap-3 p-4">
              <div className={`h-10 w-10 shrink-0 rounded-xl ${s.logo}`} />
              <div className="flex-1">
                <div className="flex items-center gap-1.5">
                  <span className="text-[13px] font-semibold text-white">{s.name}</span>
                  <BadgeCheck className="h-3 w-3 text-emerald-400" />
                </div>
                <div className="mt-0.5 flex items-center gap-2 text-[10px] text-white/45">
                  <span className={
                    s.tier === "Platinum" ? "text-violet-300" :
                    s.tier === "Gold" ? "text-amber-300" :
                    s.tier === "Silver" ? "text-slate-200" : "text-amber-700"
                  }>{s.tier}</span>
                  <span>·</span>
                  <span>с {s.since}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-14">
        <span className="section-eyebrow">Рекламные слоты</span>
        <h2 className="mt-2 text-2xl font-semibold tracking-tight text-gradient sm:text-3xl">
          Доступные интеграции
        </h2>
        <div className="mt-7 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {adSlots.map((s) => (
            <div key={s.id} className="glass-card p-5">
              <div className="flex items-start justify-between">
                <div>
                  <span className="badge">{s.id}</span>
                  <h4 className="mt-2 text-[14px] font-semibold text-white">{s.name}</h4>
                  <p className="mt-0.5 text-[11px] text-white/45">{s.position}</p>
                </div>
                <span className={`badge ${s.sold ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-300" : "border-amber-400/30 bg-amber-400/10 text-amber-200"}`}>
                  {s.sold ? "Занят" : "Свободен"}
                </span>
              </div>
              <div className="mt-4 flex items-center justify-between text-[12px]">
                <span className="text-white/55">{s.price} / мес</span>
                <span className="inline-flex items-center gap-1 text-emerald-300">
                  <TrendingUp className="h-3 w-3" /> CTR {s.ctr}
                </span>
              </div>
              <button className={`mt-4 w-full justify-center text-[11px] ${s.sold ? "btn-secondary" : "btn-primary"}`}>
                {s.sold ? <><Eye className="h-3 w-3" /> Смотреть</> : <><Sparkles className="h-3 w-3" /> Забронировать</>}
              </button>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-14">
        <span className="section-eyebrow">Аналитика распределения показов</span>
        <h2 className="mt-2 text-2xl font-semibold tracking-tight text-gradient sm:text-3xl">
          Как работает реклама у нас
        </h2>
        <div className="mt-7 grid grid-cols-12 gap-px overflow-hidden rounded-2xl border border-white/[0.05] bg-white/[0.02]">
          {[120, 180, 230, 280, 320, 410, 380, 460, 540, 612, 690, 720, 640, 580, 720, 850, 920, 1010, 1080, 1210, 1180, 1240, 1310, 1380].map((v, i) => (
            <div key={i} className="relative h-24 bg-[#0a0c12] p-1.5">
              <div
                className="absolute bottom-1.5 left-1.5 right-1.5 rounded bg-gradient-to-t from-violet-500 to-cyan-400"
                style={{ height: `${(v / 1380) * 100}%` }}
              />
            </div>
          ))}
        </div>
      </section>

      <section className="mt-14">
        <div className="glass-card p-8 text-center">
          <Building2 className="mx-auto h-8 w-8 text-violet-300" />
          <h2 className="mt-4 text-2xl font-semibold tracking-tight text-gradient sm:text-3xl">
            Готовы обсудить партнёрство?
          </h2>
          <p className="mx-auto mt-2 max-w-xl text-[13px] text-white/55">
            Оставьте заявку, и мы пришлём персональное коммерческое предложение в течение одного рабочего дня.
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <button className="btn-primary">Оставить заявку</button>
            <button className="btn-secondary">Задать вопрос</button>
          </div>
        </div>
      </section>
    </div>
  );
}
