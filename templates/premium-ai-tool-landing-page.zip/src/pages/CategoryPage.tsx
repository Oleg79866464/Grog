import { Link, useParams } from "react-router-dom";
import { ArrowUpRight, Filter, Sparkles } from "lucide-react";
import { categories, tools, type Tool } from "../data/tools";
import { ToolCard, PageHero, ComparisonTable, FAQBlock, TrustBadges } from "../components/PageSections";

const categoryData: Record<string, {
  eyebrow: string;
  title: string;
  intro: string;
  seo: string;
  cases: string[];
}> = {
  marketing: {
    eyebrow: "Категория",
    title: "Нейросети для маркетинга",
    intro: "ИИ-решения для автоматизации маркетинга: от прогнозирования спроса и динамического ценообразования до генерации рекламных креативов и персонализированных рассылок.",
    seo: "В подборке представлены российские нейросети для маркетинга: платформы для прогнозной аналитики, генерации рекламных кампаний и автоматизации performance-маркетинга. Каждая модель сравнивается по качеству генерации, интеграциям и стоимости лида.",
    cases: [
      "Прогнозирование оттока и LTV клиентов",
      "Генерация рекламных креативов и UGC",
      "Персонализация email и push-рассылок",
      "Автоматическое назначение ставок в Яндекс.Директ",
    ],
  },
  smm: {
    eyebrow: "Категория",
    title: "ИИ для SMM",
    intro: "Инструменты для ведения социальных сетей: планирование контент-плана, адаптация под разные площадки, генерация креативов и аналитика вовлечённости.",
    seo: "Реестр лучших российских ИИ для SMM: от генерации постов и сторис до модерации комментариев и автоответов в Direct. Каждое решение протестировано редакцией AINexus.",
    cases: [
      "Контент-план на месяц в один клик",
      "Автоответы в Direct Instagram и VK",
      "Адаптация постов под Телеграм и Дзен",
      "Генерация обложек и каруселей",
    ],
  },
  text: {
    eyebrow: "Категория",
    title: "Генераторы текста",
    intro: "Языковые модели для написания статей, писем, скриптов и технической документации. Поддержка русского языка и возможность приватного развёртывания.",
    seo: "Российские генераторы текста — обзор YandexGPT, GigaChat и других LLM. Сравнение по скорости генерации, стоимости токена и качеству работы с кириллицей.",
    cases: [
      "Написание длинных статей и книг",
      "Создание технической документации",
      "Перевод и локализация контента",
      "Суммаризация длинных документов",
    ],
  },
  seo: {
    eyebrow: "Категория",
    title: "ИИ для SEO",
    intro: "Автоматизация поисковой оптимизации: кластеризация запросов, генерация метатегов, аудит сайтов и внутренняя перелинковка.",
    seo: "Обзор российских ИИ для SEO-продвижения: как автоматизировать кластеризацию, написание Title и Description, аудит сайтов и анализ конкурентов.",
    cases: [
      "Автоматическая кластеризация запросов",
      "Генерация Title и Description",
      "Аудит сайта и рекомендации",
      "Внутренняя перелинковка",
    ],
  },
  content: {
    eyebrow: "Категория",
    title: "ИИ для контента",
    intro: "Полный цикл создания контента: от идеи и плана публикаций до готовой статьи, видео или подкаста.",
    seo: "Лучшие российские ИИ для создания контента. Сравниваем качество генерации, интеграции с CMS и скорость вывода.",
    cases: [
      "Редакционный календарь на квартал",
      "Длинные SEO-статьи и лонгриды",
      "email-рассылки и триггеры",
      "Креативные концепции для бренда",
    ],
  },
  image: {
    eyebrow: "Категория",
    title: "Генераторы изображений",
    intro: "Генерация фотореалистичных картинок, иллюстраций и 3D-сцен по текстовому или визуальному промпту.",
    seo: "Обзор российских генераторов изображений: Kandinsky, Шедеврум и другие. Сравниваем качество картинок, скорость генерации и стоимость.",
    cases: [
      "Фотореалистичные иллюстрации",
      "Концепт-арт для игр и кино",
      "Баннеры и рекламные креативы",
      "Фирменная графика для бренда",
    ],
  },
  video: {
    eyebrow: "Категория",
    title: "ИИ для видео",
    intro: "Генерация видеороликов по текстовому сценарию, анимация изображений, автосубтитры и перевод.",
    seo: "Лучшие российские ИИ для видео: генерация коротких роликов, автоматический монтаж, TTS и синтез спикеров.",
    cases: [
      "Короткие видео для Reels и Shorts",
      "Автоматический монтаж вебинаров",
      "Синтез видеоспикеров и аватаров",
      "Автосубтитры и перевод на 12 языков",
    ],
  },
  business: {
    eyebrow: "Категория",
    title: "ИИ для бизнеса",
    intro: "Корпоративные решения: автоматизация рутины, BI-дашборды, ИИ-ассистенты и приватные LLM.",
    seo: "Подборка российских ИИ-решений для бизнеса: от автоматизации HR и документооборота до корпоративных BI-платформ.",
    cases: [
      "Автоматизация документооборота",
      "BI-дашборды и прогнозная аналитика",
      "HR: скрининг резюме и онбординг",
      "ИИ-ассистенты для топ-менеджмента",
    ],
  },
};

const defaults = categoryData.marketing;

export function CategoryPage() {
  const { slug } = useParams();
  const data = (slug && categoryData[slug]) || defaults;
  const filteredTools: Tool[] = tools.filter((t) => {
    if (!slug) return false;
    if (slug === "text") return t.category === "Генератор текста";
    if (slug === "image") return t.category === "Генератор изображений";
    if (slug === "video") return t.category === "AI для видео";
    if (slug === "business") return t.category === "ИИ для бизнеса";
    if (slug === "seo") return t.category === "ИИ для SEO";
    if (slug === "smm") return t.category === "ИИ для SMM";
    if (slug === "content") return t.category === "ИИ для контента";
    if (slug === "marketing") return t.category === "Нейросети для маркетинга";
    return false;
  });
  const recommended = filteredTools.slice(0, 6);
  const comparisons = [
    { feature: "Русский язык (качество)", a: "★★★★★", b: "★★★☆☆" },
    { feature: "API и webhooks", a: "Да, готовые SDK", b: "Только REST" },
    { feature: "Стоимость генерации", a: "от 6 ₽", b: "от 22 ₽" },
    { feature: "Приватное развёртывание", a: "Доступно", b: "Нет" },
    { feature: "SLA и поддержка 24/7", a: "Да", b: "Только бизнес-тариф" },
  ];
  const faqs = [
    { q: `Как выбрать ИИ для задач в «${data.title.toLowerCase()}»?`, a: "Ориентируйтесь на три метрики: качество на русском языке, стоимость одного действия и наличие API для вашего стека. В нашем каталоге каждый инструмент сопровождается детальным сравнением по этим параметрам." },
    { q: "Есть ли бесплатные тарифы у российских нейросетей?", a: "Да, большинство сервисов предоставляют freemium-доступ с ограниченным количеством запросов в месяц. Это удобно для тестирования и небольших проектов." },
    { q: "Можно ли интегрировать несколько инструментов одновременно?", a: "Многие команды строят композитные стеки: один ИИ для генерации идей, другой — для финальной правки, третий — для публикации. В каталоге есть готовые шаблоны таких стеков." },
  ];

  return (
    <>
      <PageHero
        eyebrow={data.eyebrow}
        title={data.title}
        description={data.intro}
        primaryCta={{ label: "Сравнить все инструменты", href: "#compare" }}
        secondaryCta={{ label: "Все категории", href: "/" }}
      >
        <div className="mx-auto mt-10 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-4 py-1.5 text-[12px] text-white/55">
          <Filter className="h-3.5 w-3.5" />
          Показано {recommended.length} из {filteredTools.length || 12} сервисов · Обновлено сегодня
        </div>
      </PageHero>

      <section className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-3 md:grid-cols-4">
          {data.cases.map((c) => (
            <div key={c} className="glass-card p-5">
              <div className="flex items-center gap-2 text-violet-300">
                <Sparkles className="h-3.5 w-3.5" />
                <span className="text-[10px] font-semibold uppercase tracking-[0.18em]">Кейс</span>
              </div>
              <p className="mt-3 text-[13px] leading-relaxed text-white/75">{c}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 pb-16" id="tools">
        <div className="flex items-end justify-between gap-6">
          <div>
            <div className="section-eyebrow">Рекомендуем</div>
            <h2 className="mt-2 text-2xl font-semibold tracking-tight text-gradient sm:text-3xl">
              Лучшие инструменты в категории
            </h2>
          </div>
          <Link to="/" className="hidden btn-secondary text-[12px] md:inline-flex">
            Все категории
            <ArrowUpRight className="h-3.5 w-3.5" />
          </Link>
        </div>
        <div className="mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {recommended.length > 0 ? (
            recommended.map((t) => <ToolCard key={t.id} tool={t} />)
          ) : (
            filteredTools.map((t) => <ToolCard key={t.id} tool={t} />)
          )}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 pb-16" id="compare">
        <div className="grid gap-10 lg:grid-cols-[1fr_1.6fr]">
          <div>
            <div className="section-eyebrow">Сравнение</div>
            <h2 className="mt-2 text-2xl font-semibold tracking-tight text-gradient sm:text-3xl">
              Лидер категории vs конкуренты
            </h2>
            <p className="mt-3 text-[13px] leading-relaxed text-white/55">
              Показываем только актуальные метрики. Если у вас есть данные, которые стоит учесть — напишите нам.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              {categories.slice(0, 6).map((c) => (
                <Link key={c.id} to={`/category/${c.id}`} className="badge">
                  {c.name}
                </Link>
              ))}
            </div>
          </div>
          <ComparisonTable rows={comparisons} />
        </div>
      </section>

      <TrustBadges />

      <section className="mx-auto max-w-7xl px-6 py-20">
        <div className="grid gap-12 lg:grid-cols-[1.3fr_1fr]">
          <div>
            <div className="section-eyebrow">SEO-материал</div>
            <h2 className="mt-2 text-2xl font-semibold tracking-tight text-gradient sm:text-3xl">
              Как выбрать решение под свою задачу
            </h2>
            <div className="mt-6 space-y-4 text-[14px] leading-relaxed text-white/60">
              <p>{data.seo}</p>
              <p>
                Мы еженедельно обновляем обзоры, чтобы вы видели актуальные тарифы, лимиты и качество генерации.
                Партнёрские ссылки отмечены отдельным значком — переход по ним помогает развитию каталога.
              </p>
              <p>
                Если вы представляете производителя ИИ-инструмента и хотите попасть в каталог, оставьте заявку на
                странице «Для партнёров». Мы проверяем каждое решение вручную и публикуем только проверенные продукты.
              </p>
            </div>
          </div>
          <div className="glass-card overflow-hidden">
            <div className="border-b border-white/[0.06] bg-white/[0.02] px-5 py-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-white/45">
              Внутренние ссылки
            </div>
            <ul className="divide-y divide-white/[0.04]">
              {categories.map((c) => (
                <li key={c.id}>
                  <Link to={`/category/${c.id}`} className="flex items-center justify-between px-5 py-3.5 text-[13px] text-white/70 transition-colors hover:bg-white/[0.02] hover:text-white">
                    <span>{c.name}</span>
                    <span className="text-[11px] text-white/35">{c.count}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 pb-24">
        <div className="section-eyebrow">FAQ</div>
        <h2 className="mt-2 mb-6 text-2xl font-semibold tracking-tight text-gradient sm:text-3xl">
          Частые вопросы
        </h2>
        <FAQBlock items={faqs} />
      </section>
    </>
  );
}
