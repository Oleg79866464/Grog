import { Link } from "react-router-dom";
import { ArrowUpRight, Check, Layers, Search, Sparkles, TrendingUp } from "lucide-react";

const intro = "В каталоге AINexus собраны все актуальные российские нейросети — от языковых моделей до генераторов видео. Мы регулярно обновляем обзоры, проверяем тарифы и публикуем честные сравнения.";

const seo = [
  "Каждый месяц мы публикуем более 30 новых обзоров и обновляем существующие карточки.",
  "Каталог полностью адаптирован для мобильных устройств и индексируется поисковыми системами в приоритетном порядке.",
  "Мы используем внутренние ссылки для перераспределения веса между категориями и повышения видимости длинного хвоста.",
  "Структура URL отражает иерархию категорий и позволяет быстро ориентироваться даже новым пользователям.",
];

const compareHints = [
  { label: "YandexGPT vs GigaChat", href: "/tool/yandexgpt" },
  { label: "Kandinsky vs Шедеврум", href: "/category/image" },
  { label: "SEOPilot vs ContentMind", href: "/category/seo" },
  { label: "SMM Oracle vs универсальные LLM", href: "/category/smm" },
];

export function SeoContent() {
  return (
    <div className="mx-auto max-w-5xl px-6 py-16">
      <span className="section-eyebrow">SEO-материал</span>
      <h1 className="mt-2 text-3xl font-semibold tracking-tight text-gradient sm:text-5xl">
        Российские ИИ-инструменты: полный обзор 2026 года
      </h1>
      <p className="mt-5 text-[15px] leading-relaxed text-white/65">
        {intro}
      </p>

      <section className="mt-12">
        <span className="section-eyebrow">Подробнее</span>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          {seo.map((s, i) => (
            <div key={i} className="glass-card flex gap-3 p-5">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-white/10 bg-gradient-to-br from-violet-500/15 to-blue-500/5 text-violet-200">
                <Check className="h-3.5 w-3.5" />
              </div>
              <p className="text-[13px] leading-relaxed text-white/70">{s}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-12">
        <span className="section-eyebrow">Полезные сравнения</span>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {compareHints.map((c) => (
            <Link key={c.label} to={c.href} className="glass-card glass-card-hover flex items-center justify-between p-5">
              <span className="inline-flex items-center gap-2 text-[14px] text-white/85">
                <Layers className="h-4 w-4 text-violet-300" />
                {c.label}
              </span>
              <ArrowUpRight className="h-3.5 w-3.5 text-white/35" />
            </Link>
          ))}
        </div>
      </section>

      <section className="mt-12 grid gap-4 md:grid-cols-3">
        {[
          { icon: Search, title: "Более 150 инструментов", desc: "В каталоге собраны как популярные, так и нишевые решения для бизнеса и личного использования." },
          { icon: TrendingUp, title: "Рост 18 месяцев подряд", desc: "Проект демонстрирует стабильный рост органического трафика без сезонных провалов." },
          { icon: Sparkles, title: "Честные обзоры", desc: "Мы не скрываем недостатки и указываем реальные кейсы использования." },
        ].map((f) => (
          <div key={f.title} className="glass-card p-6">
            <f.icon className="h-4 w-4 text-violet-300" />
            <h3 className="mt-5 text-[14px] font-semibold text-white">{f.title}</h3>
            <p className="mt-2 text-[13px] leading-relaxed text-white/55">{f.desc}</p>
          </div>
        ))}
      </section>

      <section className="mt-14">
        <h2 className="text-2xl font-semibold tracking-tight text-gradient sm:text-3xl">Рекомендуем почитать</h2>
        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          {[
            { t: "Как внедрить LLM в бизнес-процессы", d: "Пошаговое руководство по интеграции языковых моделей в рутинные операции." },
            { t: "SEO для AI-контента: мифы и реальность", d: "Разбираем, как поисковики относятся к материалам, сгенерированным нейросетями." },
            { t: "Топ-10 российских генераторов изображений", d: "Сравнительный обзор качества, стоимости и скорости работы." },
            { t: "AI в маркетинге: кейсы 2025 года", d: "Практические истории внедрения ИИ в performance- и контент-маркетинг." },
          ].map((a) => (
            <Link key={a.t} to="/" className="glass-card glass-card-hover p-5">
              <h3 className="text-[14px] font-semibold text-white">{a.t}</h3>
              <p className="mt-1 text-[12px] leading-relaxed text-white/55">{a.d}</p>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
