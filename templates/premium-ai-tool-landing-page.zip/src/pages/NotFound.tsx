export function NotFound() {
  return (
    <div className="mx-auto flex min-h-[60vh] max-w-3xl items-center justify-center px-6 py-24 text-center">
      <div className="space-y-4">
        <span className="section-eyebrow">404</span>
        <h1 className="text-4xl font-semibold tracking-tight text-gradient">Страница не найдена</h1>
        <p className="text-white/50">Возможно, инструмент был перемещён или удалён.</p>
      </div>
    </div>
  );
}
