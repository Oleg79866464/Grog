import { ArrowUpRight, Briefcase, Building2, CheckCircle2, Download, FileText, LineChart, Shield, Target, TrendingUp } from "lucide-react";

const summary = [
  { label: "Запрашиваемая цена", value: "48 000 000 ₽", sub: "x8 LTM revenue" },
  { label: "Годовая выручка (LTM)", value: "6 200 000 ₽", sub: "+38% YoY" },
  { label: "EBITDA", value: "32%", sub: "Прогноз на 2026" },
  { label: "MRR (декабрь)", value: "516 000 ₽", sub: "128 платных клиентов" },
];

const trafficValue = [
  { label: "Органический трафик", value: "184K", delta: "+24%" },
  { label: "Прямые заходы", value: "92K", delta: "+11%" },
  { label: "Реферальный", value: "38K", delta: "+42%" },
  { label: "Социальные сети", value: "21K", delta: "+9%" },
];

const seoValue = [
  { label: "Индексируемых страниц", value: "12 480" },
  { label: "DR / DA", value: "61 / 58" },
  { label: "Топ-10 запросов", value: "1 240" },
  { label: "Backlinks", value: "8 320" },
];

const highlights = [
  { icon: TrendingUp, title: "Стабильный рост", desc: "Трафик и MRR растут 18 месяцев подряд, без сезонных провалов." },
  { icon: Shield, title: "Юридическая чистота", desc: "Все партнёрские договоры проверены, нет судебных рисков." },
  { icon: Building2, title: "Сильная команда", desc: "5 человек in-house, включая SEO-специалиста и SMM-менеджера." },
  { icon: Target, title: "Нишевой лидер", desc: "Топ-3 в Рунете по запросу «каталог AI-инструментов»." },
];

export function BuyerReport() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-12">
      <div className="flex items-end justify-between gap-6">
        <div>
          <span className="section-eyebrow">Конфиденциально · Только для инвесторов</span>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-gradient sm:text-4xl">
            Отчёт покупателя AINexus
          </h1>
          <p className="mt-2 text-[14px] text-white/55">
            Пакет документов для стратегических инвесторов и M&A консультантов.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button className="btn-secondary text-[12px]">
            <FileText className="h-3.5 w-3.5" /> Полный PDF
          </button>
          <button className="btn-primary text-[12px]">
            <Download className="h-3.5 w-3.5" /> Скачать пакет
          </button>
        </div>
      </div>

      <div className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {summary.map((s) => (
          <div key={s.label} className="glass-card p-5">
            <span className="text-[10px] uppercase tracking-[0.18em] text-white/40">{s.label}</span>
            <div className="mt-3 text-2xl font-semibold tracking-tight text-gradient">{s.value}</div>
            <div className="mt-1 text-[11px] text-emerald-300">{s.sub}</div>
          </div>
        ))}
      </div>

      <section className="mt-12 grid gap-10 lg:grid-cols-[1fr_1.4fr]">
        <div className="space-y-6">
          <div>
            <span className="section-eyebrow">Обзор проекта</span>
            <h2 className="mt-2 text-2xl font-semibold tracking-tight text-gradient sm:text-3xl">
              Что приобретает покупатель
            </h2>
          </div>
          <p className="text-[14px] leading-relaxed text-white/65">
            AINexus — это крупнейший независимый каталог российских AI-инструментов с ежемесячной аудиторией
            более 184 тысяч уникальных посетителей. Проект монетизируется через партнёрские программы,
            продажу промптов и спонсорские интеграции.
          </p>
          <p className="text-[14px] leading-relaxed text-white/55">
            Продажа включает домен, движок, накопленную базу обзоров, рассылку из 12 400 подписчиков
            и действующие партнёрские договоры с 38 сервисами.
          </p>
          <div className="glass-card p-5">
            <h3 className="text-[14px] font-semibold text-white">Выводы</h3>
            <ul className="mt-3 space-y-2 text-[13px] text-white/65">
              {["Диверсифицированная выручка", "Сильный SEO-фундамент", "Растущая партнёрская сеть", "Низкая стоимость владения"].map((c) => (
                <li key={c} className="flex items-center gap-2">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                  {c}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="space-y-6">
          <div className="glass-card p-6">
            <h3 className="text-[14px] font-semibold text-white">Динамика выручки, ₽</h3>
            <div className="mt-3 grid grid-cols-12 gap-px overflow-hidden rounded-lg bg-white/[0.04]">
              {[120, 180, 230, 280, 320, 410, 380, 460, 540, 612, 690, 720].map((v, i) => (
                <div key={i} className="relative h-32 bg-[#0a0c12] p-2">
                  <div
                    className="absolute bottom-2 left-2 right-2 rounded bg-gradient-to-t from-violet-500 to-blue-400"
                    style={{ height: `${(v / 720) * 100}%` }}
                  />
                </div>
              ))}
            </div>
            <div className="mt-2 grid grid-cols-12 gap-px text-center text-[9px] text-white/35">
              {["Ф25","М25","А25","Мй25","Ин25","Ил25","Ав25","Сн25","Ок25","Ня25","Дк25","Ян26"].map((m) => (
                <div key={m}>{m}</div>
              ))}
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            {[
              { icon: Briefcase, label: "Платных клиентов", value: "128" },
              { icon: LineChart, label: "Churn", value: "4.1%" },
              { icon: TrendingUp, label: "LTV/CAC", value: "6.4×" },
              { icon: Target, label: "ARPU", value: "4 025 ₽" },
            ].map((m) => (
              <div key={m.label} className="glass-card p-5">
                <m.icon className="h-4 w-4 text-violet-300" />
                <div className="mt-4 text-[10px] uppercase tracking-[0.18em] text-white/40">{m.label}</div>
                <div className="mt-1 text-2xl font-semibold tracking-tight text-white">{m.value}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mt-14 grid gap-6 md:grid-cols-2">
        <div className="glass-card p-6">
          <h3 className="text-[14px] font-semibold text-white">Стоимость трафика</h3>
          <p className="mt-1 text-[12px] text-white/45">Оценка по входящему органическому трафику</p>
          <div className="mt-5 space-y-4">
            {trafficValue.map((t) => (
              <div key={t.label} className="flex items-center justify-between text-[13px]">
                <span className="text-white/65">{t.label}</span>
                <span className="font-medium text-white/85">{t.value}</span>
                <span className="text-emerald-300 text-[11px] flex items-center gap-0.5">
                  <ArrowUpRight className="h-3 w-3" /> {t.delta}
                </span>
              </div>
            ))}
          </div>
        </div>
        <div className="glass-card p-6">
          <h3 className="text-[14px] font-semibold text-white">SEO-активы</h3>
          <p className="mt-1 text-[12px] text-white/45">Накопленный органический капитал</p>
          <div className="mt-5 space-y-4">
            {seoValue.map((t) => (
              <div key={t.label} className="flex items-center justify-between text-[13px]">
                <span className="text-white/65">{t.label}</span>
                <span className="font-medium text-white/85">{t.value}</span>
                <span className="text-white/30 text-[11px]">—</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mt-14">
        <span className="section-eyebrow">Бизнес-акценты</span>
        <h2 className="mt-2 text-2xl font-semibold tracking-tight text-gradient sm:text-3xl">
          Почему это выгодно прямо сейчас
        </h2>
        <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {highlights.map((h) => (
            <div key={h.title} className="glass-card p-5">
              <h.icon className="h-5 w-5 text-violet-300" />
              <h4 className="mt-4 text-[14px] font-semibold text-white">{h.title}</h4>
              <p className="mt-2 text-[12px] leading-relaxed text-white/55">{h.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
