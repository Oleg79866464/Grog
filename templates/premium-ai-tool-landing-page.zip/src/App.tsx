import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { CategoryPage } from "./pages/CategoryPage";
import { ToolPage } from "./pages/ToolPage";
import { RedirectPage } from "./pages/RedirectPage";
import { Analytics } from "./pages/Analytics";
import { Templates } from "./pages/Templates";
import { BuyerReport } from "./pages/BuyerReport";
import { Contact } from "./pages/Contact";
import { Prompts } from "./pages/Prompts";
import { PromptCard } from "./pages/PromptCard";
import { Sponsors } from "./pages/Sponsors";
import { RevenueWidget } from "./pages/RevenueWidget";
import { SeoContent } from "./pages/SeoContent";
import { NotFound } from "./pages/NotFound";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/admin" element={<Layout />}>
          <Route index element={<Analytics />} />
          <Route path="analytics" element={<Analytics />} />
          <Route path="templates" element={<Templates />} />
        </Route>
        <Route element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="category/:slug" element={<CategoryPage />} />
          <Route path="category" element={<CategoryPage />} />
          <Route path="tool/:id" element={<ToolPage />} />
          <Route path="go/:id" element={<RedirectPage />} />
          <Route path="prompts" element={<Prompts />} />
          <Route path="prompts/card" element={<PromptCard />} />
          <Route path="sponsors" element={<Sponsors />} />
          <Route path="revenue-widget" element={<RevenueWidget />} />
          <Route path="seo-content" element={<SeoContent />} />
          <Route path="buyer-report" element={<BuyerReport />} />
          <Route path="contact" element={<Contact />} />
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
